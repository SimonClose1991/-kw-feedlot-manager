import type { Pen, FeedRunSummary } from "@shared/types";

export const LS_KEYS = {
  pens: "kw-feedlot-pens-v2",
  order: "kw-feedlot-order-v1",
  history: "kw-feedlot-history-v2",
  currentRun: "kw-feedlot-current-run-v2",
  feederDefault: "kw-feedlot-feeder-default-v1",
  splitPrefs: "kw-feedlot-split-prefs-v1",
  adminPin: "kw-feedlot-admin-pin-v1",
} as const;

function log(...args: any[]) { try { console.log("[KW]", ...args); } catch {} }
function warn(...args: any[]) { try { console.warn("[KW]", ...args); } catch {} }
function error(...args: any[]) { try { console.error("[KW]", ...args); } catch {} }

export function loadPens(): Pen[] {
  log("loadPens: reading from localStorage");
  const raw = localStorage.getItem(LS_KEYS.pens);
  if (raw) {
    try {
      const pens = (JSON.parse(raw) as Pen[]).map(p => ({
        ...p,
        rationPercent: typeof p.rationPercent === "number" ? p.rationPercent : 100,
      }));
      log("loadPens: loaded", pens.length, "pens");
      return pens;
    } catch (e) {
      error("loadPens: parse error", e);
    }
  }
  warn("loadPens: no saved pens found, using defaults");
  const defaults: Pen[] = [
    { id: crypto.randomUUID(), name: "Pen 1", ration: "Grower", headCount: 400, kgPerHead: 1.2, rationPercent: 100, active: true },
    { id: crypto.randomUUID(), name: "Pen 2", ration: "Grower", headCount: 380, kgPerHead: 1.2, rationPercent: 100, active: true },
    { id: crypto.randomUUID(), name: "Pen 3", ration: "Finisher", headCount: 420, kgPerHead: 1.4, rationPercent: 100, active: true },
    { id: crypto.randomUUID(), name: "Pen 4", ration: "Starter", headCount: 350, kgPerHead: 0.8, rationPercent: 100, active: true },
    { id: crypto.randomUUID(), name: "Hospital", ration: "Hay/Chaff", headCount: 45, kgPerHead: 0.5, rationPercent: 100, active: true },
  ];
  localStorage.setItem(LS_KEYS.pens, JSON.stringify(defaults));
  localStorage.setItem(LS_KEYS.order, JSON.stringify(defaults.map(p => p.id)));
  return defaults;
}

export function savePens(pens: Pen[]) {
  log("savePens: saving", pens.length, "pens");
  localStorage.setItem(LS_KEYS.pens, JSON.stringify(pens));
}

export function loadOrder(fallbackIds: string[]): string[] {
  log("loadOrder: reading");
  const raw = localStorage.getItem(LS_KEYS.order);
  if (raw) {
    try { 
      const order = JSON.parse(raw) as string[]; 
      log("loadOrder: loaded", order.length, "ids"); 
      return order; 
    } catch (e) { 
      error("loadOrder: parse error", e); 
    }
  }
  warn("loadOrder: using fallback");
  localStorage.setItem(LS_KEYS.order, JSON.stringify(fallbackIds));
  return fallbackIds;
}

export function saveOrder(order: string[]) {
  log("saveOrder: saving", order.length, "ids");
  localStorage.setItem(LS_KEYS.order, JSON.stringify(order));
}

export function loadHistory(): FeedRunSummary[] {
  log("loadHistory: reading");
  const raw = localStorage.getItem(LS_KEYS.history);
  if (!raw) return [];
  try { 
    const h = JSON.parse(raw) as FeedRunSummary[]; 
    log("loadHistory: entries", h.length); 
    return h; 
  } catch (e) { 
    error("loadHistory: parse error", e); 
    return []; 
  }
}

export function saveHistory(history: FeedRunSummary[]) {
  log("saveHistory: saving entries", history.length);
  localStorage.setItem(LS_KEYS.history, JSON.stringify(history));
}

export function loadCurrentRun(): FeedRunSummary | null {
  log("loadCurrentRun: reading");
  const raw = localStorage.getItem(LS_KEYS.currentRun);
  if (!raw) return null;
  try { 
    const r = JSON.parse(raw) as FeedRunSummary; 
    log("loadCurrentRun: loaded id", r.id); 
    return r; 
  } catch (e) { 
    error("loadCurrentRun: parse error", e); 
    return null; 
  }
}

export function saveCurrentRun(run: FeedRunSummary | null) {
  if (!run) { 
    log("saveCurrentRun: clearing"); 
    localStorage.removeItem(LS_KEYS.currentRun); 
  } else { 
    log("saveCurrentRun: saving id", run.id, "events", run.events.length, "period", run.period, "split", run.splitFraction); 
    localStorage.setItem(LS_KEYS.currentRun, JSON.stringify(run)); 
  }
}

export function loadDefaultFeeder(): string { 
  return localStorage.getItem(LS_KEYS.feederDefault) || ""; 
}

export function saveDefaultFeeder(name: string) { 
  log("saveDefaultFeeder:", name); 
  localStorage.setItem(LS_KEYS.feederDefault, name); 
}

export function loadSplitPrefs(): { AM: number; PM: number } {
  const raw = localStorage.getItem(LS_KEYS.splitPrefs);
  if (!raw) return { AM: 0.6, PM: 0.4 };
  try {
    const x = JSON.parse(raw);
    const AM = typeof x?.AM === "number" ? x.AM : 0.6;
    const PM = typeof x?.PM === "number" ? x.PM : 0.4;
    const norm = (n: number) => (n > 1 ? n / 100 : n);
    return { AM: norm(AM), PM: norm(PM) };
  } catch {
    return { AM: 0.6, PM: 0.4 };
  }
}

export function saveSplitPrefs(p: { AM: number; PM: number }) {
  const norm = (n: number) => (n > 1 ? n / 100 : n);
  const payload = { AM: norm(p.AM), PM: norm(p.PM) };
  log("saveSplitPrefs:", payload);
  localStorage.setItem(LS_KEYS.splitPrefs, JSON.stringify(payload));
}

export function loadAdminPin(): string | null {
  return localStorage.getItem(LS_KEYS.adminPin);
}

export function saveAdminPin(pin: string) {
  log("saveAdminPin: set");
  localStorage.setItem(LS_KEYS.adminPin, pin);
}

export function hasAdminPin(): boolean {
  const pin = loadAdminPin();
  return pin !== null && pin.length > 0;
}
