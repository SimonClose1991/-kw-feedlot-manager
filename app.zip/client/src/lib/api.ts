import type { Pen, FeedRunSummary, MixIngredient } from "@shared/types";

export interface SafetyCheckError {
  error: string;
  requiresConfirmation: boolean;
}

async function fetchAPI<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const response = await fetch(endpoint, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: "Request failed" }));
    // For 409 Conflict (safety check), throw with additional info
    if (response.status === 409 && error.requiresConfirmation) {
      const safetyError = new Error(error.error) as Error & { requiresConfirmation: boolean };
      safetyError.requiresConfirmation = true;
      throw safetyError;
    }
    throw new Error(error.error || `HTTP ${response.status}`);
  }

  return response.json();
}

export const api = {
  pens: {
    getAll: () => fetchAPI<Pen[]>("/api/pens"),
    save: (pens: Pen[], forceDelete: boolean = false) => fetchAPI("/api/pens", {
      method: "POST",
      body: JSON.stringify({ pens, forceDelete }),
    }),
  },

  history: {
    getAll: () => fetchAPI<FeedRunSummary[]>("/api/history"),
    save: (run: FeedRunSummary) => fetchAPI("/api/history", {
      method: "POST",
      body: JSON.stringify(run),
    }),
    delete: (id: string) => fetchAPI(`/api/history/${id}`, {
      method: "DELETE",
    }),
  },

  currentRun: {
    get: () => fetchAPI<FeedRunSummary | null>("/api/current-run"),
    save: (run: FeedRunSummary | null) => fetchAPI("/api/current-run", {
      method: "POST",
      body: JSON.stringify(run),
    }),
  },

  settings: {
    get: () => fetchAPI<{
      adminPin: string | null;
      defaultFeeder: string | null;
      splitAM: number;
      splitPM: number;
      silage: number;
      protein: number;
      energy: number;
      water: number;
      straw: number;
      ingredients: MixIngredient[];
      bufferPercent: number;
    }>("/api/settings"),
    save: (settings: {
      adminPin?: string | null;
      defaultFeeder?: string | null;
      splitAM?: number;
      splitPM?: number;
      silage?: number;
      protein?: number;
      energy?: number;
      water?: number;
      straw?: number;
      ingredients?: MixIngredient[];
      bufferPercent?: number;
    }) => fetchAPI("/api/settings", {
      method: "POST",
      body: JSON.stringify(settings),
    }),
  },
};
