// Workflow planner — embedded as a self-contained static page (client/public/workflow.html).
// It has its own admin login ("admin"), its own storage, and its own styling.
export default function Workflow() {
  return (
    <div className="w-full" style={{ height: "calc(100vh - 41px)" }}>
      <iframe
        src="/workflow.html"
        title="Farm Weekly Planner"
        className="w-full h-full border-0"
        data-testid="workflow-frame"
      />
    </div>
  );
}
