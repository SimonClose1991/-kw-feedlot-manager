import { useState } from "react";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import ElementsTab from "@/cattle/components/management/ElementsTab";
import RecipesTab from "@/cattle/components/management/RecipesTab";
import MobsTab from "@/cattle/components/management/MobsTab";
import LoadsTab from "@/cattle/components/management/LoadsTab";
import ReportsTab from "@/cattle/components/management/ReportsTab";

export default function Management() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("elements");

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/cattle")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-3xl font-bold text-foreground">
            Management
          </h1>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 h-auto">
            <TabsTrigger value="elements" className="text-sm md:text-base py-3" data-testid="tab-elements">
              Elements
            </TabsTrigger>
            <TabsTrigger value="recipes" className="text-sm md:text-base py-3" data-testid="tab-recipes">
              Recipes
            </TabsTrigger>
            <TabsTrigger value="mobs" className="text-sm md:text-base py-3" data-testid="tab-mobs">
              Mobs
            </TabsTrigger>
            <TabsTrigger value="loads" className="text-sm md:text-base py-3" data-testid="tab-loads">
              Loads
            </TabsTrigger>
            <TabsTrigger value="reports" className="text-sm md:text-base py-3" data-testid="tab-reports">
              Reports
            </TabsTrigger>
          </TabsList>

          <TabsContent value="elements" className="mt-6">
            <ElementsTab />
          </TabsContent>

          <TabsContent value="recipes" className="mt-6">
            <RecipesTab />
          </TabsContent>

          <TabsContent value="mobs" className="mt-6">
            <MobsTab />
          </TabsContent>

          <TabsContent value="loads" className="mt-6">
            <LoadsTab />
          </TabsContent>

          <TabsContent value="reports" className="mt-6">
            <ReportsTab />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
