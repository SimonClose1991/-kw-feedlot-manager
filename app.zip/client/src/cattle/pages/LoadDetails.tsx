import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Loader2, ArrowLeft, AlertCircle, CheckCircle2, ChevronUp, ChevronDown, XCircle, Clock, Sun, Moon, RefreshCw, Layers } from "lucide-react";
import { useLocation, useParams } from "wouter";
import FeedMode from "@/cattle/components/FeedMode";
import { GradualPercentageControl } from "@/cattle/components/GradualPercentageControl";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Element, LoadAssignment, Mob, Recipe, GradualElementData } from "@shared/cattleSchema";

interface IngredientTotal {
  elementName: string;
  unit: string;
  total: number;
}

interface MobIngredients {
  mob: Mob;
  multiplier: number;
  ingredients: { elementName: string; unit: string; amount: number }[];
}

export default function LoadDetails() {
  const params = useParams<{ loadName: string }>();
  const loadName = decodeURIComponent(params.loadName || "");
  const [, setLocation] = useLocation();
  const [feedMode, setFeedMode] = useState(false);
  const [feedSession, setFeedSession] = useState<"morning" | "afternoon" | null>(null);
  const [skippedMobs, setSkippedMobs] = useState<Set<string>>(new Set());
  const [mixerView, setMixerView] = useState<"split" | "combined">("combined");
  const { toast } = useToast();

  const toggleSkipMob = (mobName: string) => {
    setSkippedMobs(prev => {
      const next = new Set(prev);
      if (next.has(mobName)) {
        next.delete(mobName);
      } else {
        next.add(mobName);
      }
      return next;
    });
  };

  const { data: elements } = useQuery<Element[]>({
    queryKey: ["/api/elements"],
  });

  const { data: recipes } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  const { data: mobs } = useQuery<Mob[]>({
    queryKey: ["/api/mobs"],
  });

  const { data: allAssignments, isLoading: assignmentsLoading } = useQuery<LoadAssignment[]>({
    queryKey: ["/api/load-assignments"],
    staleTime: 0,
  });

  const mobNames = new Set(mobs?.map(m => m.name) || []);
  const assignments = allAssignments?.filter(a => a.loadName === loadName && mobNames.has(a.mobName)) || [];

  const reorderMutation = useMutation({
    mutationFn: ({ id, feedOrder, swapId, swapFeedOrder }: { id: string; feedOrder: number; swapId: string; swapFeedOrder: number }) =>
      Promise.all([
        apiRequest("PATCH", `/api/load-assignments/${id}`, { feedOrder }),
        apiRequest("PATCH", `/api/load-assignments/${swapId}`, { feedOrder: swapFeedOrder }),
      ]),
    onMutate: async ({ id, feedOrder, swapId, swapFeedOrder }) => {
      await queryClient.cancelQueries({ queryKey: ["/api/load-assignments"] });
      const previous = queryClient.getQueryData<LoadAssignment[]>(["/api/load-assignments"]);
      queryClient.setQueryData<LoadAssignment[]>(["/api/load-assignments"], old =>
        old?.map(a => {
          if (a.id === id) return { ...a, feedOrder };
          if (a.id === swapId) return { ...a, feedOrder: swapFeedOrder };
          return a;
        })
      );
      return { previous };
    },
    onError: (_err, _vars, context) => {
      if (context?.previous) queryClient.setQueryData(["/api/load-assignments"], context.previous);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
    },
  });

  const toggleTwiceDailyMutation = useMutation({
    mutationFn: ({ id, twiceDaily }: { id: string; twiceDaily: boolean }) =>
      apiRequest("PATCH", `/api/load-assignments/${id}`, { twiceDaily }),
    onMutate: async ({ id, twiceDaily }) => {
      await queryClient.cancelQueries({ queryKey: ["/api/load-assignments"] });
      const previous = queryClient.getQueryData<LoadAssignment[]>(["/api/load-assignments"]);
      queryClient.setQueryData<LoadAssignment[]>(["/api/load-assignments"], old =>
        old?.map(a => a.id === id ? { ...a, twiceDaily } : a)
      );
      return { previous };
    },
    onError: (_err, _vars, context) => {
      if (context?.previous) queryClient.setQueryData(["/api/load-assignments"], context.previous);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
    },
  });

  const handleToggleTwiceDaily = (assignment: LoadAssignment) => {
    const newValue = !assignment.twiceDaily;
    toggleTwiceDailyMutation.mutate({ id: assignment.id, twiceDaily: newValue });
    toast({
      title: newValue ? "Set to twice daily" : "Set to once daily",
      description: `${assignment.mobName} will be fed ${newValue ? "twice" : "once"} per day`,
    });
  };

  const toggleFeedTimeMutation = useMutation({
    mutationFn: ({ id, feedTime }: { id: string; feedTime: "morning" | "afternoon" }) =>
      apiRequest("PATCH", `/api/load-assignments/${id}`, { feedTime }),
    onMutate: async ({ id, feedTime }) => {
      await queryClient.cancelQueries({ queryKey: ["/api/load-assignments"] });
      const previous = queryClient.getQueryData<LoadAssignment[]>(["/api/load-assignments"]);
      queryClient.setQueryData<LoadAssignment[]>(["/api/load-assignments"], old =>
        old?.map(a => a.id === id ? { ...a, feedTime } : a)
      );
      return { previous };
    },
    onError: (_err, _vars, context) => {
      if (context?.previous) queryClient.setQueryData(["/api/load-assignments"], context.previous);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
    },
  });

  const handleToggleFeedTime = (assignment: LoadAssignment) => {
    const newTime = assignment.feedTime === "morning" ? "afternoon" : "morning";
    toggleFeedTimeMutation.mutate({ id: assignment.id, feedTime: newTime });
    toast({
      title: `Set to ${newTime} feed`,
      description: `${assignment.mobName} will be fed in the ${newTime}`,
    });
  };

  const updateMultiplierMutation = useMutation({
    mutationFn: ({ id, feedMultiplier }: { id: string; feedMultiplier: number }) =>
      apiRequest("PATCH", `/api/mobs/${id}`, { feedMultiplier }),
    onMutate: async ({ id, feedMultiplier }) => {
      await queryClient.cancelQueries({ queryKey: ["/api/mobs"] });
      const previous = queryClient.getQueryData<Mob[]>(["/api/mobs"]);
      queryClient.setQueryData<Mob[]>(["/api/mobs"], old =>
        old?.map(m => m.id === id ? { ...m, feedMultiplier } : m)
      );
      return { previous };
    },
    onError: (_err, _vars, context) => {
      if (context?.previous) queryClient.setQueryData(["/api/mobs"], context.previous);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mobs"] });
    },
  });

  const updateGradualMutation = useMutation({
    mutationFn: ({ id, gradualPercentages }: { id: string; gradualPercentages: Record<string, GradualElementData> }) =>
      apiRequest("PATCH", `/api/mobs/${id}`, { gradualPercentages }),
    onMutate: async ({ id, gradualPercentages }) => {
      await queryClient.cancelQueries({ queryKey: ["/api/mobs"] });
      const previous = queryClient.getQueryData<Mob[]>(["/api/mobs"]);
      queryClient.setQueryData<Mob[]>(["/api/mobs"], old =>
        old?.map(m => m.id === id ? { ...m, gradualPercentages } : m)
      );
      return { previous };
    },
    onError: (_err, _vars, context) => {
      if (context?.previous) queryClient.setQueryData(["/api/mobs"], context.previous);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mobs"] });
    },
  });

  const handleGradualPercentageSave = (mob: Mob, elementName: string, percentage: number) => {
    const currentPercentages = (mob.gradualPercentages as Record<string, GradualElementData>) || {};
    const newPercentages = { 
      ...currentPercentages, 
      [elementName]: {
        percentage,
        updatedAt: new Date().toISOString(),
      }
    };
    updateGradualMutation.mutate({ id: mob.id, gradualPercentages: newPercentages });
    toast({
      title: "Percentage saved",
      description: `${elementName} set to ${percentage}%`,
    });
  };

  const gradualElements = elements?.filter(e => e.isGradual) || [];

  const handleBoost = (mobId: string, currentMultiplier: number, percentage: number) => {
    const newMultiplier = Math.max(0.1, currentMultiplier + percentage);
    updateMultiplierMutation.mutate({
      id: mobId,
      feedMultiplier: parseFloat(newMultiplier.toFixed(2)),
    });

    toast({
      title: percentage > 0 ? "Boosted feed" : "Reduced feed",
      description: `Multiplier adjusted to ${newMultiplier.toFixed(2)}x`,
    });
  };

  const moveAssignment = (assignmentId: string, direction: "up" | "down") => {
    const sortedAssignments = [...assignments].sort((a, b) => a.feedOrder - b.feedOrder);
    const currentIndex = sortedAssignments.findIndex(a => a.id === assignmentId);
    
    if (currentIndex === -1) return;
    if (direction === "up" && currentIndex === 0) return;
    if (direction === "down" && currentIndex === sortedAssignments.length - 1) return;

    const newIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;
    const currentAssignment = sortedAssignments[currentIndex];
    const swapAssignment = sortedAssignments[newIndex];

    reorderMutation.mutate({
      id: currentAssignment.id,
      feedOrder: newIndex,
      swapId: swapAssignment.id,
      swapFeedOrder: currentIndex,
    });

    toast({
      title: "Order updated",
      description: `Moved paddock ${direction}`,
    });
  };

  const isLoading = assignmentsLoading || !elements || !recipes || !mobs;

  const activeAssignments = assignments.filter(a => !skippedMobs.has(a.mobName));
  const hasTwiceDailyMobs = activeAssignments.some(a => a.twiceDaily);
  const hasAfternoonMobs = activeAssignments.some(a => a.feedTime === "afternoon" || a.twiceDaily);
  const needsSplitView = hasTwiceDailyMobs || hasAfternoonMobs;

  const calculateIngredients = (session?: "morning" | "afternoon"): { totals: IngredientTotal[], mobDetails: MobIngredients[] } => {
    if (!elements || !recipes || !mobs || !assignments) {
      return { totals: [], mobDetails: [] };
    }

    let sessionAssignments = activeAssignments;
    if (session === "morning") {
      sessionAssignments = activeAssignments.filter(a => a.twiceDaily || a.feedTime === "morning");
    } else if (session === "afternoon") {
      sessionAssignments = activeAssignments.filter(a => a.twiceDaily || a.feedTime === "afternoon");
    }

    const totalsMap = new Map<string, { unit: string; total: number }>();
    const mobDetails: MobIngredients[] = [];

    sessionAssignments.forEach(assignment => {
      const mob = mobs.find(m => m.name === assignment.mobName);
      if (!mob) return;

      const dailyFactor = (session && assignment.twiceDaily) ? 0.5 : 1;
      const mobIngredients: { elementName: string; unit: string; amount: number }[] = [];

      elements.forEach(element => {
        const recipe = recipes.find(r => 
          r.className === mob.className && r.elementName === element.name
        );
        
        if (recipe) {
          let amount;
          
          if (element.isGradual) {
            const gradualData = (mob.gradualPercentages as Record<string, { percentage: number; updatedAt: string }>) || {};
            const percentage = gradualData[element.name]?.percentage ?? 0;
            amount = recipe.rate * mob.headCount * (percentage / 100) * dailyFactor;
          } else {
            amount = recipe.rate * mob.headCount * mob.feedMultiplier * dailyFactor;
          }
          
          mobIngredients.push({
            elementName: element.name,
            unit: element.unit,
            amount
          });

          const existing = totalsMap.get(element.name);
          if (existing) {
            existing.total += amount;
          } else {
            totalsMap.set(element.name, { unit: element.unit, total: amount });
          }
        }
      });

      mobDetails.push({
        mob,
        multiplier: mob.feedMultiplier,
        ingredients: mobIngredients
      });
    });

    const totals = Array.from(totalsMap.entries())
      .map(([elementName, { unit, total }]) => ({
        elementName,
        unit,
        total
      }))
      .sort((a, b) => a.elementName.localeCompare(b.elementName));

    return { totals, mobDetails };
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" data-testid="loader-loading" />
      </div>
    );
  }

  const { totals, mobDetails } = calculateIngredients();
  const morningCalc = needsSplitView ? calculateIngredients("morning") : null;
  const afternoonCalc = needsSplitView ? calculateIngredients("afternoon") : null;
  
  const totalKgs = totals.reduce((sum, item) => sum + item.total, 0);
  const morningKgs = morningCalc?.totals.reduce((sum, item) => sum + item.total, 0) ?? 0;
  const afternoonKgs = afternoonCalc?.totals.reduce((sum, item) => sum + item.total, 0) ?? 0;

  const combinedTotals = (() => {
    if (!morningCalc || !afternoonCalc) return [];
    const map = new Map<string, { unit: string; total: number }>();
    morningCalc.totals.forEach(t => map.set(t.elementName, { unit: t.unit, total: t.total }));
    afternoonCalc.totals.forEach(t => {
      const existing = map.get(t.elementName);
      if (existing) existing.total += t.total;
      else map.set(t.elementName, { unit: t.unit, total: t.total });
    });
    return Array.from(map.entries())
      .map(([elementName, { unit, total }]) => ({ elementName, unit, total }))
      .sort((a, b) => a.elementName.localeCompare(b.elementName));
  })();
  const combinedKgs = combinedTotals.reduce((sum, t) => sum + t.total, 0);

  if (feedMode && activeAssignments && activeAssignments.length > 0) {
    const sessionAssignments = feedSession === "morning"
      ? activeAssignments.filter(a => a.twiceDaily || a.feedTime === "morning")
      : feedSession === "afternoon"
      ? activeAssignments.filter(a => a.twiceDaily || a.feedTime === "afternoon")
      : activeAssignments;

    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/cattle")}
              data-testid="button-back"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-foreground">
                {loadName} - Feed Mode
              </h1>
              <p className="text-sm text-muted-foreground">
                {feedSession ? `${feedSession === "morning" ? "Morning" : "Afternoon"} feed` : "Sequential paddock feeding"}
              </p>
            </div>
          </div>

          <FeedMode
            loadName={loadName}
            assignments={sessionAssignments}
            mobs={mobs}
            elements={elements}
            recipes={recipes}
            feedSession={feedSession}
            onComplete={() => { setFeedMode(false); setFeedSession(null); }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/cattle")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground" data-testid="text-load-name">
              {loadName}
            </h1>
            <p className="text-sm text-muted-foreground">
              {mobDetails.length} {mobDetails.length === 1 ? 'mob' : 'mobs'} assigned
            </p>
          </div>
        </div>

        {assignments.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center space-y-3">
              <AlertCircle className="w-12 h-12 mx-auto text-muted-foreground" />
              <p className="text-lg font-medium text-foreground">No mobs assigned to this load</p>
              <p className="text-muted-foreground">
                Use the management interface to assign mobs to this load
              </p>
            </CardContent>
          </Card>
        ) : (
          <>
            {needsSplitView ? (
              <div className="grid grid-cols-2 gap-3">
                <Button
                  size="lg"
                  className="h-14 text-base"
                  onClick={() => { setFeedSession("morning"); setFeedMode(true); }}
                  disabled={activeAssignments.filter(a => a.twiceDaily || a.feedTime === "morning").length === 0}
                  data-testid="button-start-morning-feed"
                >
                  <Sun className="w-5 h-5 mr-2" />
                  Morning Feed
                </Button>
                <Button
                  size="lg"
                  className="h-14 text-base"
                  onClick={() => { setFeedSession("afternoon"); setFeedMode(true); }}
                  disabled={activeAssignments.filter(a => a.twiceDaily || a.feedTime === "afternoon").length === 0}
                  data-testid="button-start-afternoon-feed"
                >
                  <Moon className="w-5 h-5 mr-2" />
                  Afternoon Feed
                </Button>
              </div>
            ) : (
              <Button
                size="lg"
                className="w-full h-14 text-lg"
                onClick={() => { setFeedSession(null); setFeedMode(true); }}
                disabled={activeAssignments.length === 0}
                data-testid="button-start-feed"
              >
                <CheckCircle2 className="w-6 h-6 mr-2" />
                Start Feed{skippedMobs.size > 0 ? ` (${activeAssignments.length} mobs)` : ""}
              </Button>
            )}
          <>
            {needsSplitView ? (
              <>
                <div className="flex gap-2">
                  <Button
                    variant={mixerView === "combined" ? "default" : "outline"}
                    className="flex-1 toggle-elevate"
                    onClick={() => setMixerView("combined")}
                    data-testid="button-view-combined"
                  >
                    <Layers className="w-4 h-4 mr-2" />
                    Combined Mixer Load
                  </Button>
                  <Button
                    variant={mixerView === "split" ? "default" : "outline"}
                    className="flex-1 toggle-elevate"
                    onClick={() => setMixerView("split")}
                    data-testid="button-view-split"
                  >
                    <Sun className="w-4 h-4 mr-1" />
                    /
                    <Moon className="w-4 h-4 ml-1 mr-2" />
                    Split View
                  </Button>
                </div>

                {mixerView === "combined" ? (
                  <Card>
                    <CardHeader className="pb-4">
                      <div className="flex items-center gap-2">
                        <Layers className="w-5 h-5 text-primary" />
                        <CardTitle className="text-xl">Combined Mixer Load</CardTitle>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Total for both morning + afternoon feeds in one mixer load
                      </p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {combinedTotals.filter(item => item.total > 0).map((item) => (
                        <div key={item.elementName} className="flex items-center justify-between p-4 rounded-md bg-muted/30" data-testid={`combined-total-${item.elementName}`}>
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-foreground">{item.elementName}</h3>
                            <p className="text-sm text-muted-foreground">{item.unit}</p>
                          </div>
                          <div className="text-right">
                            <div className="text-4xl font-mono font-semibold text-primary" data-testid={`combined-amount-${item.elementName}`}>{item.total.toFixed(1)}</div>
                            <div className="text-sm text-muted-foreground mt-1">{item.unit}</div>
                          </div>
                        </div>
                      ))}
                      <div className="p-5 rounded-lg bg-primary/10 border-2 border-primary/20" data-testid="combined-kgs-summary">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-semibold text-foreground">Total Mixer Load</h3>
                          <div className="text-right">
                            <div className="text-5xl font-mono font-bold text-primary" data-testid="combined-kgs-amount">{combinedKgs.toFixed(1)}</div>
                            <div className="text-sm font-medium text-muted-foreground mt-1">KG</div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <>
                    <Card>
                      <CardHeader className="pb-4">
                        <div className="flex items-center gap-2">
                          <Sun className="w-5 h-5 text-amber-500" />
                          <CardTitle className="text-xl">Morning Feed</CardTitle>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          All once-daily mobs at 100% + twice-daily mobs at 50%
                        </p>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {(morningCalc?.totals ?? []).filter(item => item.total > 0).map((item) => (
                          <div key={item.elementName} className="flex items-center justify-between p-3 rounded-md bg-muted/30" data-testid={`morning-total-${item.elementName}`}>
                            <div className="flex-1"><h3 className="text-base font-semibold text-foreground">{item.elementName}</h3></div>
                            <div className="text-right">
                              <span className="text-2xl font-mono font-semibold text-foreground">{item.total.toFixed(1)}</span>
                              <span className="ml-1 text-sm text-muted-foreground">{item.unit}</span>
                            </div>
                          </div>
                        ))}
                        <div className="p-5 rounded-lg bg-amber-500/10 border-2 border-amber-500/20" data-testid="morning-kgs-summary">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold text-foreground">Morning Load</h3>
                            <div className="text-right">
                              <div className="text-5xl font-mono font-bold text-amber-600" data-testid="morning-kgs-amount">{morningKgs.toFixed(1)}</div>
                              <div className="text-sm font-medium text-muted-foreground mt-1">KG</div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-4">
                        <div className="flex items-center gap-2">
                          <Moon className="w-5 h-5 text-indigo-500" />
                          <CardTitle className="text-xl">Afternoon Feed</CardTitle>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Twice-daily mobs only at 50%
                        </p>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {(afternoonCalc?.totals ?? []).filter(item => item.total > 0).map((item) => (
                          <div key={item.elementName} className="flex items-center justify-between p-3 rounded-md bg-muted/30" data-testid={`afternoon-total-${item.elementName}`}>
                            <div className="flex-1"><h3 className="text-base font-semibold text-foreground">{item.elementName}</h3></div>
                            <div className="text-right">
                              <span className="text-2xl font-mono font-semibold text-foreground">{item.total.toFixed(1)}</span>
                              <span className="ml-1 text-sm text-muted-foreground">{item.unit}</span>
                            </div>
                          </div>
                        ))}
                        <div className="p-5 rounded-lg bg-indigo-500/10 border-2 border-indigo-500/20" data-testid="afternoon-kgs-summary">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold text-foreground">Afternoon Load</h3>
                            <div className="text-right">
                              <div className="text-5xl font-mono font-bold text-indigo-600" data-testid="afternoon-kgs-amount">{afternoonKgs.toFixed(1)}</div>
                              <div className="text-sm font-medium text-muted-foreground mt-1">KG</div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </>
                )}
              </>
            ) : (
              <Card>
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl">Mixer Totals</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {totals.filter(item => item.total > 0).map((item) => (
                    <div
                      key={item.elementName}
                      className="flex items-center justify-between p-4 rounded-md bg-muted/30"
                      data-testid={`total-${item.elementName}`}
                    >
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-foreground">{item.elementName}</h3>
                        <p className="text-sm text-muted-foreground">{item.unit}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-4xl font-mono font-semibold text-primary" data-testid={`amount-${item.elementName}`}>
                          {item.total.toFixed(1)}
                        </div>
                        <div className="text-sm text-muted-foreground mt-1">{item.unit}</div>
                      </div>
                    </div>
                  ))}
                  <div className="p-5 rounded-lg bg-primary/10 border-2 border-primary/20" data-testid="total-kgs-summary">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-foreground">Total Load Weight</h3>
                      <div className="text-right">
                        <div className="text-5xl font-mono font-bold text-primary" data-testid="total-kgs-amount">
                          {totalKgs.toFixed(1)}
                        </div>
                        <div className="text-sm font-medium text-muted-foreground mt-1">KG</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="text-xl">Mob Breakdown</CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  Use arrows to reorder, tap Skip to exclude from today's feed
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                {(() => {
                  const sortedAssignments = [...assignments].sort((a, b) => a.feedOrder - b.feedOrder);
                  return sortedAssignments.map((assignment, idx) => {
                    const mob = mobs.find(m => m.name === assignment.mobName);
                    if (!mob) return null;
                    const isSkipped = skippedMobs.has(assignment.mobName);
                    const mobDetail = mobDetails.find(md => md.mob.name === assignment.mobName);
                    
                    return (
                      <div key={mob.id}>
                        {idx > 0 && <Separator className="my-4" />}
                        <div className={`space-y-3 ${isSkipped ? "opacity-50" : ""}`}>
                          <div>
                            <div className="flex items-start gap-3 mb-2">
                              <div className="flex flex-col gap-1 pt-1">
                                <Button
                                  size="icon"
                                  variant="outline"
                                  className="h-7 w-7"
                                  onClick={() => moveAssignment(assignment.id, "up")}
                                  disabled={idx === 0 || reorderMutation.isPending}
                                  data-testid={`button-move-up-${idx}`}
                                >
                                  <ChevronUp className="w-4 h-4" />
                                </Button>
                                <Button
                                  size="icon"
                                  variant="outline"
                                  className="h-7 w-7"
                                  onClick={() => moveAssignment(assignment.id, "down")}
                                  disabled={idx === sortedAssignments.length - 1 || reorderMutation.isPending}
                                  data-testid={`button-move-down-${idx}`}
                                >
                                  <ChevronDown className="w-4 h-4" />
                                </Button>
                              </div>
                              
                              <div className="flex-1 min-w-0">
                                <div className="flex items-start justify-between gap-3 mb-2">
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <Badge variant="secondary" className="text-xs">#{idx + 1}</Badge>
                                      <h3 className={`text-lg font-semibold ${isSkipped ? "line-through text-muted-foreground" : "text-foreground"}`} data-testid={`mob-name-${idx}`}>
                                        {mob.name}
                                      </h3>
                                      {isSkipped && (
                                        <Badge variant="destructive" className="text-xs">
                                          Skipped
                                        </Badge>
                                      )}
                                      {!isSkipped && assignment.twiceDaily && (
                                        <Badge variant="outline" className="text-xs">
                                          <RefreshCw className="w-3 h-3 mr-1" />
                                          2x Daily
                                        </Badge>
                                      )}
                                      {!isSkipped && !assignment.twiceDaily && assignment.feedTime === "afternoon" && (
                                        <Badge variant="outline" className="text-xs">
                                          <Moon className="w-3 h-3 mr-1" />
                                          PM
                                        </Badge>
                                      )}
                                    </div>
                                    <p className="text-sm text-muted-foreground">
                                      {mob.paddock}
                                    </p>
                                  </div>
                                  <div className="flex gap-2 flex-wrap justify-end items-center">
                                    <Button
                                      variant={assignment.twiceDaily ? "default" : "outline"}
                                      size="sm"
                                      className="toggle-elevate"
                                      onClick={() => handleToggleTwiceDaily(assignment)}
                                      disabled={isSkipped || toggleTwiceDailyMutation.isPending}
                                      data-testid={`button-twice-daily-${idx}`}
                                    >
                                      <RefreshCw className="w-4 h-4 mr-1" />
                                      {assignment.twiceDaily ? "2x Daily" : "1x Daily"}
                                    </Button>
                                    {!assignment.twiceDaily && (
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="toggle-elevate"
                                        onClick={() => handleToggleFeedTime(assignment)}
                                        disabled={isSkipped || toggleFeedTimeMutation.isPending}
                                        data-testid={`button-feed-time-${idx}`}
                                      >
                                        {assignment.feedTime === "morning" ? (
                                          <><Sun className="w-4 h-4 mr-1" />AM</>
                                        ) : (
                                          <><Moon className="w-4 h-4 mr-1" />PM</>
                                        )}
                                      </Button>
                                    )}
                                    <Button
                                      variant={isSkipped ? "default" : "outline"}
                                      size="sm"
                                      onClick={() => toggleSkipMob(assignment.mobName)}
                                      data-testid={`button-skip-mob-${idx}`}
                                    >
                                      {isSkipped ? (
                                        <>
                                          <CheckCircle2 className="w-4 h-4 mr-1" />
                                          Include
                                        </>
                                      ) : (
                                        <>
                                          <XCircle className="w-4 h-4 mr-1" />
                                          Skip
                                        </>
                                      )}
                                    </Button>
                                  </div>
                                </div>
                                {!isSkipped && (
                                  <>
                                    <div className="flex gap-2 flex-wrap items-center mb-1">
                                      <Badge variant="secondary" data-testid={`badge-head-${idx}`}>
                                        {mob.headCount} head
                                      </Badge>
                                      <div className="flex items-center gap-1">
                                        <Button
                                          size="icon"
                                          variant="outline"
                                          className="h-6 w-6"
                                          onClick={() => handleBoost(mob.id, mob.feedMultiplier, -0.05)}
                                          disabled={updateMultiplierMutation.isPending}
                                          data-testid={`button-reduce-multiplier-${idx}`}
                                        >
                                          <ChevronDown className="w-3 h-3" />
                                        </Button>
                                        <Badge variant="outline" data-testid={`badge-multiplier-${idx}`}>
                                          x{mob.feedMultiplier.toFixed(2)}
                                        </Badge>
                                        <Button
                                          size="icon"
                                          variant="outline"
                                          className="h-6 w-6"
                                          onClick={() => handleBoost(mob.id, mob.feedMultiplier, 0.05)}
                                          disabled={updateMultiplierMutation.isPending}
                                          data-testid={`button-boost-multiplier-${idx}`}
                                        >
                                          <ChevronUp className="w-3 h-3" />
                                        </Button>
                                      </div>
                                    </div>
                                    <p className="text-xs text-muted-foreground">
                                      Class: {mob.className}
                                    </p>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                      
                          {!isSkipped && mobDetail && (
                            <>
                              <div className="grid grid-cols-2 gap-2 pl-2">
                                {mobDetail.ingredients
                                  .filter(ing => ing.amount > 0)
                                  .map((ing) => (
                                    <div
                                      key={ing.elementName}
                                      className="text-sm"
                                      data-testid={`mob-${idx}-ingredient-${ing.elementName}`}
                                    >
                                      <span className="text-muted-foreground">{ing.elementName}:</span>
                                      <span className="ml-2 font-mono font-medium text-foreground">
                                        {ing.amount.toFixed(1)}
                                      </span>
                                      <span className="ml-1 text-xs text-muted-foreground">
                                        {ing.unit}
                                      </span>
                                    </div>
                                  ))}
                              </div>

                              {gradualElements.length > 0 && (
                                <div className="mt-3 pt-3 border-t border-border space-y-3 pl-2">
                                  <div className="flex items-center gap-2">
                                    <Clock className="w-4 h-4 text-amber-600" />
                                    <span className="text-sm font-medium text-muted-foreground">
                                      Gradual Introduction Elements
                                    </span>
                                  </div>
                                  {gradualElements.map((element) => (
                                    <GradualPercentageControl
                                      key={element.name}
                                      mob={mob}
                                      element={element}
                                      recipes={recipes || []}
                                      onSave={handleGradualPercentageSave}
                                    />
                                  ))}
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      </div>
                    );
                  });
                })()}
              </CardContent>
            </Card>
          </>
          </>
        )}
      </div>
    </div>
  );
}
