import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowLeft, Clock, ChevronRight } from "lucide-react";
import { useLocation } from "wouter";
import type { FeedHistory } from "@shared/cattleSchema";
import { format } from "date-fns";
import { useState } from "react";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

export default function History() {
  const [, setLocation] = useLocation();
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());

  const { data: history, isLoading } = useQuery<FeedHistory[]>({
    queryKey: ["/api/feed-history"],
  });

  const toggleExpanded = (id: string) => {
    setExpandedIds((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/cattle")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Feed History</h1>
            <p className="text-sm text-muted-foreground">
              Complete record of all feeding activities
            </p>
          </div>
        </div>

        {!history || history.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Clock className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-lg font-medium text-foreground">No feeding records yet</p>
              <p className="text-muted-foreground">
                Start feeding loads to see history appear here
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {history.map((record) => {
              const isExpanded = expandedIds.has(record.id);
              return (
                <Collapsible
                  key={record.id}
                  open={isExpanded}
                  onOpenChange={() => toggleExpanded(record.id)}
                >
                  <Card
                    className="hover-elevate active-elevate-2 cursor-pointer"
                    data-testid={`history-record-${record.id}`}
                  >
                    <CollapsibleTrigger asChild>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <ChevronRight
                              className={`w-5 h-5 text-muted-foreground shrink-0 transition-transform ${
                                isExpanded ? "rotate-90" : ""
                              }`}
                            />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap mb-1">
                                <Badge variant="secondary" className="shrink-0">
                                  {record.feederName}
                                </Badge>
                                <Badge variant="outline" className="shrink-0">
                                  {record.loadName}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <Clock className="w-3.5 h-3.5 shrink-0" />
                                <span className="truncate">
                                  {format(new Date(record.timestamp), "MMM d, yyyy 'at' h:mm a")}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="text-right shrink-0">
                            <div className="text-2xl font-mono font-bold text-primary">
                              {record.totalKg.toFixed(1)}
                            </div>
                            <p className="text-xs text-muted-foreground">kg</p>
                          </div>
                        </div>
                      </CardContent>
                    </CollapsibleTrigger>

                    <CollapsibleContent>
                      <div className="px-4 pb-4 pt-0 space-y-3 border-t mt-2">
                        <div className="grid grid-cols-2 gap-3 pt-3">
                          <div>
                            <p className="text-xs text-muted-foreground">Paddock</p>
                            <p className="text-sm font-medium">{record.paddock}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Mob</p>
                            <p className="text-sm font-medium truncate">{record.mobName}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Multiplier</p>
                            <p className="text-sm font-medium">×{record.feedMultiplier.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Total Fed</p>
                            <p className="text-sm font-medium">{record.totalKg.toFixed(1)} kg</p>
                          </div>
                        </div>

                        {record.ingredients && Object.keys(record.ingredients).length > 0 && (
                          <div className="pt-2 border-t">
                            <p className="text-xs text-muted-foreground mb-2">Ingredient Breakdown</p>
                            <div className="grid grid-cols-2 gap-2">
                              {Object.entries(record.ingredients)
                                .sort(([a], [b]) => a.localeCompare(b))
                                .map(([ingredient, amount]) => (
                                  <div
                                    key={ingredient}
                                    className="flex items-center justify-between px-2 py-1.5 rounded bg-muted/20"
                                    data-testid={`ingredient-${ingredient}`}
                                  >
                                    <p className="text-xs font-medium text-foreground">{ingredient}</p>
                                    <p className="text-sm font-mono font-semibold">
                                      {amount.toFixed(1)}
                                    </p>
                                  </div>
                                ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CollapsibleContent>
                  </Card>
                </Collapsible>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
