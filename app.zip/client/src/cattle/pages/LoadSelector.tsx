import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, ArrowRight, Clock, Settings, User, Beef } from "lucide-react";
import { useLocation } from "wouter";
import type { Load, LoadAssignment, Mob } from "@shared/cattleSchema";
import logoUrl from "@assets/logo new_1761128920148.jpg";

export default function LoadSelector() {
  const [, setLocation] = useLocation();
  const [feederName, setFeederName] = useState("");

  // Load feeder name from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("feederName");
    if (saved) setFeederName(saved);
  }, []);

  // Save feeder name to localStorage when it changes
  const handleFeederNameChange = (value: string) => {
    setFeederName(value);
    localStorage.setItem("feederName", value);
  };

  const { data: loads, isLoading: loadsLoading } = useQuery<Load[]>({
    queryKey: ["/api/loads"],
  });

  const { data: assignments, isLoading: assignmentsLoading } = useQuery<LoadAssignment[]>({
    queryKey: ["/api/load-assignments"],
  });

  const { data: mobsData, isLoading: mobsLoading } = useQuery<Mob[]>({
    queryKey: ["/api/mobs"],
  });

  const isLoading = loadsLoading || assignmentsLoading || mobsLoading;

  const getMobCount = (loadName: string) => {
    if (!assignments || !mobsData) return 0;
    const mobNames = new Set(mobsData.map(m => m.name));
    return assignments.filter(a => a.loadName === loadName && mobNames.has(a.mobName)).length;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" data-testid="loader-loading" />
      </div>
    );
  }

  const sortedLoads = [...(loads || [])].sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));

  // Total cattle on feed: sum headCounts of all unique mobs assigned to any load
  const totalCattleOnFeed = (() => {
    if (!assignments || !mobsData) return 0;
    const assignedMobNames = new Set(assignments.map(a => a.mobName));
    return mobsData
      .filter(m => assignedMobNames.has(m.name))
      .reduce((sum, m) => sum + m.headCount, 0);
  })();

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <img src={logoUrl} alt="Kurra-Wirra Logo" className="w-12 h-12 object-contain rounded" />
            <h1 className="text-2xl font-bold text-foreground" data-testid="text-title">
              Kurra-Wirra Cattle Feedlot Manager
            </h1>
          </div>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="w-5 h-5" />
                Your Name
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label htmlFor="feeder-name">Feeder Name</Label>
                <Input
                  id="feeder-name"
                  type="text"
                  placeholder="Enter your name"
                  value={feederName}
                  onChange={(e) => handleFeederNameChange(e.target.value)}
                  className="text-lg h-12"
                  data-testid="input-feeder-name"
                />
                <p className="text-sm text-muted-foreground">
                  This name will be used for all feeding records
                </p>
              </div>
            </CardContent>
          </Card>

          <p className="text-base text-muted-foreground">
            Select a load to view ingredient totals for the mixer wagon
          </p>

          <Card>
            <CardContent className="py-4 px-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Beef className="w-5 h-5" />
                  <span className="text-sm font-medium">Total Cattle on Feed</span>
                </div>
                <span className="text-3xl font-mono font-bold text-foreground" data-testid="text-total-cattle">
                  {totalCattleOnFeed.toLocaleString()}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {sortedLoads.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground">No loads configured. Use the management tab to create loads.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {sortedLoads.map((load) => {
              const mobCount = getMobCount(load.name);
              return (
                <Card
                  key={load.id}
                  className="hover-elevate active-elevate-2 cursor-pointer transition-all"
                  onClick={() => setLocation(`/cattle/load/${encodeURIComponent(load.name)}`)}
                  data-testid={`card-load-${load.name}`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h2 className="text-2xl font-semibold text-foreground mb-2">
                          {load.name}
                        </h2>
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="secondary" className="text-sm" data-testid={`badge-mob-count-${load.name}`}>
                            {mobCount} {mobCount === 1 ? 'mob' : 'mobs'}
                          </Badge>
                        </div>
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="shrink-0"
                        data-testid={`button-view-${load.name}`}
                      >
                        <ArrowRight className="w-6 h-6" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <div className="pt-4 grid grid-cols-2 gap-3">
          <Button
            variant="outline"
            size="lg"
            onClick={() => setLocation("/cattle/history")}
            data-testid="button-history"
          >
            <Clock className="w-5 h-5 mr-2" />
            History
          </Button>
          <Button
            variant="outline"
            size="lg"
            onClick={() => setLocation("/cattle/manage")}
            data-testid="button-manage"
          >
            <Settings className="w-5 h-5 mr-2" />
            Manage
          </Button>
        </div>
      </div>
    </div>
  );
}
