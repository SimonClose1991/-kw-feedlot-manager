import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import type { Mob, Element, GradualElementData, Recipe } from "@shared/cattleSchema";

interface GradualPercentageControlProps {
  mob: Mob;
  element: Element;
  recipes: Recipe[];
  onSave: (mob: Mob, elementName: string, percentage: number) => void;
}

export function GradualPercentageControl({ 
  mob, 
  element, 
  recipes,
  onSave 
}: GradualPercentageControlProps) {
  const gradualData = (mob.gradualPercentages as Record<string, GradualElementData>) || {};
  const elementData = gradualData[element.name];
  const savedPercentage = elementData?.percentage ?? 0;
  const updatedAt = elementData?.updatedAt;
  
  const recipe = recipes?.find(r => r.className === mob.className && r.elementName === element.name);
  const baseRate = recipe?.rate ?? 0;
  
  const [localValue, setLocalValue] = useState(savedPercentage);
  const [inputValue, setInputValue] = useState(savedPercentage.toString());
  
  const kgPerHead = baseRate * (localValue / 100);
  
  useEffect(() => {
    setLocalValue(savedPercentage);
    setInputValue(savedPercentage.toString());
  }, [savedPercentage]);
  
  const handleInputBlur = () => {
    const parsed = Math.min(100, Math.max(0, parseInt(inputValue) || 0));
    if (parsed !== savedPercentage) {
      onSave(mob, element.name, parsed);
    }
    setLocalValue(parsed);
    setInputValue(parsed.toString());
  };
  
  const handleSliderChange = (value: number[]) => {
    setLocalValue(value[0]);
    setInputValue(value[0].toString());
  };
  
  const handleSliderCommit = (value: number[]) => {
    if (value[0] !== savedPercentage) {
      onSave(mob, element.name, value[0]);
    }
  };
  
  const formatDate = (isoDate: string) => {
    const date = new Date(isoDate);
    return date.toLocaleDateString(undefined, { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  return (
    <div className="space-y-2" data-testid={`gradual-${mob.name}-${element.name}`}>
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex flex-col">
          <span className="text-sm font-medium">{element.name}</span>
          {updatedAt && (
            <span className="text-xs text-muted-foreground">
              Updated: {formatDate(updatedAt)}
            </span>
          )}
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm font-mono font-semibold text-primary" data-testid={`kg-gradual-${mob.name}-${element.name}`}>
            {kgPerHead.toFixed(1)} {element.unit === "kg/head" ? "kg" : "L"}/head
          </span>
          <div className="flex items-center gap-1">
            <Input
              type="number"
              min="0"
              max="100"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onBlur={handleInputBlur}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  (e.target as HTMLInputElement).blur();
                }
              }}
              className="w-16 h-8 text-right font-mono"
              data-testid={`input-gradual-${mob.name}-${element.name}`}
            />
            <span className="text-sm text-muted-foreground">%</span>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Slider
          value={[localValue]}
          min={0}
          max={100}
          step={5}
          onValueChange={handleSliderChange}
          onValueCommit={handleSliderCommit}
          className="flex-1"
          data-testid={`slider-gradual-${mob.name}-${element.name}`}
        />
      </div>
    </div>
  );
}
