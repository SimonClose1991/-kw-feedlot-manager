import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { CheckCircle2, ChevronUp, ChevronDown, List, Check, Circle, ArrowLeft } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Element, Mob, Recipe, LoadAssignment, InsertFeedHistory } from "@shared/cattleSchema";

interface FeedModeProps {
  loadName: string;
  assignments: LoadAssignment[];
  mobs: Mob[];
  elements: Element[];
  recipes: Recipe[];
  feedSession?: "morning" | "afternoon" | null;
  onComplete: () => void;
}

export default function FeedMode({
  loadName,
  assignments,
  mobs,
  elements,
  recipes,
  feedSession,
  onComplete,
}: FeedModeProps) {
  const { toast } = useToast();
  const [feederName, setFeederName] = useState<string>("");
  const [feedingStarted, setFeedingStarted] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [fedPaddocks, setFedPaddocks] = useState<Set<string>>(new Set());
  const [loadComplete, setLoadComplete] = useState(false);

  // Load feeder name from localStorage and auto-start if available
  useEffect(() => {
    const saved = localStorage.getItem("feederName");
    if (saved && saved.trim()) {
      setFeederName(saved);
      setFeedingStarted(true);
    }
  }, []);

  const mobNames = new Set(mobs.map(m => m.name));
  const validAssignments = assignments.filter(a => mobNames.has(a.mobName));
  const sortedAssignments = [...validAssignments].sort((a, b) => a.feedOrder - b.feedOrder);
  const currentAssignment = sortedAssignments[currentIndex];
  const currentMob = currentAssignment ? mobs.find(m => m.name === currentAssignment.mobName) : null;
  const progress = sortedAssignments.length > 0 ? (fedPaddocks.size / sortedAssignments.length) * 100 : 0;

  const updateMultiplierMutation = useMutation({
    mutationFn: ({ id, feedMultiplier }: { id: string; feedMultiplier: number }) =>
      apiRequest("PATCH", `/api/mobs/${id}`, { feedMultiplier }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mobs"] });
    },
  });

  const recordFeedMutation = useMutation({
    mutationFn: (data: InsertFeedHistory) =>
      apiRequest("POST", "/api/feed-history", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/feed-history"] });
    },
  });

  const reorderMutation = useMutation({
    mutationFn: ({ id, feedOrder }: { id: string; feedOrder: number }) =>
      apiRequest("PATCH", `/api/load-assignments/${id}`, { feedOrder }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
    },
  });

  const calculatePaddockTotals = () => {
    if (!currentMob || !currentAssignment) return { totals: [], totalKg: 0 };

    const dailyFactor = (feedSession && currentAssignment.twiceDaily) ? 0.5 : 1;
    const totals: { elementName: string; unit: string; total: number }[] = [];
    let totalKg = 0;

    elements.forEach(element => {
      const recipe = recipes.find(r => 
        r.className === currentMob.className && r.elementName === element.name
      );
      
      if (recipe && recipe.rate > 0) {
        let total;
        
        if (element.isGradual) {
          const gradualData = (currentMob.gradualPercentages as Record<string, { percentage: number; updatedAt: string }>) || {};
          const percentage = gradualData[element.name]?.percentage ?? 0;
          total = recipe.rate * currentMob.headCount * (percentage / 100) * dailyFactor;
        } else {
          total = recipe.rate * currentMob.headCount * currentMob.feedMultiplier * dailyFactor;
        }
        
        totals.push({
          elementName: element.name,
          unit: element.unit,
          total
        });
        
        totalKg += total;
      }
    });

    return {
      totals: totals.sort((a, b) => a.elementName.localeCompare(b.elementName)),
      totalKg
    };
  };

  const handleBoost = (percentage: number) => {
    if (!currentMob) return;
    
    const newMultiplier = Math.max(0.1, currentMob.feedMultiplier + percentage);
    updateMultiplierMutation.mutate({
      id: currentMob.id,
      feedMultiplier: parseFloat(newMultiplier.toFixed(2)),
    });

    toast({
      title: percentage > 0 ? "Boosted feed" : "Reduced feed",
      description: `Multiplier adjusted to ${newMultiplier.toFixed(2)}x`,
    });
  };

  const handleFed = () => {
    if (!currentAssignment || !currentMob) return;

    const { totals, totalKg } = calculatePaddockTotals();

    // Convert totals array to ingredients object
    const ingredients: Record<string, number> = {};
    totals.forEach(item => {
      ingredients[item.elementName] = item.total;
    });

    // Record to history
    recordFeedMutation.mutate({
      feederName,
      loadName,
      mobName: currentAssignment.mobName,
      paddock: currentMob.paddock,
      feedMultiplier: currentMob.feedMultiplier,
      totalKg,
      ingredients,
    });

    setFedPaddocks(prev => new Set(prev).add(currentAssignment.mobName));

    if (currentIndex < sortedAssignments.length - 1) {
      setCurrentIndex(prev => prev + 1);
      toast({
        title: "Paddock marked as fed",
        description: "Moving to next paddock...",
      });
    } else {
      setLoadComplete(true);
      toast({
        title: "All paddocks processed!",
        description: "Ready to finish load",
      });
    }
  };

  const handleSkip = () => {
    if (!currentAssignment) return;

    if (currentIndex < sortedAssignments.length - 1) {
      setCurrentIndex(prev => prev + 1);
      toast({
        title: "Paddock skipped",
        description: "Moving to next paddock...",
      });
    } else {
      setLoadComplete(true);
      toast({
        title: "All paddocks processed!",
        description: "Ready to finish load",
      });
    }
  };

  const handleGoBack = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      toast({
        title: "Went back",
        description: "Returned to previous paddock",
      });
    }
  };

  const handleStartFeeding = () => {
    if (!feederName.trim()) {
      toast({
        title: "Name required",
        description: "Please enter your name before starting",
        variant: "destructive",
      });
      return;
    }
    setFeedingStarted(true);
  };

  const moveAssignment = (assignmentId: string, direction: "up" | "down") => {
    const currentIdx = sortedAssignments.findIndex(a => a.id === assignmentId);
    
    if (currentIdx === -1) return;
    if (direction === "up" && currentIdx === 0) return;
    if (direction === "down" && currentIdx === sortedAssignments.length - 1) return;

    const newIdx = direction === "up" ? currentIdx - 1 : currentIdx + 1;
    const currentAssignment = sortedAssignments[currentIdx];
    const swapAssignment = sortedAssignments[newIdx];

    reorderMutation.mutate({ id: currentAssignment.id, feedOrder: newIdx });
    reorderMutation.mutate({ id: swapAssignment.id, feedOrder: currentIdx });

    // Update current index if we're moving the current paddock
    if (currentIdx === currentIndex) {
      setCurrentIndex(newIdx);
    } else if (newIdx === currentIndex) {
      setCurrentIndex(currentIdx);
    }

    toast({
      title: "Order updated",
      description: `Moved paddock ${direction}`,
    });
  };

  // Show feeder name input first
  if (!feedingStarted) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Who is feeding today?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="feeder-name">Feeder Name</Label>
            <Input
              id="feeder-name"
              type="text"
              placeholder="Enter your name"
              value={feederName}
              onChange={(e) => setFeederName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleStartFeeding();
              }}
              data-testid="input-feeder-name"
            />
          </div>
          <div className="flex gap-3">
            <Button
              className="flex-1"
              onClick={handleStartFeeding}
              data-testid="button-start-feeding"
            >
              Start Feeding
            </Button>
            <Button
              variant="outline"
              onClick={onComplete}
              data-testid="button-cancel-feed"
            >
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Show completion screen when all paddocks are processed
  if (loadComplete) {
    const skippedCount = sortedAssignments.length - fedPaddocks.size;
    
    return (
      <Card className="border-2 border-primary">
        <CardHeader className="text-center pb-4">
          <div className="mx-auto mb-4 w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <CheckCircle2 className="w-10 h-10 text-primary" />
          </div>
          <CardTitle className="text-2xl">Load Complete!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-muted/30 text-center">
              <div className="text-3xl font-mono font-bold text-primary" data-testid="text-fed-count">
                {fedPaddocks.size}
              </div>
              <p className="text-sm text-muted-foreground mt-1">Paddocks Fed</p>
            </div>
            <div className="p-4 rounded-lg bg-muted/30 text-center">
              <div className="text-3xl font-mono font-bold text-muted-foreground" data-testid="text-skipped-count">
                {skippedCount}
              </div>
              <p className="text-sm text-muted-foreground mt-1">Paddocks Skipped</p>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-muted/30">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-foreground">Load</p>
              <p className="text-sm font-mono text-foreground">{loadName}</p>
            </div>
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-foreground">Feeder</p>
              <Badge variant="secondary">{feederName}</Badge>
            </div>
          </div>

          <Button
            size="lg"
            className="w-full h-14 text-lg"
            onClick={onComplete}
            data-testid="button-finish-load"
          >
            <CheckCircle2 className="w-6 h-6 mr-2" />
            Finish Load
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (!currentMob || !currentAssignment) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-muted-foreground">No paddocks to feed in this load</p>
          <Button onClick={onComplete} className="mt-4" data-testid="button-exit-feed">
            Exit Feed Mode
          </Button>
        </CardContent>
      </Card>
    );
  }

  const { totals: paddockTotals, totalKg } = calculatePaddockTotals();
  const isFed = fedPaddocks.has(currentAssignment.mobName);

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-muted-foreground">
            Paddock {currentIndex + 1} of {sortedAssignments.length}
          </h3>
          <Badge variant="secondary">
            {fedPaddocks.size} fed
          </Badge>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {currentIndex > 0 && (
        <Button
          variant="outline"
          size="lg"
          className="w-full h-12"
          onClick={handleGoBack}
          data-testid="button-go-back"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Go Back to {(() => {
            const prevAssignment = sortedAssignments[currentIndex - 1];
            const prevMob = prevAssignment ? mobs.find(m => m.name === prevAssignment.mobName) : null;
            return prevMob?.paddock || "Previous Paddock";
          })()}
        </Button>
      )}

      <Card className="border-2 border-primary">
        <CardHeader className="pb-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl" data-testid="text-current-paddock">
                {currentMob.paddock}
              </CardTitle>
              <Badge variant="secondary" className="text-sm">
                Feeder: {feederName}
              </Badge>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="secondary">{currentMob.className}</Badge>
              <Badge variant="outline">{currentMob.headCount} head</Badge>
              <Badge variant="outline" data-testid="badge-multiplier">
                ×{currentMob.feedMultiplier.toFixed(2)}
              </Badge>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="text-center p-6 bg-primary/10 rounded-lg border-2 border-primary/20">
            <p className="text-sm font-medium text-muted-foreground mb-2">Total Feed</p>
            <div className="text-6xl font-mono font-bold text-primary" data-testid="text-total-kg">
              {totalKg.toFixed(1)}
            </div>
            <p className="text-lg font-medium text-muted-foreground mt-2">kg</p>
          </div>

          <div className="space-y-1">
            <h4 className="font-semibold text-xs text-muted-foreground mb-1">Breakdown</h4>
            <div className="grid grid-cols-2 gap-1.5">
              {paddockTotals
                .filter(item => item.total > 0)
                .map((item) => (
                  <div
                    key={item.elementName}
                    className="flex items-center justify-between px-2 py-1.5 rounded bg-muted/20"
                    data-testid={`paddock-total-${item.elementName}`}
                  >
                    <p className="text-xs font-medium text-foreground">{item.elementName}</p>
                    <p className="text-sm font-mono font-semibold text-foreground">
                      {item.total.toFixed(1)}
                    </p>
                  </div>
                ))}
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-sm text-muted-foreground">Adjust Feed Amount</h4>
            <div className="grid grid-cols-2 gap-3">
              <Button
                size="lg"
                onClick={() => handleBoost(-0.05)}
                disabled={updateMultiplierMutation.isPending}
                className="h-14 bg-blue-600 hover:bg-blue-700 text-white"
                data-testid="button-reduce"
              >
                <ChevronDown className="w-5 h-5 mr-2" />
                Reduce 5%
              </Button>
              <Button
                size="lg"
                onClick={() => handleBoost(0.05)}
                disabled={updateMultiplierMutation.isPending}
                className="h-14 bg-blue-600 hover:bg-blue-700 text-white"
                data-testid="button-boost"
              >
                <ChevronUp className="w-5 h-5 mr-2" />
                Boost 5%
              </Button>
            </div>
          </div>

          <Button
            size="lg"
            className="w-full h-16 text-lg"
            onClick={handleFed}
            disabled={isFed}
            data-testid="button-fed"
          >
            {isFed ? (
              <>
                <CheckCircle2 className="w-6 h-6 mr-2" />
                Fed
              </>
            ) : (
              <>
                <CheckCircle2 className="w-6 h-6 mr-2" />
                Mark as Fed
              </>
            )}
          </Button>

          <Button
            variant="outline"
            size="lg"
            className="w-full h-14"
            onClick={handleSkip}
            data-testid="button-skip"
          >
            Skip Paddock
          </Button>
        </CardContent>
      </Card>

      <Button
        variant="outline"
        onClick={onComplete}
        className="w-full"
        data-testid="button-exit-feed"
      >
        Exit Feed Mode
      </Button>

      {/* Mob Summary Section */}
      <Collapsible defaultOpen={true}>
        <Card>
          <CollapsibleTrigger className="w-full" data-testid="button-toggle-mob-summary">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <List className="w-5 h-5" />
                  <CardTitle className="text-lg">All Paddocks ({sortedAssignments.length})</CardTitle>
                </div>
                <Badge variant="secondary">
                  {fedPaddocks.size}/{sortedAssignments.length} fed
                </Badge>
              </div>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="space-y-2">
              {sortedAssignments.map((assignment, idx) => {
                const mob = mobs.find(m => m.name === assignment.mobName);
                if (!mob) return null;
                
                const isCurrent = idx === currentIndex;
                const isFedPaddock = fedPaddocks.has(assignment.mobName);
                const isPending = !isCurrent && !isFedPaddock && idx > currentIndex;
                
                return (
                  <div
                    key={assignment.id}
                    className={`p-3 rounded-lg border-2 ${
                      isCurrent 
                        ? "border-primary bg-primary/10" 
                        : isFedPaddock 
                        ? "border-green-500/30 bg-green-500/5" 
                        : "border-border bg-muted/20"
                    }`}
                    data-testid={`mob-summary-${idx}`}
                  >
                    <div className="flex items-center gap-2">
                      {/* Reorder Controls */}
                      <div className="flex flex-col gap-1 flex-shrink-0">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-5 w-5 p-0"
                          onClick={() => moveAssignment(assignment.id, "up")}
                          disabled={idx === 0 || reorderMutation.isPending}
                          data-testid={`button-move-up-feed-${idx}`}
                        >
                          <ChevronUp className="w-3 h-3" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-5 w-5 p-0"
                          onClick={() => moveAssignment(assignment.id, "down")}
                          disabled={idx === sortedAssignments.length - 1 || reorderMutation.isPending}
                          data-testid={`button-move-down-feed-${idx}`}
                        >
                          <ChevronDown className="w-3 h-3" />
                        </Button>
                      </div>

                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="flex-shrink-0">
                          {isFedPaddock ? (
                            <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
                              <Check className="w-4 h-4 text-white" />
                            </div>
                          ) : isCurrent ? (
                            <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                              <Circle className="w-3 h-3 text-white fill-white" />
                            </div>
                          ) : (
                            <div className="w-6 h-6 rounded-full border-2 border-muted-foreground/30" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={`font-semibold truncate ${isCurrent ? "text-primary" : "text-foreground"}`}>
                            {mob.paddock}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">
                            {mob.className} · {mob.headCount} head · ×{mob.feedMultiplier.toFixed(2)}
                          </p>
                        </div>
                      </div>
                      <Badge variant={isCurrent ? "default" : "outline"} className="flex-shrink-0">
                        #{idx + 1}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>
    </div>
  );
}
