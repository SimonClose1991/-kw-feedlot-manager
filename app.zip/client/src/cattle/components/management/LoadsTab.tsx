import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Plus, Trash2, Loader2, ChevronUp, ChevronDown, Pencil, Check, X } from "lucide-react";
import type { Load, LoadAssignment, Mob, InsertLoad, InsertLoadAssignment } from "@shared/cattleSchema";

export default function LoadsTab() {
  const { toast } = useToast();
  const [newLoadName, setNewLoadName] = useState("");
  const [selectedLoad, setSelectedLoad] = useState<string>("");
  const [selectedMob, setSelectedMob] = useState<string>("");
  const [multiplier, setMultiplier] = useState<string>("1.0");
  const [editingLoadId, setEditingLoadId] = useState<string | null>(null);
  const [editingLoadName, setEditingLoadName] = useState<string>("");

  const { data: loads, isLoading: loadsLoading } = useQuery<Load[]>({
    queryKey: ["/api/loads"],
  });

  const { data: mobs, isLoading: mobsLoading } = useQuery<Mob[]>({
    queryKey: ["/api/mobs"],
  });

  const { data: assignments, isLoading: assignmentsLoading } = useQuery<LoadAssignment[]>({
    queryKey: ["/api/load-assignments"],
  });

  const createLoadMutation = useMutation({
    mutationFn: (data: InsertLoad) => apiRequest("POST", "/api/loads", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/loads"] });
      setNewLoadName("");
      toast({
        title: "Load created",
        description: "New load has been created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create load. Name may already exist.",
        variant: "destructive",
      });
    },
  });

  const deleteLoadMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/loads/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/loads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
      toast({
        title: "Load deleted",
        description: "The load has been removed.",
      });
    },
  });

  const createAssignmentMutation = useMutation({
    mutationFn: (data: InsertLoadAssignment) => apiRequest("POST", "/api/load-assignments", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
      setSelectedMob("");
      setMultiplier("1.0");
      toast({
        title: "Mob assigned",
        description: "Mob has been assigned to the load.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to assign mob. It may already be in this load.",
        variant: "destructive",
      });
    },
  });

  const deleteAssignmentMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/load-assignments/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
      toast({
        title: "Assignment removed",
        description: "Mob has been removed from the load.",
      });
    },
  });

  const reorderMutation = useMutation({
    mutationFn: ({ id, feedOrder }: { id: string; feedOrder: number }) =>
      apiRequest("PATCH", `/api/load-assignments/${id}`, { feedOrder }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
    },
  });

  const renameLoadMutation = useMutation({
    mutationFn: ({ id, name }: { id: string; name: string }) =>
      apiRequest("PATCH", `/api/loads/${id}`, { name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/loads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
      setEditingLoadId(null);
      setEditingLoadName("");
      toast({ title: "Load renamed", description: "Load name updated successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to rename load. Name may already exist.", variant: "destructive" });
    },
  });

  const startEditing = (load: Load) => {
    setEditingLoadId(load.id);
    setEditingLoadName(load.name);
  };

  const cancelEditing = () => {
    setEditingLoadId(null);
    setEditingLoadName("");
  };

  const saveRename = (id: string) => {
    const trimmed = editingLoadName.trim();
    if (!trimmed) return;
    renameLoadMutation.mutate({ id, name: trimmed });
  };

  const handleCreateLoad = () => {
    if (!newLoadName.trim()) return;
    createLoadMutation.mutate({ name: newLoadName.trim() });
  };

  const handleAssignMob = () => {
    if (!selectedLoad || !selectedMob) return;
    createAssignmentMutation.mutate({
      loadName: selectedLoad,
      mobName: selectedMob,
      feedMultiplier: parseFloat(multiplier) || 1.0,
    });
  };

  const isLoading = loadsLoading || mobsLoading || assignmentsLoading;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const sortedLoads = [...(loads || [])].sort((a, b) => 
    a.name.localeCompare(b.name, undefined, { numeric: true })
  );

  const getLoadAssignments = (loadName: string) => {
    return (assignments?.filter(a => a.loadName === loadName) || [])
      .sort((a, b) => a.feedOrder - b.feedOrder);
  };

  const moveAssignment = (assignmentId: string, loadName: string, direction: "up" | "down") => {
    const loadAssignments = getLoadAssignments(loadName);
    const currentIndex = loadAssignments.findIndex(a => a.id === assignmentId);
    
    if (currentIndex === -1) return;
    if (direction === "up" && currentIndex === 0) return;
    if (direction === "down" && currentIndex === loadAssignments.length - 1) return;

    const newIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;
    const currentAssignment = loadAssignments[currentIndex];
    const swapAssignment = loadAssignments[newIndex];

    reorderMutation.mutate({ id: currentAssignment.id, feedOrder: newIndex });
    reorderMutation.mutate({ id: swapAssignment.id, feedOrder: currentIndex });

    toast({
      title: "Order updated",
      description: `Moved ${direction}`,
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Create Load</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3">
            <div className="flex-1">
              <Label htmlFor="loadName">Load Name</Label>
              <Input
                id="loadName"
                placeholder="e.g., Load 1"
                value={newLoadName}
                onChange={(e) => setNewLoadName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleCreateLoad()}
                data-testid="input-load-name"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={handleCreateLoad}
                disabled={!newLoadName.trim() || createLoadMutation.isPending}
                data-testid="button-create-load"
              >
                {createLoadMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Plus className="w-4 h-4 mr-2" />
                )}
                Create Load
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {sortedLoads.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Assign Mob to Load</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <Label>Load</Label>
                <Select value={selectedLoad} onValueChange={setSelectedLoad}>
                  <SelectTrigger data-testid="select-load">
                    <SelectValue placeholder="Select load" />
                  </SelectTrigger>
                  <SelectContent>
                    {sortedLoads.map((load) => (
                      <SelectItem key={load.id} value={load.name}>
                        {load.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Mob</Label>
                <Select value={selectedMob} onValueChange={setSelectedMob}>
                  <SelectTrigger data-testid="select-mob">
                    <SelectValue placeholder="Select mob" />
                  </SelectTrigger>
                  <SelectContent>
                    {mobs?.map((mob) => (
                      <SelectItem key={mob.id} value={mob.name}>
                        {mob.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Feed Multiplier</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={multiplier}
                  onChange={(e) => setMultiplier(e.target.value)}
                  placeholder="1.0"
                  data-testid="input-multiplier"
                />
              </div>
            </div>

            <Button
              onClick={handleAssignMob}
              disabled={!selectedLoad || !selectedMob || createAssignmentMutation.isPending}
              data-testid="button-assign-mob"
            >
              {createAssignmentMutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Plus className="w-4 h-4 mr-2" />
              )}
              Assign Mob
            </Button>
          </CardContent>
        </Card>
      )}

      {sortedLoads.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">
              No loads yet. Create your first load above.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {sortedLoads.map((load) => {
            const loadAssignments = getLoadAssignments(load.name);

            return (
              <Card key={load.id}>
                <CardHeader>
                  <div className="flex items-center gap-2 justify-between flex-wrap">
                    {editingLoadId === load.id ? (
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <Input
                          value={editingLoadName}
                          onChange={(e) => setEditingLoadName(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") saveRename(load.id);
                            if (e.key === "Escape") cancelEditing();
                          }}
                          autoFocus
                          className="flex-1"
                          data-testid={`input-rename-load-${load.id}`}
                        />
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => saveRename(load.id)}
                          disabled={!editingLoadName.trim() || renameLoadMutation.isPending}
                          data-testid={`button-confirm-rename-load-${load.id}`}
                        >
                          {renameLoadMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={cancelEditing}
                          data-testid={`button-cancel-rename-load-${load.id}`}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <CardTitle className="truncate">{load.name}</CardTitle>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => startEditing(load)}
                          data-testid={`button-edit-load-${load.id}`}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                    {editingLoadId !== load.id && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteLoadMutation.mutate(load.id)}
                        disabled={deleteLoadMutation.isPending}
                        data-testid={`button-delete-load-${load.name}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {loadAssignments.length === 0 ? (
                    <p className="text-sm text-muted-foreground">
                      No mobs assigned to this load yet
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {loadAssignments.map((assignment, idx) => (
                        <div
                          key={assignment.id}
                          className="flex items-center gap-2 p-3 rounded-md bg-muted/30"
                          data-testid={`assignment-${load.name}-${assignment.mobName}`}
                        >
                          <div className="flex flex-col gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => moveAssignment(assignment.id, load.name, "up")}
                              disabled={idx === 0 || reorderMutation.isPending}
                              className="h-6 w-6"
                              data-testid={`button-move-up-${assignment.mobName}`}
                            >
                              <ChevronUp className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => moveAssignment(assignment.id, load.name, "down")}
                              disabled={idx === loadAssignments.length - 1 || reorderMutation.isPending}
                              className="h-6 w-6"
                              data-testid={`button-move-down-${assignment.mobName}`}
                            >
                              <ChevronDown className="w-4 h-4" />
                            </Button>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary" className="shrink-0">#{idx + 1}</Badge>
                              <p className="font-medium text-foreground truncate">
                                {assignment.mobName}
                              </p>
                            </div>
                            <Badge variant="outline" className="mt-1">
                              Multiplier: ×{assignment.feedMultiplier.toFixed(2)}
                            </Badge>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteAssignmentMutation.mutate(assignment.id)}
                            disabled={deleteAssignmentMutation.isPending}
                            className="shrink-0"
                            data-testid={`button-remove-${load.name}-${assignment.mobName}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
