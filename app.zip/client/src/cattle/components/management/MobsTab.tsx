import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Plus, Trash2, Loader2, Pencil, Check, X, Clock, ChevronUp, ChevronDown } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMobSchema, type Mob, type InsertMob, type AnimalClass, type Element, type GradualElementData, type Recipe } from "@shared/cattleSchema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

interface EditingMob {
  id: string;
  name: string;
  paddock: string;
  headCount: number;
}

import { GradualPercentageControl } from "@/cattle/components/GradualPercentageControl";

export default function MobsTab() {
  const { toast } = useToast();
  const [editingMob, setEditingMob] = useState<EditingMob | null>(null);

  const { data: mobs, isLoading: mobsLoading } = useQuery<Mob[]>({
    queryKey: ["/api/mobs"],
  });

  const { data: classes, isLoading: classesLoading } = useQuery<AnimalClass[]>({
    queryKey: ["/api/classes"],
  });

  const { data: elements } = useQuery<Element[]>({
    queryKey: ["/api/elements"],
  });

  const { data: recipes } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  // Get gradual elements
  const gradualElements = elements?.filter(e => e.isGradual) || [];

  const form = useForm<InsertMob>({
    resolver: zodResolver(insertMobSchema),
    defaultValues: {
      name: "",
      className: "",
      paddock: "",
      headCount: 0,
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertMob) => apiRequest("POST", "/api/mobs", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mobs"] });
      form.reset();
      toast({
        title: "Mob created",
        description: "The mob has been added successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create mob. Name may already exist.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/mobs/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mobs"] });
      toast({
        title: "Mob deleted",
        description: "The mob has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete mob. It may be assigned to a load.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, name, paddock, headCount }: { id: string; name: string; paddock: string; headCount: number }) =>
      apiRequest("PATCH", `/api/mobs/${id}`, { name, paddock, headCount }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
      setEditingMob(null);
      toast({
        title: "Mob updated",
        description: "Mob details have been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update mob. Name may already exist.",
        variant: "destructive",
      });
    },
  });

  const updateGradualMutation = useMutation({
    mutationFn: ({ id, gradualPercentages }: { id: string; gradualPercentages: Record<string, GradualElementData> }) =>
      apiRequest("PATCH", `/api/mobs/${id}`, { gradualPercentages }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mobs"] });
    },
  });

  const updateMultiplierMutation = useMutation({
    mutationFn: ({ id, feedMultiplier }: { id: string; feedMultiplier: number }) =>
      apiRequest("PATCH", `/api/mobs/${id}`, { feedMultiplier }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/load-assignments"] });
    },
  });

  const handleMultiplierChange = (mob: Mob, change: number) => {
    const newMultiplier = Math.max(0.1, mob.feedMultiplier + change);
    updateMultiplierMutation.mutate({
      id: mob.id,
      feedMultiplier: parseFloat(newMultiplier.toFixed(2)),
    });
    toast({
      title: change > 0 ? "Boosted feed" : "Reduced feed",
      description: `Multiplier adjusted to ${newMultiplier.toFixed(2)}x`,
    });
  };

  const handleGradualPercentageSave = (mob: Mob, elementName: string, percentage: number) => {
    const currentPercentages = (mob.gradualPercentages as Record<string, GradualElementData>) || {};
    const newPercentages = { 
      ...currentPercentages, 
      [elementName]: {
        percentage,
        updatedAt: new Date().toISOString(),
      }
    };
    updateGradualMutation.mutate({ id: mob.id, gradualPercentages: newPercentages });
    toast({
      title: "Percentage saved",
      description: `${elementName} set to ${percentage}%`,
    });
  };

  const startEditing = (mob: Mob) => {
    setEditingMob({
      id: mob.id,
      name: mob.name,
      paddock: mob.paddock,
      headCount: mob.headCount,
    });
  };

  const cancelEditing = () => {
    setEditingMob(null);
  };

  const saveEditing = () => {
    if (editingMob) {
      updateMutation.mutate({
        id: editingMob.id,
        name: editingMob.name,
        paddock: editingMob.paddock,
        headCount: editingMob.headCount,
      });
    }
  };

  const onSubmit = (data: InsertMob) => {
    createMutation.mutate(data);
  };

  const isLoading = mobsLoading || classesLoading;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const sortedClasses = [...(classes || [])].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Add Mob</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mob Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="e.g., Spring U Bulls @ Simon's Haystack"
                          {...field}
                          data-testid="input-mob-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="className"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Animal Class</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-class">
                            <SelectValue placeholder="Select class" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sortedClasses.map((cls) => (
                            <SelectItem key={cls.id} value={cls.name}>
                              {cls.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="paddock"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Paddock</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="e.g., Simon's Haystack"
                          {...field}
                          data-testid="input-paddock"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="headCount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Head Count</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="0"
                          {...field}
                          onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                          data-testid="input-head-count"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Button
                type="submit"
                disabled={createMutation.isPending || sortedClasses.length === 0}
                className="w-full md:w-auto"
                data-testid="button-create-mob"
              >
                {createMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Plus className="w-4 h-4 mr-2" />
                )}
                Add Mob
              </Button>

              {sortedClasses.length === 0 && (
                <p className="text-sm text-muted-foreground">
                  Create animal classes first in the Recipes tab
                </p>
              )}
            </form>
          </Form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Mobs ({mobs?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
          {!mobs || mobs.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No mobs yet. Add your first mob above.
            </p>
          ) : (
            <div className="space-y-3">
              {mobs.map((mob) => {
                const isEditing = editingMob?.id === mob.id;
                
                return (
                  <div
                    key={mob.id}
                    className="p-4 border rounded-md"
                    data-testid={`mob-${mob.name}`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0 space-y-2">
                        <h3 className="font-semibold text-foreground">{mob.name}</h3>
                        
                        {isEditing ? (
                          <div className="space-y-3">
                            <div>
                              <label className="text-xs text-muted-foreground">Mob Name</label>
                              <Input
                                value={editingMob.name}
                                onChange={(e) => setEditingMob({ ...editingMob, name: e.target.value })}
                                className="mt-1"
                                data-testid={`input-edit-name-${mob.name}`}
                              />
                            </div>
                            <div>
                              <label className="text-xs text-muted-foreground">Paddock</label>
                              <Input
                                value={editingMob.paddock}
                                onChange={(e) => setEditingMob({ ...editingMob, paddock: e.target.value })}
                                className="mt-1"
                                data-testid={`input-edit-paddock-${mob.name}`}
                              />
                            </div>
                            <div>
                              <label className="text-xs text-muted-foreground">Head Count</label>
                              <Input
                                type="number"
                                value={editingMob.headCount}
                                onChange={(e) => setEditingMob({ ...editingMob, headCount: parseInt(e.target.value) || 0 })}
                                className="mt-1"
                                data-testid={`input-edit-headcount-${mob.name}`}
                              />
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                onClick={saveEditing}
                                disabled={updateMutation.isPending}
                                data-testid={`button-save-mob-${mob.name}`}
                              >
                                {updateMutation.isPending ? (
                                  <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                                ) : (
                                  <Check className="w-4 h-4 mr-1" />
                                )}
                                Save
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={cancelEditing}
                                disabled={updateMutation.isPending}
                                data-testid={`button-cancel-mob-${mob.name}`}
                              >
                                <X className="w-4 h-4 mr-1" />
                                Cancel
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <>
                            <p className="text-sm text-muted-foreground">{mob.paddock}</p>
                            <div className="flex gap-2 flex-wrap">
                              <Badge variant="secondary">{mob.className}</Badge>
                              <Badge variant="outline">{mob.headCount} head</Badge>
                            </div>
                            
                            {/* Feed Multiplier Section */}
                            <div className="mt-3 pt-3 border-t border-border">
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-sm font-medium text-muted-foreground">Feed Multiplier</span>
                                <div className="flex items-center gap-2">
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    className="h-8 w-8"
                                    onClick={() => handleMultiplierChange(mob, -0.05)}
                                    disabled={updateMultiplierMutation.isPending || mob.feedMultiplier <= 0.1}
                                    data-testid={`button-reduce-${mob.name}`}
                                  >
                                    <ChevronDown className="w-4 h-4" />
                                  </Button>
                                  <Badge 
                                    variant="outline" 
                                    className="font-mono text-base px-3"
                                    data-testid={`badge-multiplier-${mob.name}`}
                                  >
                                    ×{mob.feedMultiplier.toFixed(2)}
                                  </Badge>
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    className="h-8 w-8"
                                    onClick={() => handleMultiplierChange(mob, 0.05)}
                                    disabled={updateMultiplierMutation.isPending}
                                    data-testid={`button-boost-${mob.name}`}
                                  >
                                    <ChevronUp className="w-4 h-4" />
                                  </Button>
                                </div>
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                Applies to all loads containing this mob (except gradual elements)
                              </p>
                            </div>
                            
                            {/* Gradual Elements Section */}
                            {gradualElements.length > 0 && (
                              <div className="mt-3 pt-3 border-t border-border space-y-3">
                                <div className="flex items-center gap-2">
                                  <Clock className="w-4 h-4 text-amber-600" />
                                  <span className="text-sm font-medium text-muted-foreground">
                                    Gradual Introduction Elements
                                  </span>
                                </div>
                                {gradualElements.map((element) => (
                                  <GradualPercentageControl
                                    key={element.name}
                                    mob={mob}
                                    element={element}
                                    recipes={recipes || []}
                                    onSave={handleGradualPercentageSave}
                                  />
                                ))}
                              </div>
                            )}
                          </>
                        )}
                      </div>
                      
                      {!isEditing && (
                        <div className="flex gap-1 shrink-0">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => startEditing(mob)}
                            data-testid={`button-edit-${mob.name}`}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteMutation.mutate(mob.id)}
                            disabled={deleteMutation.isPending}
                            data-testid={`button-delete-${mob.name}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
