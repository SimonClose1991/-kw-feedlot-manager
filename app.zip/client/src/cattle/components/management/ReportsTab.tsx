import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Download } from "lucide-react";
import type { FeedHistory, Element } from "@shared/cattleSchema";

type RangeKey = "week" | "month" | "ytd" | "year" | "all" | "custom";

function startOf(range: RangeKey): Date | null {
  const now = new Date();
  switch (range) {
    case "week": {
      const d = new Date(now);
      d.setDate(d.getDate() - 7);
      return d;
    }
    case "month": {
      const d = new Date(now);
      d.setMonth(d.getMonth() - 1);
      return d;
    }
    case "ytd":
      return new Date(now.getFullYear(), 0, 1);
    case "year": {
      const d = new Date(now);
      d.setFullYear(d.getFullYear() - 1);
      return d;
    }
    default:
      return null;
  }
}

// Convert a stored cost ($/tonne or $/kg) into $/kg for calculation.
function costPerKg(el: Element | undefined): number {
  if (!el || !el.costPerUnit) return 0;
  return el.costUnit === "$/kg" ? el.costPerUnit : el.costPerUnit / 1000;
}

export default function ReportsTab() {
  const [range, setRange] = useState<RangeKey>("ytd");
  const [customStart, setCustomStart] = useState("");
  const [customEnd, setCustomEnd] = useState("");

  const { data: history, isLoading: historyLoading } = useQuery<FeedHistory[]>({
    queryKey: ["/api/feed-history"],
  });
  const { data: elements, isLoading: elementsLoading } = useQuery<Element[]>({
    queryKey: ["/api/elements"],
  });

  const elementByName = useMemo(() => {
    const m = new Map<string, Element>();
    (elements || []).forEach((e) => m.set(e.name, e));
    return m;
  }, [elements]);

  const { rows, totalKg, totalCost, filteredCount, rangeLabel } = useMemo(() => {
    let start: Date | null = null;
    let end: Date | null = null;
    let label = "All time";

    if (range === "custom") {
      start = customStart ? new Date(customStart) : null;
      end = customEnd ? new Date(customEnd + "T23:59:59") : null;
      label = `${customStart || "start"} to ${customEnd || "now"}`;
    } else if (range !== "all") {
      start = startOf(range);
      label =
        range === "week" ? "Last 7 days" :
        range === "month" ? "Last 30 days" :
        range === "ytd" ? "Year to date" :
        range === "year" ? "Last 12 months" : "All time";
    }

    const totals = new Map<string, number>(); // commodity -> kg
    let count = 0;

    (history || []).forEach((rec) => {
      const t = new Date(rec.timestamp);
      if (start && t < start) return;
      if (end && t > end) return;
      count++;
      const ingredients = (rec.ingredients || {}) as Record<string, number>;
      Object.entries(ingredients).forEach(([name, kg]) => {
        totals.set(name, (totals.get(name) || 0) + (Number(kg) || 0));
      });
    });

    const rows = Array.from(totals.entries())
      .map(([name, kg]) => {
        const cpk = costPerKg(elementByName.get(name));
        return {
          name,
          kg,
          tonnes: kg / 1000,
          costPerKg: cpk,
          cost: kg * cpk,
        };
      })
      .sort((a, b) => b.kg - a.kg);

    const totalKg = rows.reduce((s, r) => s + r.kg, 0);
    const totalCost = rows.reduce((s, r) => s + r.cost, 0);

    return { rows, totalKg, totalCost, filteredCount: count, rangeLabel: label };
  }, [history, elementByName, range, customStart, customEnd]);

  const exportCsv = () => {
    const header = ["Commodity", "Total kg", "Total tonnes", "Cost per kg", "Total cost"];
    const lines = [header.join(",")];
    rows.forEach((r) => {
      lines.push([
        `"${r.name}"`,
        r.kg.toFixed(1),
        r.tonnes.toFixed(3),
        r.costPerKg.toFixed(4),
        r.cost.toFixed(2),
      ].join(","));
    });
    lines.push(["TOTAL", totalKg.toFixed(1), (totalKg / 1000).toFixed(3), "", totalCost.toFixed(2)].join(","));
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cattle-commodity-report-${rangeLabel.replace(/\s+/g, "-")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const isLoading = historyLoading || elementsLoading;

  const fmt = (n: number) =>
    n.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 1 });
  const money = (n: number) =>
    "$" + n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Commodity &amp; Cost Report</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {([
              ["week", "Last 7 days"],
              ["month", "Last 30 days"],
              ["ytd", "Year to date"],
              ["year", "Last 12 months"],
              ["all", "All time"],
              ["custom", "Custom"],
            ] as [RangeKey, string][]).map(([key, lbl]) => (
              <Button
                key={key}
                variant={range === key ? "default" : "outline"}
                size="sm"
                onClick={() => setRange(key)}
                data-testid={`range-${key}`}
              >
                {lbl}
              </Button>
            ))}
          </div>

          {range === "custom" && (
            <div className="grid grid-cols-2 gap-3 max-w-md">
              <div className="space-y-1">
                <Label className="text-xs">Start date</Label>
                <Input type="date" value={customStart} onChange={(e) => setCustomStart(e.target.value)} data-testid="report-start" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">End date</Label>
                <Input type="date" value={customEnd} onChange={(e) => setCustomEnd(e.target.value)} data-testid="report-end" />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <CardTitle className="text-base">
              {rangeLabel} · {filteredCount} feed{filteredCount === 1 ? "" : "s"}
            </CardTitle>
            <Button variant="outline" size="sm" onClick={exportCsv} disabled={rows.length === 0} data-testid="button-export-csv">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </CardHeader>
          <CardContent>
            {rows.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                No feed records in this period.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b text-left text-muted-foreground">
                      <th className="py-2 pr-4 font-medium">Commodity</th>
                      <th className="py-2 px-4 font-medium text-right">Tonnes</th>
                      <th className="py-2 px-4 font-medium text-right">kg</th>
                      <th className="py-2 pl-4 font-medium text-right">Cost</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r) => (
                      <tr key={r.name} className="border-b last:border-0" data-testid={`report-row-${r.name}`}>
                        <td className="py-2 pr-4 font-medium">{r.name}</td>
                        <td className="py-2 px-4 text-right">{r.tonnes.toFixed(2)}</td>
                        <td className="py-2 px-4 text-right text-muted-foreground">{fmt(r.kg)}</td>
                        <td className="py-2 pl-4 text-right">{r.cost > 0 ? money(r.cost) : <span className="text-muted-foreground">—</span>}</td>
                      </tr>
                    ))}
                    <tr className="font-semibold">
                      <td className="py-2 pr-4">Total</td>
                      <td className="py-2 px-4 text-right">{(totalKg / 1000).toFixed(2)}</td>
                      <td className="py-2 px-4 text-right">{fmt(totalKg)}</td>
                      <td className="py-2 pl-4 text-right">{totalCost > 0 ? money(totalCost) : "—"}</td>
                    </tr>
                  </tbody>
                </table>
                {totalCost === 0 && (
                  <p className="text-xs text-muted-foreground mt-3">
                    Tip: add a cost to your feed elements (in the Elements tab) to see dollar figures here.
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
