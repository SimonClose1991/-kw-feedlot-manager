import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Plus, Trash2, Loader2, Edit2, Check, X, Clock } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertElementSchema, type Element, type InsertElement } from "@shared/cattleSchema";
import { useState } from "react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

export default function ElementsTab() {
  const { toast } = useToast();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValues, setEditValues] = useState<{ defaultRate: number; isGradual: boolean; costPerUnit: number; costUnit: "$/tonne" | "$/kg" }>({ defaultRate: 0, isGradual: false, costPerUnit: 0, costUnit: "$/tonne" });

  const { data: elements, isLoading } = useQuery<Element[]>({
    queryKey: ["/api/elements"],
  });

  const form = useForm<InsertElement>({
    resolver: zodResolver(insertElementSchema),
    defaultValues: {
      name: "",
      unit: "kg/head",
      defaultRate: 0,
      isGradual: false,
      costPerUnit: 0,
      costUnit: "$/tonne",
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertElement) => apiRequest("POST", "/api/elements", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/elements"] });
      form.reset();
      toast({
        title: "Element created",
        description: "The feed element has been added successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create element. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/elements/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/elements"] });
      toast({
        title: "Element deleted",
        description: "The feed element has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete element. It may be in use.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertElement> }) =>
      apiRequest("PATCH", `/api/elements/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/elements"] });
      setEditingId(null);
      toast({
        title: "Element updated",
        description: "The default rate has been updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update element. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertElement) => {
    createMutation.mutate(data);
  };

  const handleEdit = (element: Element) => {
    setEditingId(element.id);
    setEditValues({ defaultRate: element.defaultRate, isGradual: element.isGradual, costPerUnit: element.costPerUnit ?? 0, costUnit: (element.costUnit as "$/tonne" | "$/kg") ?? "$/tonne" });
  };

  const handleSaveEdit = (id: string) => {
    updateMutation.mutate({ id, data: { defaultRate: editValues.defaultRate, isGradual: editValues.isGradual, costPerUnit: editValues.costPerUnit, costUnit: editValues.costUnit } });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Add Feed Element</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Element Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="e.g., Silage"
                          {...field}
                          data-testid="input-element-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="unit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Unit</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-unit">
                            <SelectValue placeholder="Select unit" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="kg/head">kg/head</SelectItem>
                          <SelectItem value="L/head">L/head</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="defaultRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Default Rate</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.1"
                          placeholder="0"
                          {...field}
                          onChange={e => field.onChange(parseFloat(e.target.value) || 0)}
                          data-testid="input-default-rate"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="costPerUnit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cost</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0"
                          {...field}
                          onChange={e => field.onChange(parseFloat(e.target.value) || 0)}
                          data-testid="input-cost"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="costUnit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cost Unit</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-cost-unit">
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="$/tonne">$/tonne</SelectItem>
                          <SelectItem value="$/kg">$/kg</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="isGradual"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="checkbox-gradual"
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Gradual Introduction Required</FormLabel>
                      <p className="text-sm text-muted-foreground">
                        Check this for elements that need slow introduction over 7-10 days (e.g., high-starch feeds)
                      </p>
                    </div>
                  </FormItem>
                )}
              />

              <Button
                type="submit"
                disabled={createMutation.isPending}
                className="w-full md:w-auto"
                data-testid="button-create-element"
              >
                {createMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Plus className="w-4 h-4 mr-2" />
                )}
                Add Element
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Feed Elements ({elements?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
          {!elements || elements.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              No elements yet. Add your first feed element above.
            </p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {elements.map((element) => (
                <div
                  key={element.id}
                  className="p-4 border rounded-md space-y-3"
                  data-testid={`element-${element.name}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-semibold text-foreground">{element.name}</h3>
                    <div className="flex gap-1 shrink-0">
                      {editingId === element.id ? (
                        <>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleSaveEdit(element.id)}
                            disabled={updateMutation.isPending}
                            className="h-8 w-8"
                            data-testid={`button-save-${element.name}`}
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={handleCancelEdit}
                            disabled={updateMutation.isPending}
                            className="h-8 w-8"
                            data-testid={`button-cancel-${element.name}`}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(element)}
                            className="h-8 w-8"
                            data-testid={`button-edit-${element.name}`}
                          >
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteMutation.mutate(element.id)}
                            disabled={deleteMutation.isPending}
                            className="h-8 w-8"
                            data-testid={`button-delete-${element.name}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex gap-2 flex-wrap">
                      <Badge variant="secondary">{element.unit}</Badge>
                      {element.isGradual && (
                        <Badge variant="default" className="bg-amber-600">
                          <Clock className="w-3 h-3 mr-1" />
                          Gradual
                        </Badge>
                      )}
                    </div>
                    {editingId === element.id ? (
                      <div className="space-y-3">
                        <div className="space-y-1">
                          <Label htmlFor={`edit-${element.id}`} className="text-sm">
                            Default Rate
                          </Label>
                          <Input
                            id={`edit-${element.id}`}
                            type="number"
                            step="0.1"
                            value={editValues.defaultRate}
                            onChange={(e) =>
                              setEditValues({ ...editValues, defaultRate: parseFloat(e.target.value) || 0 })
                            }
                            disabled={updateMutation.isPending}
                            data-testid={`input-edit-rate-${element.name}`}
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id={`edit-gradual-${element.id}`}
                            checked={editValues.isGradual}
                            onCheckedChange={(checked) =>
                              setEditValues({ ...editValues, isGradual: checked === true })
                            }
                            disabled={updateMutation.isPending}
                            data-testid={`checkbox-edit-gradual-${element.name}`}
                          />
                          <Label htmlFor={`edit-gradual-${element.id}`} className="text-sm">
                            Gradual Introduction
                          </Label>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="space-y-1">
                            <Label className="text-sm">Cost</Label>
                            <Input
                              type="number"
                              step="0.01"
                              value={editValues.costPerUnit}
                              onChange={(e) =>
                                setEditValues({ ...editValues, costPerUnit: parseFloat(e.target.value) || 0 })
                              }
                              disabled={updateMutation.isPending}
                              data-testid={`input-edit-cost-${element.name}`}
                            />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-sm">Unit</Label>
                            <Select
                              value={editValues.costUnit}
                              onValueChange={(v) => setEditValues({ ...editValues, costUnit: v as "$/tonne" | "$/kg" })}
                            >
                              <SelectTrigger data-testid={`select-edit-cost-unit-${element.name}`}>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="$/tonne">$/tonne</SelectItem>
                                <SelectItem value="$/kg">$/kg</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex gap-2 flex-wrap">
                        <Badge variant="outline">Default: {element.defaultRate}</Badge>
                        {(element.costPerUnit ?? 0) > 0 && (
                          <Badge variant="outline">
                            ${element.costPerUnit} {element.costUnit ?? "$/tonne"}
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
