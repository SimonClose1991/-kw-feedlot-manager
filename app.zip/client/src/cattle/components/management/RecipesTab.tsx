import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Plus, Loader2, Save, Trash2 } from "lucide-react";
import type { Element, Recipe, AnimalClass, InsertRecipe } from "@shared/cattleSchema";

export default function RecipesTab() {
  const { toast } = useToast();
  const [newClassName, setNewClassName] = useState("");

  const { data: elements } = useQuery<Element[]>({
    queryKey: ["/api/elements"],
  });

  const { data: classes } = useQuery<AnimalClass[]>({
    queryKey: ["/api/classes"],
  });

  const { data: recipes, isLoading } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  const [recipeEdits, setRecipeEdits] = useState<Map<string, number>>(new Map());

  const createClassMutation = useMutation({
    mutationFn: async (className: string) => {
      await apiRequest("POST", "/api/classes", { name: className });
      
      if (elements) {
        const recipePromises = elements.map(element =>
          apiRequest("POST", "/api/recipes", {
            className,
            elementName: element.name,
            rate: element.defaultRate,
          })
        );
        await Promise.all(recipePromises);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      setNewClassName("");
      toast({
        title: "Class created",
        description: "New animal class with default recipes has been created.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create class. Name may already exist.",
        variant: "destructive",
      });
    },
  });

  const deleteClassMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/classes/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({
        title: "Class deleted",
        description: "Animal class and its recipes have been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete class. It may be in use by mobs.",
        variant: "destructive",
      });
    },
  });

  const updateRecipeMutation = useMutation({
    mutationFn: ({ id, rate }: { id: string; rate: number }) =>
      apiRequest("PATCH", `/api/recipes/${id}`, { rate }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({
        title: "Recipe updated",
        description: "Recipe rate has been saved.",
      });
    },
  });

  const createRecipeMutation = useMutation({
    mutationFn: (data: InsertRecipe) =>
      apiRequest("POST", "/api/recipes", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({
        title: "Recipe added",
        description: "Element has been added to this class.",
      });
    },
  });

  const handleCreateClass = () => {
    if (!newClassName.trim()) return;
    createClassMutation.mutate(newClassName.trim());
  };

  const handleRateChange = (recipeId: string, newRate: number) => {
    const updated = new Map(recipeEdits);
    updated.set(recipeId, newRate);
    setRecipeEdits(updated);
  };

  const handleSaveRecipe = (recipeId: string) => {
    const rate = recipeEdits.get(recipeId);
    if (rate !== undefined) {
      updateRecipeMutation.mutate({ id: recipeId, rate });
      const updated = new Map(recipeEdits);
      updated.delete(recipeId);
      setRecipeEdits(updated);
    }
  };

  const getRecipeValue = (recipe: Recipe): number => {
    return recipeEdits.has(recipe.id) ? recipeEdits.get(recipe.id)! : recipe.rate;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const sortedClasses = [...(classes || [])].sort((a, b) => a.name.localeCompare(b.name));
  const sortedElements = [...(elements || [])].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Create Animal Class</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3">
            <div className="flex-1">
              <Label htmlFor="className">Class Name</Label>
              <Input
                id="className"
                placeholder="e.g., Spring U Bulls"
                value={newClassName}
                onChange={(e) => setNewClassName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleCreateClass()}
                data-testid="input-class-name"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={handleCreateClass}
                disabled={!newClassName.trim() || createClassMutation.isPending}
                data-testid="button-create-class"
              >
                {createClassMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Plus className="w-4 h-4 mr-2" />
                )}
                Create Class
              </Button>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mt-2">
            Creates a class with default recipes for all elements
          </p>
        </CardContent>
      </Card>

      {sortedClasses.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">
              No animal classes yet. Create your first class above.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {sortedClasses.map((animalClass) => {
            const classRecipes = recipes?.filter(r => r.className === animalClass.name) || [];
            
            // Calculate total KGs for this class (only kg/head elements)
            const totalKgs = sortedElements.reduce((sum, element) => {
              if (element.unit !== "kg/head") return sum;
              const recipe = classRecipes.find(r => r.elementName === element.name);
              if (!recipe) return sum;
              const rate = recipeEdits.has(recipe.id) ? recipeEdits.get(recipe.id)! : recipe.rate;
              return sum + rate;
            }, 0);

            return (
              <Card key={animalClass.id}>
                <CardHeader>
                  <div className="flex items-center justify-between gap-3">
                    <CardTitle>{animalClass.name}</CardTitle>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteClassMutation.mutate(animalClass.id)}
                      disabled={deleteClassMutation.isPending}
                      data-testid={`button-delete-class-${animalClass.name}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {sortedElements.map((element) => {
                      const recipe = classRecipes.find(r => r.elementName === element.name);
                      
                      if (!recipe) {
                        // Element doesn't have a recipe for this class - show "Add" button
                        return (
                          <div
                            key={element.name}
                            className="flex items-center gap-3 p-3 rounded-md bg-muted/30 border-2 border-dashed border-muted-foreground/30"
                            data-testid={`recipe-missing-${animalClass.name}-${element.name}`}
                          >
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-foreground">{element.name}</p>
                              <p className="text-sm text-muted-foreground">{element.unit}</p>
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => createRecipeMutation.mutate({
                                className: animalClass.name,
                                elementName: element.name,
                                rate: element.defaultRate,
                              })}
                              disabled={createRecipeMutation.isPending}
                              data-testid={`button-add-recipe-${animalClass.name}-${element.name}`}
                            >
                              <Plus className="w-4 h-4 mr-1" />
                              Add
                            </Button>
                          </div>
                        );
                      }

                      const currentValue = getRecipeValue(recipe);
                      const hasChanges = recipeEdits.has(recipe.id);

                      return (
                        <div
                          key={recipe.id}
                          className="flex items-center gap-3 p-3 rounded-md bg-muted/30"
                          data-testid={`recipe-${animalClass.name}-${element.name}`}
                        >
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-foreground">{element.name}</p>
                            <p className="text-sm text-muted-foreground">{element.unit}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              step="0.1"
                              value={currentValue}
                              onChange={(e) => handleRateChange(recipe.id, parseFloat(e.target.value) || 0)}
                              className="w-24 text-right font-mono"
                              data-testid={`input-rate-${animalClass.name}-${element.name}`}
                            />
                            {hasChanges && (
                              <Button
                                size="sm"
                                onClick={() => handleSaveRecipe(recipe.id)}
                                disabled={updateRecipeMutation.isPending}
                                data-testid={`button-save-${animalClass.name}-${element.name}`}
                              >
                                <Save className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  
                  {/* Total KGs per head summary */}
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-muted-foreground">Total KGs per Head</span>
                      <span 
                        className="text-xl font-mono font-bold text-primary"
                        data-testid={`total-kgs-${animalClass.name}`}
                      >
                        {totalKgs.toFixed(1)} kg
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
