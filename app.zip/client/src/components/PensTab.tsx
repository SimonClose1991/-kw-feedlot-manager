import { useState } from "react";
import type { Pen } from "@shared/types";
import { formatKg } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, ChevronUp, ChevronDown, Trash2, AlertTriangle } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { usePinProtection } from "@/hooks/usePinProtection";
import { useMutation, useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface PensTabProps {
  pens: Pen[];
  order: string[];
  setOrder: (order: string[]) => void;
}

export function PensTab({ pens, order, setOrder }: PensTabProps) {
  const [filter, setFilter] = useState("");
  const [expandedPens, setExpandedPens] = useState<Record<string, boolean>>({});
  const [editingPens, setEditingPens] = useState<Record<string, Partial<Pen>>>({});
  const [safetyDialog, setSafetyDialog] = useState<{ open: boolean; message: string; pendingPens: Pen[] | null }>({
    open: false,
    message: "",
    pendingPens: null,
  });
  const { isUnlocked, requestUnlock, PinDialog } = usePinProtection();
  const { toast } = useToast();

  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: api.settings.get,
  });

  const savePensMutation = useMutation({
    mutationFn: (params: { pens: Pen[]; forceDelete?: boolean }) => 
      api.pens.save(params.pens, params.forceDelete ?? false),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pens"] });
    },
    onError: (error: Error & { requiresConfirmation?: boolean }) => {
      if (error.requiresConfirmation) {
        // Extract the pen names from the error message
        const match = error.message.match(/SAFETY_CHECK: Would delete (\d+) pens \(([^)]+)\)/);
        if (match) {
          setSafetyDialog({
            open: true,
            message: `This action would delete ${match[1]} pens: ${match[2]}. This is unusual and may indicate a sync problem. Are you sure you want to proceed?`,
            pendingPens: null, // Will be set when we try again with force
          });
        }
      } else {
        toast({
          title: "Error saving pens",
          description: error.message,
          variant: "destructive",
        });
      }
    },
  });

  // Store pending pens for force delete
  const [pendingForcePens, setPendingForcePens] = useState<Pen[] | null>(null);

  function savePens(pensToSave: Pen[], force: boolean = false) {
    if (!force) {
      setPendingForcePens(pensToSave);
    }
    savePensMutation.mutate({ pens: pensToSave, forceDelete: force });
  }

  function handleForceDelete() {
    if (pendingForcePens) {
      savePensMutation.mutate({ pens: pendingForcePens, forceDelete: true });
      setSafetyDialog({ open: false, message: "", pendingPens: null });
      setPendingForcePens(null);
    }
  }

  async function ensureUnlocked() {
    if (isUnlocked) return true;
    return await requestUnlock();
  }

  function updatePenLocal(id: string, patch: Partial<Pen>) {
    setEditingPens(prev => ({
      ...prev,
      [id]: { ...(prev[id] || {}), ...patch }
    }));
  }

  async function savePen(id: string) {
    const changes = editingPens[id];
    if (!changes) return;
    
    // Check if unlocked before saving
    if (!isUnlocked && !(await ensureUnlocked())) {
      // If unlock failed, revert local changes
      setEditingPens(prev => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
      return;
    }
    
    const updated = pens.map(p => p.id === id ? { ...p, ...changes } : p);
    
    try {
      await savePensMutation.mutateAsync({ pens: updated, forceDelete: false });
      // Only clear local state after successful save
      setEditingPens(prev => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
    } catch (error) {
      console.error("Failed to save pen:", error);
      // Keep local changes on error so user can try again
    }
  }

  function updatePen(id: string, patch: Partial<Pen>) {
    const updated = pens.map(p => p.id === id ? { ...p, ...patch } : p);
    savePens(updated);
  }

  function getPenValue(pen: Pen, field: keyof Pen) {
    return editingPens[pen.id]?.[field] ?? pen[field];
  }

  async function addPen() {
    if (!isUnlocked && !(await ensureUnlocked())) return;
    
    // Calculate default kg/head/day from ration settings (silage + protein + energy + water)
    const defaultKgPerHead = (settings?.silage ?? 0) + (settings?.protein ?? 0) + (settings?.energy ?? 0) + (settings?.water ?? 0);
    
    const next: Pen = {
      id: crypto.randomUUID(),
      name: `Pen ${pens.length + 1}`,
      ration: "Grower",
      headCount: 0,
      kgPerHead: defaultKgPerHead,
      rationPercent: 100,
      active: true,
    };
    const updated = [...pens, next];
    savePens(updated);
    setOrder([...order, next.id]);
  }

  async function removePen(id: string) {
    if (!isUnlocked && !(await ensureUnlocked())) return;
    if (!confirm("Remove this pen?")) return;
    const updated = pens.filter(p => p.id !== id);
    savePens(updated);
    setOrder(order.filter(x => x !== id));
  }

  async function move(id: string, dir: -1 | 1) {
    if (!isUnlocked && !(await ensureUnlocked())) return;
    const idx = order.indexOf(id);
    if (idx < 0) return;
    const j = idx + dir;
    if (j < 0 || j >= order.length) return;
    const next = [...order];
    [next[idx], next[j]] = [next[j], next[idx]];
    setOrder(next);
  }

  const totalToday = pens.filter(p => p.active).reduce((s, p) => 
    s + p.headCount * p.kgPerHead * ((p.rationPercent ?? 100) / 100), 0
  );

  const totalHeadCount = pens.filter(p => p.active).reduce((s, p) => s + p.headCount, 0);

  const orderedPens = order.map(id => pens.find(p => p.id === id)).filter((p): p is Pen => !!p);
  const filtered = orderedPens.filter(p => 
    !filter || 
    p.name.toLowerCase().includes(filter.toLowerCase()) || 
    p.ration.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <>
      <PinDialog />
      
      {/* Safety confirmation dialog for bulk pen deletion */}
      <AlertDialog open={safetyDialog.open} onOpenChange={(open) => !open && setSafetyDialog({ open: false, message: "", pendingPens: null })}>
        <AlertDialogContent data-testid="dialog-safety-check">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="w-5 h-5" />
              Safety Warning
            </AlertDialogTitle>
            <AlertDialogDescription>
              {safetyDialog.message}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-safety-cancel">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleForceDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-safety-confirm"
            >
              Yes, Delete Anyway
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Card className="p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
          <h2 className="text-xl font-semibold">Pens</h2>
          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
            <div>
              Total head (active): <span className="font-semibold font-mono" data-testid="text-total-head">{totalHeadCount.toLocaleString()}</span>
            </div>
            <div>
              Total daily (active): <span className="font-semibold font-mono" data-testid="text-total-daily">{formatKg(totalToday)}</span>
            </div>
          </div>
        </div>

      <div className="flex flex-wrap gap-3 mb-6">
        <Input
          placeholder="Filter pens..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="max-w-xs"
          data-testid="input-filter"
        />
        <Button onClick={addPen} data-testid="button-add-pen">
          <Plus className="w-4 h-4 mr-2" />
          Add Pen
        </Button>
      </div>

      <div className="space-y-3" data-testid="list-pens">
        {filtered.map((pen, idx) => {
          const isOpen = !!expandedPens[pen.id];
          const dailyTotal = formatKg(
            (getPenValue(pen, 'headCount') as number) *
            (getPenValue(pen, 'kgPerHead') as number) *
            (((getPenValue(pen, 'rationPercent') ?? 100) as number) / 100)
          );
          return (
          <Card key={pen.id} className="p-3 hover-elevate" data-testid={`card-pen-${pen.id}`}>
            <div className="flex items-center gap-2">
              {/* Reorder arrows */}
              <div className="flex flex-col gap-0.5">
                <button
                  onClick={() => move(pen.id, -1)}
                  disabled={idx === 0}
                  className="text-muted-foreground hover:text-foreground disabled:opacity-30"
                  data-testid={`button-move-up-${pen.id}`}
                >
                  <ChevronUp className="w-4 h-4" />
                </button>
                <button
                  onClick={() => move(pen.id, 1)}
                  disabled={idx === filtered.length - 1}
                  className="text-muted-foreground hover:text-foreground disabled:opacity-30"
                  data-testid={`button-move-down-${pen.id}`}
                >
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>

              {/* Collapsed summary: name, type, head — the key glance info */}
              <button
                onClick={() => setExpandedPens(prev => ({ ...prev, [pen.id]: !prev[pen.id] }))}
                className="flex-1 flex items-center gap-3 text-left min-w-0"
                data-testid={`button-expand-pen-${pen.id}`}
              >
                <span className="font-semibold truncate">{(getPenValue(pen, 'name') as string) || "Unnamed"}</span>
                <Badge variant="secondary" className="text-xs shrink-0">{(getPenValue(pen, 'ration') as string) || "—"}</Badge>
                <span className="text-sm text-muted-foreground font-mono shrink-0">{(getPenValue(pen, 'headCount') as number) ?? 0} hd</span>
                {!pen.active && <Badge variant="outline" className="text-xs shrink-0">Inactive</Badge>}
              </button>

              <Badge variant="outline" className="font-mono text-xs shrink-0">{dailyTotal}</Badge>
              <button
                onClick={() => setExpandedPens(prev => ({ ...prev, [pen.id]: !prev[pen.id] }))}
                className="text-muted-foreground hover:text-foreground shrink-0"
                data-testid={`button-toggle-pen-${pen.id}`}
              >
                {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
              </button>
            </div>

            {/* Expanded: full editable form */}
            {isOpen && (
              <div className="mt-3 pt-3 border-t grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor={`name-${pen.id}`} className="text-xs">Name</Label>
                  <Input
                    id={`name-${pen.id}`}
                    value={getPenValue(pen, 'name') as string}
                    onChange={(e) => updatePenLocal(pen.id, { name: e.target.value })}
                    onBlur={() => savePen(pen.id)}
                    className="mt-1"
                    data-testid={`input-name-${pen.id}`}
                  />
                </div>

                <div>
                  <Label htmlFor={`ration-${pen.id}`} className="text-xs">Type</Label>
                  <Input
                    id={`ration-${pen.id}`}
                    value={getPenValue(pen, 'ration') as string}
                    onChange={(e) => updatePenLocal(pen.id, { ration: e.target.value })}
                    onBlur={() => savePen(pen.id)}
                    placeholder="Grower, Finisher, etc."
                    className="mt-1"
                    data-testid={`input-ration-${pen.id}`}
                  />
                </div>

                <div>
                  <Label htmlFor={`headCount-${pen.id}`} className="text-xs">Head Count</Label>
                  <Input
                    id={`headCount-${pen.id}`}
                    type="number"
                    value={getPenValue(pen, 'headCount') as number}
                    onChange={(e) => updatePenLocal(pen.id, { headCount: Number(e.target.value) })}
                    onBlur={() => savePen(pen.id)}
                    className="mt-1 font-mono"
                    data-testid={`input-headcount-${pen.id}`}
                  />
                </div>

                <div>
                  <Label htmlFor={`kgPerHead-${pen.id}`} className="text-xs">kg/Head/Day</Label>
                  <Input
                    id={`kgPerHead-${pen.id}`}
                    type="number"
                    step="0.1"
                    value={getPenValue(pen, 'kgPerHead') as number}
                    onChange={(e) => updatePenLocal(pen.id, { kgPerHead: Number(e.target.value) })}
                    onBlur={() => savePen(pen.id)}
                    className="mt-1 font-mono"
                    data-testid={`input-kgperhead-${pen.id}`}
                  />
                </div>

                <div>
                  <Label htmlFor={`rationPercent-${pen.id}`} className="text-xs">Type Adjust %</Label>
                  <Input
                    id={`rationPercent-${pen.id}`}
                    type="number"
                    value={(getPenValue(pen, 'rationPercent') ?? 100) as number}
                    onChange={(e) => updatePenLocal(pen.id, { rationPercent: Number(e.target.value) })}
                    onBlur={() => savePen(pen.id)}
                    className="mt-1 font-mono"
                    data-testid={`input-rationpercent-${pen.id}`}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex-1">
                    <div className="text-xs text-muted-foreground mb-1">Daily Total</div>
                    <Badge variant="outline" className="font-mono text-sm">
                      {dailyTotal}
                    </Badge>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Switch
                    id={`active-${pen.id}`}
                    checked={pen.active}
                    onCheckedChange={async (checked) => {
                      if (!isUnlocked && !(await ensureUnlocked())) return;
                      updatePen(pen.id, { active: checked });
                    }}
                    data-testid={`switch-active-${pen.id}`}
                  />
                  <Label htmlFor={`active-${pen.id}`} className="text-xs cursor-pointer">
                    {pen.active ? "Active" : "Inactive"}
                  </Label>
                </div>

                <div className="flex items-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removePen(pen.id)}
                    className="text-destructive hover:text-destructive"
                    data-testid={`button-delete-${pen.id}`}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </Button>
                </div>
              </div>
            )}
          </Card>
          );
        })}
      </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            {filter ? "No pens match your filter." : "No pens yet. Click 'Add Pen' to get started."}
          </div>
        )}
      </Card>
    </>
  );
}
