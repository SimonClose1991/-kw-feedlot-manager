import type { FeedRunSummary } from "@shared/types";
import { formatKg } from "@/lib/utils";
import { Card } from "@/components/ui/card";

interface RunTotalsProps {
  run: FeedRunSummary;
}

export function RunTotals({ run }: RunTotalsProps) {
  const totalKg = run.events.reduce((s, e) => s + e.totalKg, 0);
  const byRation = run.events.reduce<Record<string, number>>((acc, e) => {
    acc[e.ration] = (acc[e.ration] ?? 0) + e.totalKg;
    return acc;
  }, {});

  return (
    <div>
      <div className="text-sm text-muted-foreground">
        This run totals ({run.period} · {Math.round(run.splitFraction*100)}%)
      </div>
      <div className="text-3xl font-bold mt-1 font-mono" data-testid="text-total-kg">{formatKg(totalKg)}</div>
      <div className="mt-1 text-xs text-muted-foreground">Feeder: {run.feeder || "—"}</div>
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
        {Object.entries(byRation).map(([ration, kg]) => (
          <Card key={ration} className="bg-muted/50 border-muted px-3 py-2">
            <div className="text-xs text-muted-foreground">{ration}</div>
            <div className="font-semibold font-mono">{formatKg(kg)}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}
