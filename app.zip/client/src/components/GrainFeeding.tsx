import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerFooter, DrawerClose } from "@/components/ui/drawer";
import { Checkbox } from "@/components/ui/checkbox";
import { Download, Pause, Play, RotateCcw, Upload, Plus, Trash2, Pencil, Check, GripVertical, Save, Loader2, CheckCircle, AlertCircle } from "lucide-react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

const fmtKg = (n:number) => `${(n ?? 0).toLocaleString(undefined, { maximumFractionDigits: 2 })} kg`;
const fmtSec = (n:number) => `${Math.max(0, n|0)} sec`;

interface PaddockRow {
  id: string;
  paddock: string;
  mob: string;
  head: number;
  kgPerHead: number;
  rationPct: number;
}

interface RosterState {
  farm: string;
  feedRateKgPerSec: number;
  rows: PaddockRow[];
}

interface GrainRosterData {
  id: string;
  farm: string;
  feedRateKgPerSec: number;
  rows: PaddockRow[];
}

const sampleRows: PaddockRow[] = [
  { id: crypto.randomUUID(), paddock: "Pen 1", mob: "Merino Ewes", head: 100, kgPerHead: 2.5, rationPct: 100 },
  { id: crypto.randomUUID(), paddock: "Pen 2", mob: "Cross Lambs", head: 80, kgPerHead: 2.3, rationPct: 80 },
  { id: crypto.randomUUID(), paddock: "Pen 3", mob: "Wethers", head: 60, kgPerHead: 2.0, rationPct: 75 },
];

async function parseFile(file: File): Promise<PaddockRow[]> {
  const ext = file.name.toLowerCase().split('.').pop();
  if (ext === 'csv') {
    const text = await file.text();
    return parseCSV(text);
  } else {
    const XLSX = await import('xlsx');
    const data = await file.arrayBuffer();
    const wb = XLSX.read(data, { type: 'array' });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const json: any[] = XLSX.utils.sheet_to_json(sheet, { defval: '' });
    return normaliseRows(json);
  }
}

function parseCSV(text: string): PaddockRow[] {
  const lines = text.split(/\r?\n/).filter(Boolean);
  const [header, ...rows] = lines;
  const cols = header.split(',').map((s) => s.trim().toLowerCase());
  const idx = {
    paddock: cols.findIndex((c) => c.includes('paddock') || c.includes('pen')),
    mob: cols.findIndex((c) => c.includes('mob')),
    head: cols.findIndex((c) => c === 'head' || c.includes('head')),
    kg: cols.findIndex((c) => c.includes('kg') && c.includes('head')),
    pct: cols.findIndex((c) => c.includes('%') || c.includes('ration')),
  };
  return rows.map((line) => {
    const cells = line.split(',');
    const paddock = cells[idx.paddock] ?? '';
    const mob = cells[idx.mob] ?? '';
    const head = Number(cells[idx.head] ?? 0);
    const kgPerHead = Number(cells[idx.kg] ?? 0);
    const rationPct = Number((cells[idx.pct] ?? '100').toString().replace('%',''));
    return { id: crypto.randomUUID(), paddock, mob, head, kgPerHead, rationPct };
  }).filter(r => r.paddock);
}

function normaliseRows(json: any[]): PaddockRow[] {
  return json.map((r) => {
    const paddock = r.Paddock ?? r.Pen ?? r["Pen "] ?? r.paddock ?? r.pen ?? '';
    const mob = r.Mob ?? r.mob ?? '';
    const head = Number(r.Head ?? r.head ?? 0);
    const kgPerHead = Number(r["Kg/Head"] ?? r.kgPerHead ?? r.KgPerHead ?? r["Kg per Head"] ?? 0);
    const rationRaw = r["Ration %"] ?? r.Ration ?? r.rationPct ?? r["Ration % "] ?? 100;
    const rationPct = Number(String(rationRaw).replace('%',''));
    return { id: crypto.randomUUID(), paddock, mob, head, kgPerHead, rationPct } as PaddockRow;
  }).filter(r => r.paddock);
}

function useTimer() {
  const [running, setRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const lastTick = useRef<number | null>(null);

  useEffect(() => {
    let raf: number | null = null;
    function loop(ts: number) {
      if (running) {
        if (lastTick.current == null) lastTick.current = ts;
        const dt = (ts - (lastTick.current || ts)) / 1000;
        lastTick.current = ts;
        setElapsed((e) => e + dt);
      } else {
        lastTick.current = null;
      }
      raf = requestAnimationFrame(loop);
    }
    raf = requestAnimationFrame(loop);
    return () => { if (raf) cancelAnimationFrame(raf); };
  }, [running]);

  const start = () => setRunning(true);
  const pause = () => setRunning(false);
  const reset = () => { setRunning(false); setElapsed(0); lastTick.current = null; };

  return { running, elapsed, start, pause, reset };
}

function MobileEditDrawer({ row, isOpen, onClose, updateRow }: {
  row: PaddockRow;
  isOpen: boolean;
  onClose: () => void;
  updateRow: (id: string, patch: Partial<PaddockRow>) => void;
}) {
  const [formData, setFormData] = useState(row);

  useEffect(() => {
    setFormData(row);
  }, [row]);

  const handleSave = () => {
    updateRow(row.id, formData);
    onClose();
  };

  return (
    <Drawer open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>Edit Paddock</DrawerTitle>
        </DrawerHeader>
        <div className="px-4 py-6 space-y-4">
          <div>
            <Label htmlFor="edit-paddock" className="text-base">Paddock Name</Label>
            <Input
              id="edit-paddock"
              value={formData.paddock}
              onChange={(e) => setFormData({ ...formData, paddock: e.target.value })}
              className="min-h-[44px] text-lg mt-2"
              data-testid={`drawer-input-paddock-${row.id}`}
            />
          </div>
          <div>
            <Label htmlFor="edit-mob" className="text-base">Mob Type</Label>
            <Input
              id="edit-mob"
              value={formData.mob}
              onChange={(e) => setFormData({ ...formData, mob: e.target.value })}
              className="min-h-[44px] text-lg mt-2"
              data-testid={`drawer-input-mob-${row.id}`}
            />
          </div>
          <div>
            <Label htmlFor="edit-head" className="text-base">Head Count</Label>
            <Input
              id="edit-head"
              type="number"
              value={formData.head || ''}
              onChange={(e) => setFormData({ ...formData, head: Number(e.target.value || 0) })}
              className="min-h-[44px] text-lg mt-2"
              data-testid={`drawer-input-head-${row.id}`}
            />
          </div>
          <div>
            <Label htmlFor="edit-kg" className="text-base">Kg per Head</Label>
            <Input
              id="edit-kg"
              type="number"
              step="0.1"
              value={formData.kgPerHead || ''}
              onChange={(e) => setFormData({ ...formData, kgPerHead: Number(e.target.value || 0) })}
              className="min-h-[44px] text-lg mt-2"
              data-testid={`drawer-input-kg-${row.id}`}
            />
          </div>
          <div>
            <Label htmlFor="edit-ration" className="text-base">Ration %</Label>
            <Input
              id="edit-ration"
              type="number"
              value={formData.rationPct || ''}
              onChange={(e) => setFormData({ ...formData, rationPct: Number(e.target.value || 0) })}
              className="min-h-[44px] text-lg mt-2"
              data-testid={`drawer-input-ration-${row.id}`}
            />
          </div>
        </div>
        <DrawerFooter>
          <Button onClick={handleSave} className="min-h-[44px] text-lg" data-testid={`drawer-button-save-${row.id}`}>
            Save Changes
          </Button>
          <DrawerClose asChild>
            <Button variant="outline" className="min-h-[44px] text-lg" data-testid={`drawer-button-cancel-${row.id}`}>
              Cancel
            </Button>
          </DrawerClose>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

function SortableRow({ row, state, isEditing, setEditingId, updateRow, removeRow }: {
  row: PaddockRow;
  state: RosterState;
  isEditing: boolean;
  setEditingId: (id: string | null) => void;
  updateRow: (id: string, patch: Partial<PaddockRow>) => void;
  removeRow: (id: string) => void;
}) {
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: row.id });
  const style = { transform: CSS.Transform.toString(transform), transition };

  const total = row.head * row.kgPerHead * (row.rationPct / 100);
  const sec = total / Math.max(0.0001, state.feedRateKgPerSec);

  return (
    <div ref={setNodeRef} style={style} className="rounded-md border bg-card mb-2" data-testid={`row-paddock-${row.id}`}>
      {/* Desktop grid view (md and up) */}
      <div className="hidden md:grid grid-cols-16 gap-2 items-center p-2">
        <div className="col-span-1 flex items-center">
          <div {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing p-2 hover-elevate rounded min-h-[44px] min-w-[44px] flex items-center justify-center">
            <GripVertical className="h-5 w-5 text-muted-foreground" />
          </div>
        </div>
        <div className="col-span-3">
          {isEditing ? (
            <Input value={row.paddock} onChange={(e) => updateRow(row.id, { paddock: e.target.value })} data-testid={`input-paddock-${row.id}`} />
          ) : (
            <div className="font-medium">{row.paddock}</div>
          )}
        </div>
        <div className="col-span-3">
          {isEditing ? (
            <Input value={row.mob} onChange={(e) => updateRow(row.id, { mob: e.target.value })} data-testid={`input-mob-${row.id}`} />
          ) : (
            <div className="text-muted-foreground">{row.mob || '-'}</div>
          )}
        </div>
        <div className="col-span-2">
          {isEditing ? (
            <Input type="number" value={row.head || ''} onChange={(e) => updateRow(row.id, { head: Number(e.target.value || 0) })} data-testid={`input-head-${row.id}`} />
          ) : (
            <div>{row.head.toLocaleString()}</div>
          )}
        </div>
        <div className="col-span-2">
          {isEditing ? (
            <Input type="number" step="0.1" value={row.kgPerHead || ''} onChange={(e) => updateRow(row.id, { kgPerHead: Number(e.target.value || 0) })} data-testid={`input-kg-${row.id}`} />
          ) : (
            <div>{row.kgPerHead}</div>
          )}
        </div>
        <div className="col-span-2">
          {isEditing ? (
            <div className="flex items-center gap-2">
              <Input type="number" value={row.rationPct || ''} onChange={(e) => updateRow(row.id, { rationPct: Number(e.target.value || 0) })} data-testid={`input-ration-${row.id}`} />
              <span className="text-muted-foreground text-sm">%</span>
            </div>
          ) : (
            <div>{row.rationPct}%</div>
          )}
        </div>
        <div className="col-span-2">
          <div className="font-semibold">{fmtKg(total)}</div>
          <div className="text-xs text-muted-foreground">{fmtSec(sec)}</div>
        </div>
        <div className="col-span-1 flex justify-end gap-2">
          {isEditing ? (
            <Button size="icon" variant="outline" onClick={() => setEditingId(null)} title="Save" data-testid={`button-save-${row.id}`}><Check className="h-4 w-4"/></Button>
          ) : (
            <Button size="icon" variant="outline" onClick={() => setEditingId(row.id)} title="Edit" data-testid={`button-edit-${row.id}`}><Pencil className="h-4 w-4"/></Button>
          )}
          <Button size="icon" variant="destructive" onClick={() => removeRow(row.id)} title="Delete" data-testid={`button-delete-${row.id}`}><Trash2 className="h-4 w-4"/></Button>
        </div>
      </div>

      {/* Mobile card view (below md) */}
      <div className="md:hidden p-3 space-y-3">
        <div className="flex items-start gap-3">
          <div {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing p-2 hover-elevate rounded min-h-[44px] min-w-[44px] flex items-center justify-center border">
            <GripVertical className="h-6 w-6 text-muted-foreground" />
          </div>
          <div className="flex-1 space-y-2">
            <div>
              <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Paddock</div>
              <div className="text-lg font-bold">{row.paddock}</div>
            </div>
            <div>
              <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Mob</div>
              <div className="text-base">{row.mob || '-'}</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Head</div>
            <div className="text-lg font-mono font-bold">{row.head.toLocaleString()}</div>
          </div>
          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Kg/Head</div>
            <div className="text-lg font-mono font-bold">{row.kgPerHead}</div>
          </div>
          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Ration %</div>
            <div className="text-lg font-mono font-bold">{row.rationPct}%</div>
          </div>
          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Total</div>
            <div className="text-lg font-mono font-bold">{fmtKg(total)}</div>
            <div className="text-xs text-muted-foreground">{fmtSec(sec)}</div>
          </div>
        </div>

        <div className="flex gap-2 pt-2 border-t">
          <Button className="flex-1 min-h-[44px]" variant="outline" onClick={() => setMobileDrawerOpen(true)} data-testid={`button-edit-${row.id}`}>
            <Pencil className="h-4 w-4 mr-2"/>Edit
          </Button>
          <Button className="min-h-[44px]" size="icon" variant="destructive" onClick={() => removeRow(row.id)} title="Delete" data-testid={`button-delete-${row.id}`}>
            <Trash2 className="h-4 w-4"/>
          </Button>
        </div>
      </div>

      {/* Mobile edit drawer */}
      <MobileEditDrawer
        row={row}
        isOpen={mobileDrawerOpen}
        onClose={() => setMobileDrawerOpen(false)}
        updateRow={updateRow}
      />
    </div>
  );
}

function RosterEditor({ farm }: { farm: string }) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isHydrated, setIsHydrated] = useState(false);
  const lastSavedRef = useRef<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'pending' | 'error'>('saved');
  const pendingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { data: roster, isLoading, isError } = useQuery<GrainRosterData | null>({
    queryKey: ["/api/grain-rosters", farm],
    queryFn: async () => {
      const res = await fetch(`/api/grain-rosters/${farm}`);
      if (!res.ok && res.status !== 404) {
        throw new Error('Failed to fetch roster');
      }
      if (res.status === 404 || res.status === 204) {
        return null;
      }
      return res.json();
    },
    retry: 1,
  });

  const [state, setState] = useState<RosterState>({
    farm,
    feedRateKgPerSec: 4,
    rows: [],
  });

  useEffect(() => {
    if (isError || isLoading) return;
    
    if (roster && roster.rows) {
      setState({
        farm: roster.farm,
        feedRateKgPerSec: roster.feedRateKgPerSec,
        rows: roster.rows,
      });
      lastSavedRef.current = JSON.stringify({
        farm: roster.farm,
        feedRateKgPerSec: roster.feedRateKgPerSec,
        rows: roster.rows,
      });
      setIsHydrated(true);
      setSaveStatus('saved');
    } else if (roster === null) {
      const initialState = {
        farm,
        feedRateKgPerSec: 4,
        rows: sampleRows,
      };
      setState(initialState);
      lastSavedRef.current = JSON.stringify(initialState);
      setIsHydrated(true);
      setSaveStatus('saved');
    }
  }, [roster, isLoading, isError, farm]);

  const saveMutation = useMutation({
    mutationFn: async (data: Omit<GrainRosterData, 'id'>) => {
      return await apiRequest('/api/grain-rosters', 'POST', data);
    },
    onSuccess: (_data, variables) => {
      lastSavedRef.current = JSON.stringify(variables);
      setSaveStatus('saved');
      queryClient.invalidateQueries({ queryKey: ["/api/grain-rosters", farm] });
    },
    onError: () => {
      setSaveStatus('error');
    },
  });

  // Immediate save function (bypasses debounce)
  const saveNow = () => {
    if (pendingTimerRef.current) {
      clearTimeout(pendingTimerRef.current);
      pendingTimerRef.current = null;
    }
    
    const currentState = JSON.stringify({
      farm: state.farm,
      feedRateKgPerSec: state.feedRateKgPerSec,
      rows: state.rows,
    });
    
    if (currentState !== lastSavedRef.current) {
      setSaveStatus('saving');
      saveMutation.mutate({
        farm: state.farm,
        feedRateKgPerSec: state.feedRateKgPerSec,
        rows: state.rows,
      });
    }
  };

  // Auto-save with debounce
  useEffect(() => {
    if (!isHydrated) return;
    
    const currentState = JSON.stringify({
      farm: state.farm,
      feedRateKgPerSec: state.feedRateKgPerSec,
      rows: state.rows,
    });
    
    if (currentState === lastSavedRef.current) return;
    
    setSaveStatus('pending');
    
    if (pendingTimerRef.current) {
      clearTimeout(pendingTimerRef.current);
    }
    
    pendingTimerRef.current = setTimeout(() => {
      setSaveStatus('saving');
      saveMutation.mutate({
        farm: state.farm,
        feedRateKgPerSec: state.feedRateKgPerSec,
        rows: state.rows,
      });
      pendingTimerRef.current = null;
    }, 500);
    
    return () => {
      if (pendingTimerRef.current) {
        clearTimeout(pendingTimerRef.current);
      }
    };
  }, [state, isHydrated]);

  // Warn user before leaving page with unsaved changes
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (saveStatus === 'pending' || saveStatus === 'saving') {
        e.preventDefault();
        e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
        return e.returnValue;
      }
    };
    
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [saveStatus]);

  // Save immediately when component unmounts (switching farms/tabs)
  useEffect(() => {
    return () => {
      if (pendingTimerRef.current) {
        clearTimeout(pendingTimerRef.current);
        // Perform synchronous save on unmount
        const currentState = JSON.stringify({
          farm: state.farm,
          feedRateKgPerSec: state.feedRateKgPerSec,
          rows: state.rows,
        });
        
        if (currentState !== lastSavedRef.current) {
          // Use fetch directly for immediate save (mutation may not complete during unmount)
          fetch('/api/grain-rosters', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              farm: state.farm,
              feedRateKgPerSec: state.feedRateKgPerSec,
              rows: state.rows,
            }),
          }).catch(console.error);
        }
      }
    };
  }, [state]);

  const totalKg = useMemo(() => state.rows.reduce((sum, r) => sum + r.head * r.kgPerHead * (r.rationPct / 100), 0), [state.rows]);
  const totalHead = useMemo(() => state.rows.reduce((sum, r) => sum + r.head, 0), [state.rows]);

  const addRow = () => setState((s) => ({ ...s, rows: [...s.rows, { id: crypto.randomUUID(), paddock: `Pen ${s.rows.length + 1}`, mob: '', head: 0, kgPerHead: 0, rationPct: 100 }] }));

  const removeRow = (id: string) => setState((s) => ({ ...s, rows: s.rows.filter((r) => r.id !== id) }));

  const updateRow = (id: string, patch: Partial<PaddockRow>) => setState((s) => ({ ...s, rows: s.rows.map((r) => r.id === id ? { ...r, ...patch } : r) }));

  const bumpAll = (deltaPct: number) => setState((s) => ({ ...s, rows: s.rows.map((r) => ({ ...r, rationPct: Math.max(0, Math.min(200, Math.round(r.rationPct + deltaPct))) })) }));

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      setState((s) => {
        const oldIndex = s.rows.findIndex((r) => r.id === active.id);
        const newIndex = s.rows.findIndex((r) => r.id === over.id);
        return { ...s, rows: arrayMove(s.rows, oldIndex, newIndex) };
      });
    }
  };

  const onImport = async (file?: File | null) => {
    if (!file) return;
    try {
      const rows = await parseFile(file);
      setState((s) => ({ ...s, rows }));
    } catch (e) {
      alert("Could not import file. Please ensure headers include Paddock, Mob, Head, Kg/Head, Ration %");
    }
  };

  const exportCSV = () => {
    const headers = ['Paddock','Mob','Head','Kg/Head','Ration %'];
    const body = state.rows.map(r => [r.paddock, r.mob, r.head, r.kgPerHead, r.rationPct].join(',')).join('\n');
    const csv = headers.join(',') + '\n' + body;
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${farm.replace(/\s+/g,'_')}_roster.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  if (isLoading) {
    return <div className="text-center py-12">Loading roster...</div>;
  }

  return (
    <div className="space-y-4">
      <FeedRunPanel roster={state} onCompleteNext={(id) => {
        setState((s) => {
          const idx = s.rows.findIndex((r) => r.id === id);
          if (idx < 0) return s;
          const row = s.rows[idx];
          const rest = s.rows.filter((r) => r.id !== id);
          return { ...s, rows: [...rest, row] };
        });
      }} />

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <span className="text-xl font-semibold">{farm} – Feeding Roster</span>
              {/* Save status indicator */}
              <div className="flex items-center gap-1.5 text-sm" data-testid="save-status">
                {saveStatus === 'saved' && (
                  <span className="flex items-center gap-1 text-green-600 dark:text-green-400">
                    <CheckCircle className="h-4 w-4" />
                    <span className="hidden sm:inline">Saved</span>
                  </span>
                )}
                {saveStatus === 'saving' && (
                  <span className="flex items-center gap-1 text-blue-600 dark:text-blue-400">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="hidden sm:inline">Saving...</span>
                  </span>
                )}
                {saveStatus === 'pending' && (
                  <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                    <Save className="h-4 w-4" />
                    <span className="hidden sm:inline">Unsaved</span>
                  </span>
                )}
                {saveStatus === 'error' && (
                  <span className="flex items-center gap-1 text-red-600 dark:text-red-400">
                    <AlertCircle className="h-4 w-4" />
                    <span className="hidden sm:inline">Error</span>
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Label className="text-sm">Feed rate (kg/sec)</Label>
              <Input
                className="w-24"
                type="number"
                step="0.1"
                value={state.feedRateKgPerSec || ''}
                onChange={(e) => setState({ ...state, feedRateKgPerSec: Math.max(0.1, Number(e.target.value || 0)) })}
                data-testid="input-feed-rate"
              />
              <Button variant="outline" size="sm" onClick={() => bumpAll(5)} data-testid="button-bump-up">+5%</Button>
              <Button variant="outline" size="sm" onClick={() => bumpAll(-5)} data-testid="button-bump-down">-5%</Button>
              <Input ref={fileInputRef} type="file" accept=".csv,.xlsx" className="hidden" onChange={(e) => onImport(e.target.files?.[0])} data-testid="input-file-import" />
              <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} data-testid="button-import"><Upload className="h-4 w-4 mr-2"/>Import</Button>
              <Button variant="outline" size="sm" onClick={exportCSV} data-testid="button-export"><Download className="h-4 w-4 mr-2"/>Export</Button>
              <Button size="sm" onClick={addRow} data-testid="button-add-row"><Plus className="h-4 w-4 mr-2"/>Add</Button>
              {(saveStatus === 'pending' || saveStatus === 'error') && (
                <Button 
                  size="sm" 
                  variant={saveStatus === 'error' ? 'destructive' : 'default'}
                  onClick={saveNow}
                  disabled={saveMutation.isPending}
                  data-testid="button-save-now"
                >
                  <Save className="h-4 w-4 mr-2"/>
                  {saveStatus === 'error' ? 'Retry Save' : 'Save Now'}
                </Button>
              )}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <div className="hidden md:grid grid-cols-16 gap-2 px-1 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide sticky top-0 bg-card z-10 border-b">
            <div className="col-span-1"></div>
            <div className="col-span-3">Paddock</div>
            <div className="col-span-3">Mob</div>
            <div className="col-span-2">Head</div>
            <div className="col-span-2">Kg/Head</div>
            <div className="col-span-2">Ration %</div>
            <div className="col-span-2">Total kg</div>
            <div className="col-span-1 text-right">Actions</div>
          </div>
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <SortableContext items={state.rows.map(r => r.id)} strategy={verticalListSortingStrategy}>
              {state.rows.map((r) => (
                <SortableRow
                  key={r.id}
                  row={r}
                  state={state}
                  isEditing={editingId === r.id}
                  setEditingId={setEditingId}
                  updateRow={updateRow}
                  removeRow={removeRow}
                />
              ))}
            </SortableContext>
          </DndContext>
          <div className="grid grid-cols-2 gap-4 mt-3 pt-3 border-t">
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">Total sheep</div>
              <div className="text-base font-bold" data-testid="text-total-head">{totalHead.toLocaleString()} hd</div>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">Total feed</div>
              <div className="text-base font-bold" data-testid="text-grand-total">{fmtKg(totalKg)}</div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <GrainFeedHistory farm={farm} />
    </div>
  );
}

function GrainFeedHistory({ farm }: { farm: string }) {
  const { data: runs, isLoading } = useQuery({
    queryKey: ["/api/grain-feed-runs", farm],
    queryFn: async () => {
      const res = await fetch(`/api/grain-feed-runs?farm=${encodeURIComponent(farm)}`);
      if (!res.ok) throw new Error('Failed to fetch feed runs');
      return res.json();
    },
  });

  if (isLoading) {
    return <div className="text-center py-4">Loading history...</div>;
  }

  if (!runs || runs.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Feed History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-8">No feed runs recorded yet</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Feed History – {farm}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {runs.map((run: any) => (
            <div key={run.id} className="border rounded-md p-4" data-testid={`feed-run-${run.id}`}>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <div>
                  <div className="font-semibold text-lg">{run.feeder}</div>
                  <div className="text-sm text-muted-foreground">
                    {new Date(run.finishedAt).toLocaleString()}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold">{fmtKg(run.totalKg)}</div>
                  <div className="text-xs text-muted-foreground">
                    {Math.floor(run.totalSeconds / 60)}m {run.totalSeconds % 60}s @ {run.feedRateKgPerSec} kg/s
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium text-muted-foreground">Paddocks fed:</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {run.paddocks?.map((p: any, i: number) => (
                    <div key={i} className="text-sm bg-muted/30 rounded p-2">
                      <div className="font-medium">{p.paddock}</div>
                      {p.mob && <div className="text-muted-foreground text-xs">{p.mob}</div>}
                      <div className="text-xs text-muted-foreground">
                        {p.head} hd × {p.kgPerHead} kg × {p.rationPct}% = {fmtKg(p.actualKg)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function FeedRunPanel({ roster, onCompleteNext }: { roster: RosterState; onCompleteNext: (rowId: string) => void }) {
  const [selectedId, setSelectedId] = useState<string | null>(roster.rows[0]?.id ?? null);
  const [feederName, setFeederName] = useState<string>('');
  const [showFeederDialog, setShowFeederDialog] = useState(false);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [fedPaddocks, setFedPaddocks] = useState<any[]>([]);
  const [dualBin, setDualBin] = useState(false);
  
  useEffect(() => { if (!selectedId && roster.rows[0]) setSelectedId(roster.rows[0].id); }, [roster.rows, selectedId]);

  const current = roster.rows.find((r) => r.id === selectedId) ?? roster.rows[0];
  const feedRate = Math.max(0.0001, roster.feedRateKgPerSec);
  const targetKg = current ? current.head * current.kgPerHead * (current.rationPct / 100) : 0;
  const effectiveFeedRate = dualBin ? feedRate * 2 : feedRate;
  const targetSec = targetKg / effectiveFeedRate;
  const { running, elapsed, start, pause, reset } = useTimer();
  
  const saveFeedRunMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/grain-feed-runs', 'POST', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/grain-feed-runs", roster.farm] });
    },
  });
  
  const handleStartTimer = () => {
    if (!feederName.trim()) {
      setShowFeederDialog(true);
    } else {
      setStartTime(new Date());
      start();
    }
  };
  
  const handleFeederDialogConfirm = () => {
    if (feederName.trim()) {
      setShowFeederDialog(false);
      setStartTime(new Date());
      start();
    }
  };
  
  const handleCompletePaddock = () => {
    if (!current) return;
    
    const paddockData = {
      paddock: current.paddock,
      mob: current.mob,
      head: current.head,
      kgPerHead: current.kgPerHead,
      rationPct: current.rationPct,
      actualKg: targetKg,
    };
    
    const updatedFedPaddocks = [...fedPaddocks, paddockData];
    setFedPaddocks(updatedFedPaddocks);
    
    const currentIndex = roster.rows.findIndex(r => r.id === current.id);
    const nextPaddock = roster.rows[currentIndex + 1];
    
    onCompleteNext(current.id);
    reset();
    
    if (nextPaddock) {
      setSelectedId(nextPaddock.id);
    } else {
      if (feederName && startTime) {
        const totalKg = updatedFedPaddocks.reduce((sum, p) => sum + p.actualKg, 0);
        const totalSeconds = Math.floor((new Date().getTime() - startTime.getTime()) / 1000);
        
        saveFeedRunMutation.mutate({
          farm: roster.farm,
          feeder: feederName,
          startedAt: startTime,
          finishedAt: new Date(),
          feedRateKgPerSec: effectiveFeedRate,
          totalKg,
          totalSeconds,
          paddocks: updatedFedPaddocks,
        });
      }
      
      setFedPaddocks([]);
      setStartTime(null);
      setSelectedId(roster.rows[0]?.id ?? null);
    }
  };

  const buzzedRef = useRef(false);
  useEffect(() => {
    if (!running && elapsed === 0) {
      buzzedRef.current = false;
      return;
    }
    if (!buzzedRef.current && elapsed >= targetSec && targetSec > 0) {
      buzzedRef.current = true;
      pause();
      try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.value = 880;
        gain.gain.value = 0.3;
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        setTimeout(() => {
          osc.stop();
          ctx.close();
        }, 1000);
      } catch (err) {
        console.error('Audio not available:', err);
      }
    }
  }, [elapsed, targetSec, running, pause]);

  const pct = Math.min(100, (elapsed / targetSec) * 100);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Feed Run</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
          <div>
            <Label>Select paddock</Label>
            <Select value={current?.id} onValueChange={(v) => setSelectedId(v)}>
              <SelectTrigger data-testid="select-paddock">
                <SelectValue placeholder="Choose paddock" />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                {roster.rows.map((r) => (
                  <SelectItem key={r.id} value={r.id}>{r.paddock} · {r.head} hd · {r.kgPerHead} kg/hd · {r.rationPct}%</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Calculated total to feed</Label>
            <div className="text-2xl font-bold" data-testid="text-target-kg">{fmtKg(targetKg)}</div>
            <div className="text-xs text-muted-foreground">{fmtSec(targetSec)} @ {effectiveFeedRate.toFixed(2)} kg/s{dualBin ? ' (dual bin)' : ''}</div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button onClick={handleStartTimer} disabled={running} data-testid="button-timer-start"><Play className="h-4 w-4 mr-1"/>Start</Button>
            <Button variant="outline" onClick={pause} disabled={!running} data-testid="button-timer-pause"><Pause className="h-4 w-4 mr-1"/>Pause</Button>
            <Button variant="outline" onClick={reset} data-testid="button-timer-reset"><RotateCcw className="h-4 w-4 mr-1"/>Reset</Button>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Checkbox 
            id="dual-bin" 
            checked={dualBin} 
            onCheckedChange={(checked) => setDualBin(checked === true)}
            data-testid="checkbox-dual-bin"
          />
          <Label htmlFor="dual-bin" className="cursor-pointer">
            Dual bin (2x speed)
          </Label>
        </div>

        <div>
          <Label>Timer</Label>
          <div className="text-3xl font-mono font-bold" data-testid="text-timer-elapsed">{fmtSec(elapsed)}</div>
          <div className="mt-2">
            <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-chart-1 transition-all" style={{ width: `${pct}%` }} />
            </div>
            <div className="mt-1 text-xs text-muted-foreground">{pct.toFixed(0)}% of target</div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            className="bg-chart-1 hover:bg-chart-1/90"
            onClick={handleCompletePaddock}
            data-testid="button-complete-next"
          >Fed – Next paddock</Button>
        </div>
      </CardContent>
      
      <Dialog open={showFeederDialog} onOpenChange={setShowFeederDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Enter Feeder Name</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="feeder-name">Feeder Name</Label>
            <Input
              id="feeder-name"
              value={feederName}
              onChange={(e) => setFeederName(e.target.value)}
              placeholder="Enter your name"
              onKeyDown={(e) => e.key === 'Enter' && handleFeederDialogConfirm()}
              data-testid="input-feeder-name"
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowFeederDialog(false)}>Cancel</Button>
            <Button onClick={handleFeederDialogConfirm} disabled={!feederName.trim()}>Start Timer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

export function GrainFeeding() {
  const [activeFarm, setActiveFarm] = useState<string>("KW");

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Grain Feeding</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeFarm} onValueChange={setActiveFarm}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="KW" data-testid="tab-kw">KW</TabsTrigger>
              <TabsTrigger value="Arundale" data-testid="tab-arundale">Arundale</TabsTrigger>
              <TabsTrigger value="Mooralla" data-testid="tab-mooralla">Mooralla</TabsTrigger>
            </TabsList>
            <TabsContent value="KW" className="mt-4">
              <RosterEditor farm="KW" />
            </TabsContent>
            <TabsContent value="Arundale" className="mt-4">
              <RosterEditor farm="Arundale" />
            </TabsContent>
            <TabsContent value="Mooralla" className="mt-4">
              <RosterEditor farm="Mooralla" />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
