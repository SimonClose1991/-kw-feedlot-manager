import { useState, useMemo } from "react";
import type { Pen } from "@shared/types";
import { formatKg, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

interface RationTabProps {
  pens: Pen[];
}

type RationPeriod = "AM" | "PM" | "ALL_DAY";

export function RationTab({ pens }: RationTabProps) {
  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: api.settings.get,
  });

  const splitPrefs = useMemo(() => ({
    AM: settings?.splitAM ?? 0.6,
    PM: settings?.splitPM ?? 0.4
  }), [settings]);

  const ingredients = useMemo(() => settings?.ingredients ?? [], [settings]);

  const bufferMultiplier = useMemo(() => {
    return 1 + ((settings?.bufferPercent ?? 0) / 100);
  }, [settings?.bufferPercent]);

  const [period, setPeriod] = useState<RationPeriod>("AM");
  const [loadTargetKg, setLoadTargetKg] = useState<string>("");

  const activePens = useMemo(() => pens.filter(p => p.active), [pens]);

  const totalHeadCount = useMemo(() => {
    return activePens.reduce((sum, pen) => sum + pen.headCount, 0);
  }, [activePens]);

  const effectiveHeadCount = useMemo(() => {
    return activePens.reduce((sum, pen) => {
      const rationMultiplier = (pen.rationPercent ?? 100) / 100;
      return sum + (pen.headCount * rationMultiplier);
    }, 0);
  }, [activePens]);

  const splitFraction = useMemo(() => {
    if (period === "ALL_DAY") return 1.0;
    return splitPrefs[period];
  }, [period, splitPrefs]);

  const totalRatioPerHead = useMemo(() => {
    return ingredients.reduce((sum, ing) => sum + ing.kgPerHead, 0);
  }, [ingredients]);

  const calculations = useMemo(() => {
    const base = effectiveHeadCount * splitFraction;
    return ingredients.map(ing => ({
      name: ing.name,
      kgPerHead: ing.kgPerHead,
      amount: base * ing.kgPerHead * bufferMultiplier,
    }));
  }, [effectiveHeadCount, splitFraction, ingredients, bufferMultiplier]);

  const totalMixerLoad = calculations.reduce((sum, c) => sum + c.amount, 0);

  // Load calculator: given a target total kg, proportion each ingredient
  const loadTarget = loadTargetKg === "" ? null : Number(loadTargetKg);
  const loadCalculations = useMemo(() => {
    if (loadTarget === null || loadTarget <= 0 || totalRatioPerHead === 0) return [];
    return ingredients.map(ing => ({
      name: ing.name,
      kgPerHead: ing.kgPerHead,
      amount: loadTarget * (ing.kgPerHead / totalRatioPerHead),
    }));
  }, [loadTarget, ingredients, totalRatioPerHead]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold tracking-tight mb-1">Mixer Wagon Ration</h2>
        <p className="text-sm text-muted-foreground">
          Calculate ingredient quantities for filling the mixer wagon
        </p>
      </div>

      <Card className="p-6 space-y-6">
        <div className="space-y-3">
          <Label className="text-sm font-medium">Select Feeding Period</Label>
          <div className="flex gap-2">
            <Button
              onClick={() => setPeriod("AM")}
              variant={period === "AM" ? "default" : "outline"}
              size="default"
              className="flex-1"
              data-testid="button-period-am"
            >
              AM ({Math.round(splitPrefs.AM * 100)}%)
            </Button>
            <Button
              onClick={() => setPeriod("PM")}
              variant={period === "PM" ? "default" : "outline"}
              size="default"
              className="flex-1"
              data-testid="button-period-pm"
            >
              PM ({Math.round(splitPrefs.PM * 100)}%)
            </Button>
            <Button
              onClick={() => setPeriod("ALL_DAY")}
              variant={period === "ALL_DAY" ? "default" : "outline"}
              size="default"
              className="flex-1"
              data-testid="button-period-all-day"
            >
              All Day (100%)
            </Button>
          </div>
        </div>

        <div className="h-px bg-border" />

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <div className="text-sm text-muted-foreground">Active Pens</div>
            <div className="text-2xl font-mono font-semibold" data-testid="text-active-pens">
              {activePens.length}
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-sm text-muted-foreground">Total Head Count</div>
            <div className="text-2xl font-mono font-semibold" data-testid="text-total-head">
              {totalHeadCount.toLocaleString()}
            </div>
          </div>
          <div className="space-y-1 col-span-2">
            <div className="text-sm text-muted-foreground">Effective Head Count (with ration %)</div>
            <div className="text-2xl font-mono font-semibold text-primary" data-testid="text-effective-head">
              {effectiveHeadCount.toLocaleString(undefined, { maximumFractionDigits: 1 })}
            </div>
            <div className="text-xs text-muted-foreground">
              Accounts for each pen's ration percentage
            </div>
          </div>
        </div>

        <div className="h-px bg-border" />

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-medium">Ingredient Quantities</h3>
            <Badge variant="secondary" data-testid="text-period-label">
              {period === "ALL_DAY" ? "All Day" : period} Feed
            </Badge>
          </div>

          {calculations.length > 0 ? (
            <div className="space-y-3">
              {calculations.map((c, i) => (
                <IngredientRow
                  key={i}
                  name={c.name}
                  ratio={c.kgPerHead}
                  amount={c.amount}
                  testId={`ingredient-${i}`}
                />
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground py-2">
              No ingredients configured. Add them in Settings.
            </p>
          )}
        </div>

        <div className="h-px bg-border" />

        <div className="flex items-center justify-between p-4 rounded-lg bg-primary/5 border border-primary/20">
          <div className="font-medium text-lg">Total Mixer Load</div>
          <div className="text-3xl font-mono font-bold text-primary" data-testid="text-total-mixer-load">
            {formatKg(totalMixerLoad)}
          </div>
        </div>

        <div className="text-xs text-muted-foreground space-y-1">
          <div>Formula: {period === "ALL_DAY" ? "100%" : `${Math.round(splitFraction * 100)}%`} × {effectiveHeadCount.toLocaleString(undefined, { maximumFractionDigits: 1 })} effective head × ingredient ratio{(settings?.bufferPercent ?? 0) > 0 ? ` × ${bufferMultiplier.toFixed(2)} buffer` : ''}</div>
          {ingredients.length > 0 && (
            <div>Ratios: {ingredients.map(ing => `${ing.name} ${ing.kgPerHead}kg`).join(", ")} per head</div>
          )}
          <div className="text-primary">Note: Effective head count includes each pen's ration percentage</div>
          {(settings?.bufferPercent ?? 0) > 0 && (
            <div className="text-primary font-semibold">Buffer: +{settings?.bufferPercent}% extra feed added to account for potential boosts</div>
          )}
        </div>
      </Card>

      {/* Load Calculator */}
      <Card className="p-6 space-y-5">
        <div>
          <h3 className="text-lg font-semibold mb-1">Load Calculator</h3>
          <p className="text-sm text-muted-foreground">
            Enter a target total mix weight and see the breakdown per ingredient
          </p>
        </div>

        <div className="flex gap-3 items-end max-w-sm">
          <div className="flex-1">
            <Label className="text-xs text-muted-foreground mb-1 block">Target Total (kg)</Label>
            <Input
              type="number"
              step="100"
              min="0"
              value={loadTargetKg}
              onChange={(e) => setLoadTargetKg(e.target.value)}
              placeholder="e.g. 6000"
              className="font-mono"
              data-testid="input-load-target"
            />
          </div>
          {loadTargetKg !== "" && Number(loadTargetKg) > 0 && (
            <Button variant="ghost" size="default" onClick={() => setLoadTargetKg("")} data-testid="button-clear-load">
              Clear
            </Button>
          )}
        </div>

        {loadTarget !== null && loadTarget > 0 && (
          <>
            {ingredients.length === 0 ? (
              <p className="text-sm text-muted-foreground">No ingredients configured. Add them in Settings first.</p>
            ) : totalRatioPerHead === 0 ? (
              <p className="text-sm text-muted-foreground">All ingredients have 0 kg/head. Update the mix in Settings.</p>
            ) : (
              <div className="space-y-3">
                {loadCalculations.map((c, i) => (
                  <IngredientRow
                    key={i}
                    name={c.name}
                    ratio={c.kgPerHead}
                    amount={c.amount}
                    testId={`load-ingredient-${i}`}
                  />
                ))}
                <div className="flex items-center justify-between p-4 rounded-lg bg-primary/5 border border-primary/20 mt-2">
                  <div className="font-medium">Total</div>
                  <div className="text-2xl font-mono font-bold text-primary" data-testid="text-load-total">
                    {formatKg(loadTarget)}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Based on proportional ratios: each ingredient's share = (ingredient kg/head) ÷ (total kg/head) × target
                </p>
              </div>
            )}
          </>
        )}
      </Card>

      {activePens.length === 0 && (
        <Card className="p-8 text-center">
          <div className="text-muted-foreground">
            <p className="text-lg font-medium mb-2">No Active Pens</p>
            <p className="text-sm">Activate pens in the Pens tab to see ration calculations</p>
          </div>
        </Card>
      )}
    </div>
  );
}

interface IngredientRowProps {
  name: string;
  ratio: number;
  amount: number;
  testId: string;
}

function IngredientRow({ name, ratio, amount, testId }: IngredientRowProps) {
  return (
    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
      <div className="flex items-center gap-3">
        <div className="font-medium">{name}</div>
        <Badge variant="outline" className="font-mono text-xs">
          {ratio}kg/head
        </Badge>
      </div>
      <div className="text-2xl font-mono font-semibold" data-testid={`text-${testId}-amount`}>
        {formatKg(amount)}
      </div>
    </div>
  );
}

function Label({ className, children }: { className?: string; children: React.ReactNode }) {
  return <div className={cn("text-base font-medium", className)}>{children}</div>;
}
