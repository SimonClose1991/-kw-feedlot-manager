import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Download, Loader2 } from "lucide-react";
import { api } from "@/lib/api";
import type { FeedRunSummary, MixIngredient, Settings } from "@shared/types";

type RangeKey = "week" | "month" | "ytd" | "year" | "all" | "custom";

function startOf(range: RangeKey): Date | null {
  const now = new Date();
  switch (range) {
    case "week": { const d = new Date(now); d.setDate(d.getDate() - 7); return d; }
    case "month": { const d = new Date(now); d.setMonth(d.getMonth() - 1); return d; }
    case "ytd": return new Date(now.getFullYear(), 0, 1);
    case "year": { const d = new Date(now); d.setFullYear(d.getFullYear() - 1); return d; }
    default: return null;
  }
}

function costPerKg(ing: MixIngredient): number {
  if (!ing.costPerUnit) return 0;
  return ing.costUnit === "$/kg" ? ing.costPerUnit : ing.costPerUnit / 1000;
}

export function SheepReports() {
  const [range, setRange] = useState<RangeKey>("ytd");
  const [customStart, setCustomStart] = useState("");
  const [customEnd, setCustomEnd] = useState("");

  const { data: history, isLoading: historyLoading } = useQuery<FeedRunSummary[]>({
    queryKey: ["/api/history"],
    queryFn: api.history.getAll,
  });
  const { data: settings, isLoading: settingsLoading } = useQuery<Settings>({
    queryKey: ["/api/settings"],
    queryFn: api.settings.get,
  });

  const { rows, totalKg, totalCost, headFeedings, rangeLabel } = useMemo(() => {
    let start: Date | null = null;
    let end: Date | null = null;
    let label = "All time";

    if (range === "custom") {
      start = customStart ? new Date(customStart) : null;
      end = customEnd ? new Date(customEnd + "T23:59:59") : null;
      label = `${customStart || "start"} to ${customEnd || "now"}`;
    } else if (range !== "all") {
      start = startOf(range);
      label =
        range === "week" ? "Last 7 days" :
        range === "month" ? "Last 30 days" :
        range === "ytd" ? "Year to date" :
        range === "year" ? "Last 12 months" : "All time";
    }

    const mix = settings?.ingredients ?? [];
    const mixTotalKgPerHead = mix.reduce((s, ing) => s + (ing.kgPerHead || 0), 0);

    // For each feed event we know totalKg fed to a pen. Split that across the
    // mix by each ingredient's share of the recipe.
    const totals = new Map<string, number>(); // commodity -> kg
    let headFeedings = 0;

    (history || []).forEach((run) => {
      const t = new Date(run.startedAt);
      if (start && t < start) return;
      if (end && t > end) return;
      (run.events || []).forEach((ev) => {
        headFeedings += ev.headCount || 0;
        if (mixTotalKgPerHead > 0) {
          mix.forEach((ing) => {
            const share = (ing.kgPerHead || 0) / mixTotalKgPerHead;
            const kg = (ev.totalKg || 0) * share;
            totals.set(ing.name, (totals.get(ing.name) || 0) + kg);
          });
        } else {
          // No mix defined — bucket under a generic label so totals still show.
          totals.set("Feed (no mix defined)", (totals.get("Feed (no mix defined)") || 0) + (ev.totalKg || 0));
        }
      });
    });

    const costByName = new Map<string, number>();
    mix.forEach((ing) => costByName.set(ing.name, costPerKg(ing)));

    const rows = Array.from(totals.entries())
      .map(([name, kg]) => {
        const cpk = costByName.get(name) ?? 0;
        return { name, kg, tonnes: kg / 1000, cost: kg * cpk };
      })
      .sort((a, b) => b.kg - a.kg);

    const totalKg = rows.reduce((s, r) => s + r.kg, 0);
    const totalCost = rows.reduce((s, r) => s + r.cost, 0);

    return { rows, totalKg, totalCost, headFeedings, rangeLabel: label };
  }, [history, settings, range, customStart, customEnd]);

  const exportCsv = () => {
    const header = ["Commodity", "Total kg", "Total tonnes", "Total cost"];
    const lines = [header.join(",")];
    rows.forEach((r) => {
      lines.push([`"${r.name}"`, r.kg.toFixed(1), r.tonnes.toFixed(3), r.cost.toFixed(2)].join(","));
    });
    lines.push(["TOTAL", totalKg.toFixed(1), (totalKg / 1000).toFixed(3), totalCost.toFixed(2)].join(","));
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sheep-commodity-report-${rangeLabel.replace(/\s+/g, "-")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const isLoading = historyLoading || settingsLoading;
  const fmt = (n: number) => n.toLocaleString(undefined, { maximumFractionDigits: 1 });
  const money = (n: number) => "$" + n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return (
    <Card className="p-5">
      <h3 className="font-semibold mb-3">Commodity &amp; Cost Report</h3>

      <div className="flex flex-wrap gap-2 mb-4">
        {([
          ["week", "Last 7 days"],
          ["month", "Last 30 days"],
          ["ytd", "Year to date"],
          ["year", "Last 12 months"],
          ["all", "All time"],
          ["custom", "Custom"],
        ] as [RangeKey, string][]).map(([key, lbl]) => (
          <Button
            key={key}
            variant={range === key ? "default" : "outline"}
            size="sm"
            onClick={() => setRange(key)}
            data-testid={`sheep-range-${key}`}
          >
            {lbl}
          </Button>
        ))}
      </div>

      {range === "custom" && (
        <div className="grid grid-cols-2 gap-3 max-w-md mb-4">
          <div className="space-y-1">
            <Label className="text-xs">Start date</Label>
            <Input type="date" value={customStart} onChange={(e) => setCustomStart(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">End date</Label>
            <Input type="date" value={customEnd} onChange={(e) => setCustomEnd(e.target.value)} />
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="flex items-center justify-center py-10">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">{rangeLabel}</span>
            <Button variant="outline" size="sm" onClick={exportCsv} disabled={rows.length === 0} data-testid="sheep-export-csv">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
          {rows.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No feed records in this period.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-muted-foreground">
                    <th className="py-2 pr-4 font-medium">Commodity</th>
                    <th className="py-2 px-4 font-medium text-right">Tonnes</th>
                    <th className="py-2 px-4 font-medium text-right">kg</th>
                    <th className="py-2 pl-4 font-medium text-right">Cost</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.name} className="border-b last:border-0">
                      <td className="py-2 pr-4 font-medium">{r.name}</td>
                      <td className="py-2 px-4 text-right">{r.tonnes.toFixed(2)}</td>
                      <td className="py-2 px-4 text-right text-muted-foreground">{fmt(r.kg)}</td>
                      <td className="py-2 pl-4 text-right">{r.cost > 0 ? money(r.cost) : <span className="text-muted-foreground">—</span>}</td>
                    </tr>
                  ))}
                  <tr className="font-semibold">
                    <td className="py-2 pr-4">Total</td>
                    <td className="py-2 px-4 text-right">{(totalKg / 1000).toFixed(2)}</td>
                    <td className="py-2 px-4 text-right">{fmt(totalKg)}</td>
                    <td className="py-2 pl-4 text-right">{totalCost > 0 ? money(totalCost) : "—"}</td>
                  </tr>
                </tbody>
              </table>
              {totalCost === 0 && (
                <p className="text-xs text-muted-foreground mt-3">
                  Tip: add costs to your mix ingredients above to see dollar figures here.
                </p>
              )}
            </div>
          )}
        </>
      )}
    </Card>
  );
}
