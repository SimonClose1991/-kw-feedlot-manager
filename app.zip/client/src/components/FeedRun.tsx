import { useState, useEffect, useMemo } from "react";
import type { Pen, FeedRunSummary, FeedEvent, FeedingPeriod } from "@shared/types";
import { formatKg, isoNow, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Check, ArrowLeft, ArrowRight, TrendingUp, TrendingDown } from "lucide-react";
import { RunTotals } from "@/components/RunTotals";
import { useQuery, useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";

interface FeedRunProps {
  pens: Pen[];
  order: string[];
}

export function FeedRun({ pens, order }: FeedRunProps) {
  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: api.settings.get,
  });

  const { data: currentRun } = useQuery({
    queryKey: ["/api/current-run"],
    queryFn: api.currentRun.get,
  });

  const saveCurrentRunMutation = useMutation({
    mutationFn: api.currentRun.save,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/current-run"] });
    },
  });

  const saveSettingsMutation = useMutation({
    mutationFn: api.settings.save,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
  });

  const splitPrefs = useMemo(() => ({
    AM: settings?.splitAM ?? 0.6,
    PM: settings?.splitPM ?? 0.4
  }), [settings]);


  const activePens = useMemo(() => order
    .map(id => pens.find(p => p.id === id))
    .filter((p): p is Pen => !!p && p.active), [order, pens]);

  const [run, setRun] = useState<FeedRunSummary>(() => {
    if (currentRun) return currentRun;
    const period: FeedingPeriod = "AM";
    const splitFraction = 0.6;
    return {
      id: crypto.randomUUID(),
      startedAt: isoNow(),
      feeder: settings?.defaultFeeder ?? undefined,
      period,
      splitFraction,
      events: [],
    };
  });

  useEffect(() => {
    if (currentRun) {
      setRun(currentRun);
      setIndex(currentRun.events.length);
    }
  }, [currentRun]);

  const [index, setIndex] = useState<number>(() => run.events.length);
  const [overrideKg, setOverrideKg] = useState<string>("");

  const currentPen = activePens[index] ?? null;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === " ") { e.preventDefault(); handleFed(); }
      if (e.key === "ArrowRight") { e.preventDefault(); handleSkip(); }
      if (e.key === "ArrowLeft") { e.preventDefault(); handleUndo(); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const totalPens = activePens.length;
  const progress = Math.min(index, totalPens) / Math.max(totalPens, 1);

  function computeDailyTotalKg(p: Pen): number {
    const pct = (typeof p.rationPercent === "number" ? p.rationPercent : 100) / 100;
    return p.headCount * p.kgPerHead * pct;
  }

  function computeThisFeedKg(p: Pen): number {
    return computeDailyTotalKg(p) * run.splitFraction;
  }


  const saveHistoryMutation = useMutation({
    mutationFn: api.history.save,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/history"] });
    },
  });

  const savePensMutation = useMutation({
    mutationFn: api.pens.save,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pens"] });
    },
  });

  function addEventFor(p: Pen, fedKg: number) {
    const ev: FeedEvent = {
      runId: run.id,
      penId: p.id,
      penName: p.name,
      ration: p.ration,
      headCount: p.headCount,
      kgPerHead: p.kgPerHead,
      totalKg: fedKg,
      at: isoNow(),
      period: run.period,
      splitFraction: run.splitFraction,
    };
    const nextRun: FeedRunSummary = { ...run, events: [...run.events, ev] };
    setRun(nextRun);
    saveCurrentRunMutation.mutate(nextRun);
  }

  function handleFed() {
    if (!currentPen) return;
    const fedKg = overrideKg.trim() ? Number(overrideKg) : computeThisFeedKg(currentPen);
    if (Number.isNaN(fedKg) || fedKg <= 0) {
      alert("Please enter a valid kg amount.");
      return;
    }
    addEventFor(currentPen, fedKg);
    setOverrideKg("");
    setIndex((i) => i + 1);
  }

  function handleSkip() {
    setIndex(i => Math.min(i + 1, activePens.length));
  }

  function handleUndo() {
    if (run.events.length === 0) return;
    const last = run.events[run.events.length - 1];
    const idxOfPen = activePens.findIndex(p => p.id === last.penId);
    const nextRun = { ...run, events: run.events.slice(0, -1) };
    setRun(nextRun);
    saveCurrentRunMutation.mutate(nextRun);
    setIndex(idxOfPen >= 0 ? idxOfPen : Math.max(0, index - 1));
  }

  function handleFinish() {
    const finished: FeedRunSummary = { ...run, finishedAt: isoNow() };
    saveHistoryMutation.mutate(finished);
    saveCurrentRunMutation.mutate(null);
    const fresh: FeedRunSummary = { 
      id: crypto.randomUUID(), 
      startedAt: isoNow(), 
      feeder: run.feeder, 
      period: run.period, 
      splitFraction: run.splitFraction, 
      events: [] 
    };
    setRun(fresh);
    setIndex(0);
    setOverrideKg("");
    saveCurrentRunMutation.mutate(fresh);
    alert("Feed run saved to History.");
  }

  function handleCancelFeed() {
    if (!confirm("Cancel this feed run? All progress will be lost.")) return;
    
    const fresh: FeedRunSummary = { 
      id: crypto.randomUUID(), 
      startedAt: isoNow(), 
      feeder: settings?.defaultFeeder ?? undefined, 
      period: run.period, 
      splitFraction: run.splitFraction, 
      events: [] 
    };
    setRun(fresh);
    setIndex(0);
    setOverrideKg("");
    saveCurrentRunMutation.mutate(fresh);
  }

  function setPeriod(period: FeedingPeriod) {
    const sf = splitPrefs[period];
    const next = { ...run, period, splitFraction: sf };
    setRun(next);
    saveCurrentRunMutation.mutate(next);
  }

  function adjustRationPercent(delta: number) {
    if (!currentPen) return;
    
    const updatedPens = pens.map(pen => {
      if (pen.id !== currentPen.id) return pen;
      
      const currentPercent = pen.rationPercent ?? 100;
      const newPercent = Math.max(0, Math.min(200, currentPercent + delta));
      return { ...pen, rationPercent: newPercent, notes: undefined };
    });
    
    savePensMutation.mutate(updatedPens);
  }

  function updatePenNote(note: string) {
    if (!currentPen) return;
    
    const updatedPens = pens.map(pen => {
      if (pen.id !== currentPen.id) return pen;
      return { ...pen, notes: note || undefined };
    });
    
    savePensMutation.mutate(updatedPens);
  }

  const progressPct = Math.round(progress * 100);
  const dailyKg = useMemo(() => currentPen ? computeDailyTotalKg(currentPen) : 0, [currentPen]);
  const thisFeedKg = useMemo(() => currentPen ? computeThisFeedKg(currentPen) : 0, [currentPen, run.splitFraction]);

  if (!currentPen) {
    return (
      <div className="max-w-3xl mx-auto">
        <Card className="p-6">
          <h2 className="text-xl font-semibold">Feed Run Complete</h2>
          <p className="text-muted-foreground mt-1">All active pens have been processed.</p>

          <div className="mt-6 space-y-4">
            <div>
              <Label htmlFor="feeder-complete" className="text-sm">Feeder Name</Label>
              <Input
                id="feeder-complete"
                value={run.feeder || ""}
                onChange={(e) => {
                  const name = e.target.value;
                  const nextRun = { ...run, feeder: name };
                  setRun(nextRun);
                  saveCurrentRunMutation.mutate(nextRun);
                  saveSettingsMutation.mutate({ defaultFeeder: name });
                }}
                placeholder="Enter feeder name"
                className="max-w-xs mt-1"
                data-testid="input-feeder-complete"
              />
            </div>

            <div className="flex gap-3 flex-wrap">
              <Button onClick={handleFinish} size="default" data-testid="button-finish-run">
                Save to History & New Run
              </Button>
              <Button onClick={() => setIndex(0)} variant="outline" data-testid="button-review">
                Review
              </Button>
              <Button onClick={handleCancelFeed} variant="destructive" data-testid="button-cancel-feed">
                Cancel Feed
              </Button>
            </div>
          </div>

          <div className="mt-8">
            <RunTotals run={run} />
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <Card className="p-6">
        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <Input
              id="feeder"
              value={run.feeder || ""}
              onChange={(e) => {
                const name = e.target.value;
                const nextRun = { ...run, feeder: name };
                setRun(nextRun);
                saveCurrentRunMutation.mutate(nextRun);
                saveSettingsMutation.mutate({ defaultFeeder: name });
              }}
              placeholder="Feeder name"
              className="w-40"
              data-testid="input-feeder"
            />
            <div className="flex gap-2">
              <Button
                onClick={() => setPeriod("AM")}
                variant={run.period === "AM" ? "default" : "outline"}
                size="sm"
                data-testid="button-period-am"
              >
                AM
              </Button>
              <Button
                onClick={() => setPeriod("PM")}
                variant={run.period === "PM" ? "default" : "outline"}
                size="sm"
                data-testid="button-period-pm"
              >
                PM
              </Button>
            </div>
          </div>
          <div className="text-sm text-muted-foreground" data-testid="text-pen-progress">
            {index + 1} of {activePens.length} · {progressPct}%
          </div>
        </div>

        <div className="space-y-6">
          <Card className="p-6 bg-muted/50 border-muted">
            <div className="text-center mb-6">
              <div className="text-2xl font-bold mb-1" data-testid="text-pen-name">{currentPen.name}</div>
              <div className="text-sm text-muted-foreground" data-testid="text-pen-info">
                {currentPen.ration} · {currentPen.headCount} head · {run.period} Feed
              </div>
            </div>

            <div className="text-center mb-6">
              <div className="text-sm text-muted-foreground mb-2">Amount to Feed</div>
              <div className="text-7xl font-black font-mono" data-testid="text-feed-amount">
                {formatKg(thisFeedKg)}
              </div>
              <div className="text-xs text-muted-foreground mt-2">
                {currentPen.headCount} × {currentPen.kgPerHead.toFixed(2)} × {(currentPen.rationPercent ?? 100)}% × {Math.round(run.splitFraction*100)}%
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-4">
              <div>
                <Input
                  id="override-kg"
                  value={overrideKg}
                  onChange={e => setOverrideKg(e.target.value)}
                  placeholder={`Override (${Math.round(thisFeedKg)} kg)`}
                  inputMode="decimal"
                  className="font-mono"
                  data-testid="input-override-kg"
                />
              </div>
              <div>
                <Input
                  id="pen-note"
                  value={currentPen.notes || ""}
                  onChange={e => updatePenNote(e.target.value)}
                  placeholder="Note (e.g. UP)"
                  className="w-full"
                  data-testid="input-pen-note"
                />
              </div>
            </div>
            {currentPen.notes && (
              <div className="mt-2 text-xs text-amber-600 dark:text-amber-400 font-medium">
                📝 Persistent Note: {currentPen.notes} - Cleared when you adjust ration
              </div>
            )}

            <div className="h-px bg-border my-4" />

            <div className="flex flex-wrap gap-2">
              <Button 
                onClick={handleFed} 
                size="lg" 
                className="text-2xl font-bold px-8 hover-elevate active-elevate-2 bg-chart-1 hover:bg-chart-1 border-chart-1 flex-1 min-w-[200px]"
                data-testid="button-fed"
              >
                <Check className="w-6 h-6 mr-2" />
                FED
              </Button>
              <div className="flex gap-2">
                <Button 
                  onClick={() => adjustRationPercent(5)} 
                  size="lg"
                  className="bg-chart-2 hover:bg-chart-2 border-chart-2 hover-elevate active-elevate-2"
                  data-testid="button-bump-5"
                >
                  <TrendingUp className="w-5 h-5 mr-1" />
                  +5%
                </Button>
                <Button 
                  onClick={() => adjustRationPercent(-5)} 
                  size="lg"
                  className="bg-chart-2 hover:bg-chart-2 border-chart-2 hover-elevate active-elevate-2"
                  data-testid="button-down-5"
                >
                  <TrendingDown className="w-5 h-5 mr-1" />
                  -5%
                </Button>
              </div>
              <Button onClick={handleUndo} variant="outline" size="lg" data-testid="button-undo">
                <ArrowLeft className="w-5 h-5 mr-1" />
                Undo
              </Button>
              <Button onClick={handleSkip} variant="outline" size="lg" data-testid="button-skip">
                <ArrowRight className="w-5 h-5 mr-1" />
                Skip
              </Button>
            </div>

            <div className="mt-3 flex items-center justify-between gap-3">
              <Button onClick={handleCancelFeed} variant="ghost" size="sm" className="text-destructive hover:text-destructive" data-testid="button-cancel-feed-active">
                Cancel Feed
              </Button>
            </div>

            <div className="mt-2 flex items-center justify-between">
              <div className="text-xs text-muted-foreground">
                Shortcuts: <Badge variant="outline" className="font-mono text-xs">Space</Badge> Fed · <Badge variant="outline" className="font-mono text-xs">←</Badge> Undo · <Badge variant="outline" className="font-mono text-xs">→</Badge> Skip
              </div>
              <Badge variant="outline" className="font-mono" data-testid="text-current-percent">
                Type: {currentPen.rationPercent ?? 100}%
              </Badge>
            </div>
          </Card>

          <Card className="p-5 bg-muted/30">
            <h3 className="font-bold text-lg mb-3">UP NEXT</h3>
            <div className="space-y-2" data-testid="list-upcoming-pens">
              {activePens.slice(index + 1, index + 5).map((p, idx) => (
                <div key={p.id} className="flex items-center justify-between bg-background border border-border rounded-lg px-4 py-3">
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-lg font-mono">#{index + idx + 2}</span>
                    <span className="font-medium">{p.name}</span>
                    <span className="text-sm text-muted-foreground">{p.ration}</span>
                  </div>
                  <span className="font-bold font-mono text-lg">
                    {formatKg((p.headCount * p.kgPerHead * ((p.rationPercent ?? 100)/100) * run.splitFraction))}
                  </span>
                </div>
              ))}
              {activePens.length - (index + 1) === 0 && (
                <div className="text-sm text-muted-foreground py-2">Last pen - nothing left after this.</div>
              )}
            </div>
          </Card>
        </div>
      </Card>
    </div>
  );
}
