import { RunTotals } from "../RunTotals";
import type { FeedRunSummary } from "@shared/types";

export default function RunTotalsExample() {
  const run: FeedRunSummary = {
    id: "test-run",
    startedAt: new Date().toISOString(),
    feeder: "John Smith",
    period: "AM",
    splitFraction: 0.6,
    events: [
      {
        runId: "test-run",
        penId: "1",
        penName: "Pen 1",
        ration: "Grower",
        headCount: 400,
        kgPerHead: 1.2,
        totalKg: 288,
        at: new Date().toISOString(),
        period: "AM",
        splitFraction: 0.6,
      },
      {
        runId: "test-run",
        penId: "2",
        penName: "Pen 2",
        ration: "Grower",
        headCount: 380,
        kgPerHead: 1.2,
        totalKg: 273.6,
        at: new Date().toISOString(),
        period: "AM",
        splitFraction: 0.6,
      },
      {
        runId: "test-run",
        penId: "3",
        penName: "Pen 3",
        ration: "Finisher",
        headCount: 420,
        kgPerHead: 1.4,
        totalKg: 352.8,
        at: new Date().toISOString(),
        period: "AM",
        splitFraction: 0.6,
      },
    ],
  };

  return <RunTotals run={run} />;
}
