import { HistoryTab } from "../HistoryTab";

export default function HistoryTabExample() {
  return <HistoryTab />;
}
