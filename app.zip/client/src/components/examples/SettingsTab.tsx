import { SettingsTab } from "../SettingsTab";

export default function SettingsTabExample() {
  return <SettingsTab onSetPens={() => console.log("Pens updated")} />;
}
