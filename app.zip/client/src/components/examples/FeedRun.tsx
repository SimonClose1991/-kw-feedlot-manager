import { FeedRun } from "../FeedRun";
import type { Pen } from "@shared/types";

export default function FeedRunExample() {
  const pens: Pen[] = [
    { id: "1", name: "Pen 1", ration: "Grower", headCount: 400, kgPerHead: 1.2, rationPercent: 100, active: true },
    { id: "2", name: "Pen 2", ration: "Grower", headCount: 380, kgPerHead: 1.2, rationPercent: 100, active: true },
    { id: "3", name: "Pen 3", ration: "Finisher", headCount: 420, kgPerHead: 1.4, rationPercent: 100, active: true },
    { id: "4", name: "Hospital", ration: "Hay/Chaff", headCount: 45, kgPerHead: 0.5, rationPercent: 100, active: true },
  ];

  const order = ["1", "2", "3", "4"];

  return <FeedRun pens={pens} order={order} />;
}
