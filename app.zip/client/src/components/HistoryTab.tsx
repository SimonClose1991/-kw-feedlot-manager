import { useState, useMemo } from "react";
import type { FeedRunSummary } from "@shared/types";
import { formatKg, formatDate, formatTime } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trash2, ChevronDown, ChevronUp } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { usePinProtection } from "@/hooks/usePinProtection";
import { useQuery, useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";

export function HistoryTab() {
  const { data: history = [], isLoading } = useQuery({
    queryKey: ["/api/history"],
    queryFn: api.history.getAll,
  });

  const deleteHistoryMutation = useMutation({
    mutationFn: api.history.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/history"] });
    },
  });

  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [filterType, setFilterType] = useState("");
  const { requestUnlock, PinDialog } = usePinProtection();

  async function deleteRun(id: string) {
    const unlocked = await requestUnlock();
    if (!unlocked) return;
    if (!confirm("Delete this feed run from history?")) return;
    deleteHistoryMutation.mutate(id);
  }

  function toggleExpanded(id: string) {
    const next = new Set(expandedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setExpandedIds(next);
  }

  const filtered = useMemo(() => {
    let result = history;

    if (startDate) {
      const start = new Date(startDate).getTime();
      result = result.filter(r => new Date(r.startedAt).getTime() >= start);
    }

    if (endDate) {
      const end = new Date(endDate).getTime();
      result = result.filter(r => new Date(r.startedAt).getTime() <= end);
    }

    if (filterType) {
      result = result.filter(r => 
        r.events.some(e => e.ration.toLowerCase().includes(filterType.toLowerCase()))
      );
    }

    return result;
  }, [history, startDate, endDate, filterType]);

  const totalRuns = filtered.length;
  const totalKg = filtered.reduce((sum, run) => 
    sum + run.events.reduce((s, e) => s + e.totalKg, 0), 0
  );

  return (
    <>
      <PinDialog />
      <Card className="p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
          <h2 className="text-xl font-semibold">Feed Run History</h2>
          <div className="text-sm text-muted-foreground">
            {totalRuns} runs · <span className="font-semibold font-mono">{formatKg(totalKg)}</span> total
          </div>
        </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
        <div>
          <Label htmlFor="start-date" className="text-xs">Start Date</Label>
          <Input
            id="start-date"
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="mt-1"
            data-testid="input-start-date"
          />
        </div>
        <div>
          <Label htmlFor="end-date" className="text-xs">End Date</Label>
          <Input
            id="end-date"
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="mt-1"
            data-testid="input-end-date"
          />
        </div>
        <div>
          <Label htmlFor="filter-type" className="text-xs">Filter by Type</Label>
          <Input
            id="filter-type"
            placeholder="e.g. Grower"
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="mt-1"
            data-testid="input-filter-type"
          />
        </div>
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          {history.length === 0 ? "No feed runs in history yet." : "No runs match your filters."}
        </div>
      )}

      <div className="space-y-3" data-testid="list-history">
        {filtered.map((run) => {
          const totalKg = run.events.reduce((s, e) => s + e.totalKg, 0);
          const byRation = run.events.reduce<Record<string, number>>((acc, e) => {
            acc[e.ration] = (acc[e.ration] ?? 0) + e.totalKg;
            return acc;
          }, {});
          const isExpanded = expandedIds.has(run.id);

          return (
            <Card key={run.id} className="p-4" data-testid={`card-run-${run.id}`}>
              <div className="flex items-start gap-3">
                <button
                  onClick={() => toggleExpanded(run.id)}
                  className="mt-1 text-muted-foreground hover:text-foreground"
                  data-testid={`button-toggle-${run.id}`}
                >
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </button>

                <div className="flex-1">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant={run.period === "AM" ? "default" : "secondary"}>
                          {run.period}
                        </Badge>
                        <span className="font-semibold">{run.events.length > 0 ? formatDate(run.events[0].at) : formatDate(run.startedAt)}</span>
                        <span className="text-sm text-muted-foreground">{run.events.length > 0 ? formatTime(run.events[0].at) : formatTime(run.startedAt)}</span>
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">
                        Feeder: {run.feeder || "—"} · {run.events.length} pens · {Math.round(run.splitFraction * 100)}% split
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-2xl font-bold font-mono">{formatKg(totalKg)}</div>
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="mt-4 border-t border-border pt-4">
                      <div className="flex flex-wrap gap-2 mb-4">
                        {Object.entries(byRation).map(([ration, kg]) => (
                          <Badge key={ration} variant="outline" className="font-mono">
                            {ration}: {formatKg(kg)}
                          </Badge>
                        ))}
                      </div>
                      <h4 className="font-semibold text-sm mb-2">Events ({run.events.length})</h4>
                      <div className="space-y-2">
                        {run.events.map((event, idx) => (
                          <div key={idx} className="text-sm grid grid-cols-2 sm:grid-cols-4 gap-2 bg-muted p-2 rounded-lg">
                            <div>
                              <span className="font-medium">{event.penName}</span>
                            </div>
                            <div className="text-muted-foreground">{event.ration}</div>
                            <div className="font-mono font-medium">{formatKg(event.totalKg)}</div>
                            <div className="text-xs text-muted-foreground">{formatTime(event.at)}</div>
                            {event.notes && (
                              <div className="col-span-2 sm:col-span-4 text-xs text-muted-foreground italic">
                                Note: {event.notes}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteRun(run.id)}
                  className="text-destructive hover:text-destructive"
                  data-testid={`button-delete-${run.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          );
        })}
      </div>
      </Card>
    </>
  );
}
