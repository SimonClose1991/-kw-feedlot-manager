import { useState, useEffect } from "react";
import type { Pen, MixIngredient } from "@shared/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, Upload, Trash2, Lock, AlertTriangle, Plus } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";

interface SettingsTabProps {
  isUnlocked: boolean;
}

export function SettingsTab({ isUnlocked }: SettingsTabProps) {
  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: api.settings.get,
  });

  const saveSettingsMutation = useMutation({
    mutationFn: api.settings.save,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
  });

  const [feeder, setFeeder] = useState("");
  const [splitAM, setSplitAM] = useState(60);
  const [splitPM, setSplitPM] = useState(40);
  // ingredientNames and ingredientKgs store raw strings so decimal typing (e.g. "0.0025") is never mangled
  const [ingredientNames, setIngredientNames] = useState<string[]>([]);
  const [ingredientKgs, setIngredientKgs] = useState<string[]>([]);
  const [bufferPercent, setBufferPercent] = useState(0);
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");

  useEffect(() => {
    if (settings) {
      setFeeder(settings.defaultFeeder || "");
      setSplitAM(Math.round((settings.splitAM ?? 0.6) * 100));
      setSplitPM(Math.round((settings.splitPM ?? 0.4) * 100));
      const ings = settings.ingredients ?? [];
      setIngredientNames(ings.map(i => i.name));
      setIngredientKgs(ings.map(i => i.kgPerHead === 0 ? "" : String(i.kgPerHead)));
      setBufferPercent(settings.bufferPercent ?? 0);
    }
  }, [settings]);

  function saveFeeder() {
    saveSettingsMutation.mutate({ defaultFeeder: feeder });
    alert("Default feeder name saved.");
  }

  function saveSplits() {
    saveSettingsMutation.mutate({ splitAM: splitAM / 100, splitPM: splitPM / 100 });
    alert("AM/PM split preferences saved.");
  }

  function saveBuffer() {
    saveSettingsMutation.mutate({ bufferPercent: bufferPercent });
    alert("Buffer percentage saved.");
  }

  function updateIngredientName(index: number, value: string) {
    setIngredientNames(prev => prev.map((n, i) => i === index ? value : n));
  }

  function updateIngredientKg(index: number, value: string) {
    setIngredientKgs(prev => prev.map((k, i) => i === index ? value : k));
  }

  function addIngredient() {
    setIngredientNames(prev => [...prev, ""]);
    setIngredientKgs(prev => [...prev, ""]);
  }

  function removeIngredient(index: number) {
    setIngredientNames(prev => prev.filter((_, i) => i !== index));
    setIngredientKgs(prev => prev.filter((_, i) => i !== index));
  }

  // Running total for display — treat blank as 0
  const draftTotal = ingredientKgs.reduce((sum, k) => sum + (Number(k) || 0), 0);

  async function saveMixIngredients() {
    const ingredients: MixIngredient[] = ingredientNames.map((name, i) => ({
      name: name.trim(),
      kgPerHead: Number(ingredientKgs[i]) || 0,
    }));

    const valid = ingredients.every(ing => ing.name !== "" && !isNaN(ing.kgPerHead) && ing.kgPerHead >= 0);
    if (!valid) {
      alert("Please ensure all ingredients have a name and a valid kg value.");
      return;
    }

    const newTotal = ingredients.reduce((sum, ing) => sum + ing.kgPerHead, 0);

    try {
      await saveSettingsMutation.mutateAsync({ ingredients });

      const pens = await api.pens.getAll();
      const updated = pens.map(p => ({ ...p, kgPerHead: newTotal }));
      await api.pens.save(updated, false);
      queryClient.invalidateQueries({ queryKey: ["/api/pens"] });

      alert(`Mix ingredients saved. All pens updated to ${newTotal.toFixed(4)} kg/head/day.`);
    } catch (e) {
      alert("Error saving mix ingredients. Please try again.");
    }
  }

  async function exportData() {
    try {
      const [pens, history] = await Promise.all([
        api.pens.getAll(),
        api.history.getAll(),
      ]);

      function escCsv(val: unknown): string {
        const s = val === null || val === undefined ? "" : String(val);
        return s.includes(",") || s.includes('"') || s.includes("\n")
          ? `"${s.replace(/"/g, '""')}"`
          : s;
      }

      const rows: string[] = [];

      // --- Pens section ---
      rows.push("PENS");
      rows.push(["Pen Name", "Head Count", "Ration Type", "kg/Head/Day", "Ration %", "Active", "Notes"].map(escCsv).join(","));
      for (const p of pens) {
        rows.push([
          p.name,
          p.headCount,
          p.ration,
          p.kgPerHead,
          p.rationPercent ?? 100,
          p.active ? "Yes" : "No",
          p.notes ?? "",
        ].map(escCsv).join(","));
      }

      rows.push("");

      // --- Feed History section ---
      rows.push("FEED HISTORY");
      rows.push(["Run Date", "Period", "Feeder", "Pen Name", "Head Count", "kg Fed", "Split %"].map(escCsv).join(","));
      for (const run of history) {
        const runDate = new Date(run.startedAt).toLocaleDateString("en-AU");
        for (const ev of run.events) {
          rows.push([
            runDate,
            run.period,
            run.feeder ?? "",
            ev.penName,
            ev.headCount,
            ev.totalKg,
            Math.round(run.splitFraction * 100),
          ].map(escCsv).join(","));
        }
      }

      const csv = rows.join("\n");
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const date = new Date().toISOString().slice(0, 10);
      a.download = `kurra-wirra-backup-${date}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      alert("Export failed. Please try again.");
    }
  }

  function importData() {
    alert("Import functionality coming soon!");
  }

  function clearAllData() {
    alert("Clear data functionality coming soon!");
  }

  function savePinCode() {
    if (newPin.length < 4) {
      alert("PIN must be at least 4 characters long.");
      return;
    }
    if (newPin !== confirmPin) {
      alert("PINs do not match. Please try again.");
      return;
    }
    saveSettingsMutation.mutate({ adminPin: newPin });
    setNewPin("");
    setConfirmPin("");
    alert("Admin PIN saved successfully! The Settings tab is now protected.");
  }

  function removePinCode() {
    if (!confirm("Remove PIN protection? Anyone will be able to access Settings.")) return;
    saveSettingsMutation.mutate({ adminPin: null });
    alert("PIN protection removed. Refresh the page for changes to take effect.");
  }

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-6">Settings</h2>

      <div className="space-y-6">
        <div>
          <h3 className="font-semibold mb-3">Default Feeder</h3>
          <div className="flex gap-2 max-w-md">
            <Input
              placeholder="Enter default name"
              value={feeder}
              onChange={(e) => setFeeder(e.target.value)}
              data-testid="input-default-feeder"
            />
            <Button onClick={saveFeeder} data-testid="button-save-feeder">Save</Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            This name will automatically fill in the feeder field for new feed runs.
          </p>
        </div>

        <div>
          <h3 className="font-semibold mb-3">Mix Ingredients (kg/head/day)</h3>
          <div className="space-y-2 max-w-xl">
            {ingredientNames.length > 0 && (
              <div className="grid grid-cols-[1fr_120px_40px] gap-2 px-1">
                <div className="text-xs text-muted-foreground font-medium">Ingredient Name</div>
                <div className="text-xs text-muted-foreground font-medium">kg / head / day</div>
                <div />
              </div>
            )}
            {ingredientNames.map((name, i) => (
              <div key={i} className="grid grid-cols-[1fr_120px_40px] gap-2 items-center">
                <Input
                  value={name}
                  onChange={(e) => updateIngredientName(i, e.target.value)}
                  placeholder="e.g. Silage"
                  data-testid={`input-ingredient-name-${i}`}
                />
                <Input
                  type="text"
                  inputMode="decimal"
                  value={ingredientKgs[i] ?? ""}
                  onChange={(e) => updateIngredientKg(i, e.target.value)}
                  placeholder="0"
                  className="font-mono"
                  data-testid={`input-ingredient-kg-${i}`}
                />
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => removeIngredient(i)}
                  className="text-destructive"
                  data-testid={`button-remove-ingredient-${i}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
            {ingredientNames.length === 0 && (
              <p className="text-sm text-muted-foreground py-2">No ingredients added yet. Click below to add one.</p>
            )}
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <Button onClick={addIngredient} variant="outline" data-testid="button-add-ingredient">
              <Plus className="w-4 h-4 mr-2" />
              Add Ingredient
            </Button>
            <Button onClick={saveMixIngredients} data-testid="button-save-ration">
              Save Mix
            </Button>
            {ingredientNames.length > 0 && (
              <div className="text-sm text-muted-foreground">
                Total: <span className="font-semibold font-mono">
                  {draftTotal.toFixed(4)} kg/head/day
                </span>
              </div>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Add, edit, or remove ingredients freely. Saving updates all existing pens to the new total kg/head/day.
          </p>
        </div>

        <div>
          <h3 className="font-semibold mb-3">AM/PM Split Preferences</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md">
            <div>
              <Label htmlFor="split-am" className="text-xs">AM Split (%)</Label>
              <Input
                id="split-am"
                type="number"
                min="0"
                max="100"
                value={splitAM}
                onChange={(e) => setSplitAM(Number(e.target.value))}
                className="mt-1 font-mono"
                data-testid="input-split-am"
              />
            </div>
            <div>
              <Label htmlFor="split-pm" className="text-xs">PM Split (%)</Label>
              <Input
                id="split-pm"
                type="number"
                min="0"
                max="100"
                value={splitPM}
                onChange={(e) => setSplitPM(Number(e.target.value))}
                className="mt-1 font-mono"
                data-testid="input-split-pm"
              />
            </div>
          </div>
          <div className="mt-3">
            <Button onClick={saveSplits} data-testid="button-save-splits">Save Preferences</Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            These percentages determine how the daily feed amount is split between AM and PM runs.
          </p>
        </div>

        <div>
          <h3 className="font-semibold mb-3">Ration Buffer Percentage</h3>
          <div className="max-w-xs">
            <Label htmlFor="buffer-percent" className="text-xs">Buffer (%)</Label>
            <Input
              id="buffer-percent"
              type="number"
              min="0"
              max="50"
              step="1"
              value={bufferPercent}
              onChange={(e) => setBufferPercent(Number(e.target.value))}
              className="mt-1 font-mono"
              data-testid="input-buffer-percent"
            />
          </div>
          <div className="mt-3">
            <Button onClick={saveBuffer} data-testid="button-save-buffer">Save Buffer</Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Extra percentage added to all ingredients in mixer load calculations to account for potential feed boosts during runs. Recommended: 10-15%.
          </p>
        </div>

        <div>
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <Lock className="w-5 h-5" />
            Admin PIN Protection
            {settings?.adminPin && <Badge variant="secondary">Active</Badge>}
          </h3>
          
          {!settings?.adminPin ? (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md">
                <div>
                  <Label htmlFor="new-pin" className="text-xs">New PIN</Label>
                  <Input
                    id="new-pin"
                    type="password"
                    inputMode="numeric"
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="Enter PIN (min 4 chars)"
                    className="mt-1 font-mono"
                    data-testid="input-new-pin"
                  />
                </div>
                <div>
                  <Label htmlFor="confirm-pin" className="text-xs">Confirm PIN</Label>
                  <Input
                    id="confirm-pin"
                    type="password"
                    inputMode="numeric"
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value)}
                    placeholder="Re-enter PIN"
                    className="mt-1 font-mono"
                    data-testid="input-confirm-pin"
                  />
                </div>
              </div>
              <div className="mt-3">
                <Button onClick={savePinCode} data-testid="button-save-pin">
                  <Lock className="w-4 h-4 mr-2" />
                  Set PIN Protection
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Set a PIN to protect Pens and Settings tabs from unauthorized access.
              </p>
            </>
          ) : (
            <>
              <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-orange-500 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">PIN Protection Active</p>
                  <p className="text-xs text-muted-foreground">
                    Pens and Settings tabs are protected. Staff will need to enter the PIN to access these sections.
                  </p>
                </div>
              </div>
              <div className="mt-3 flex gap-2">
                <div className="grid grid-cols-2 gap-3 flex-1 max-w-md">
                  <Input
                    type="password"
                    inputMode="numeric"
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="New PIN"
                    className="font-mono"
                    data-testid="input-change-pin"
                  />
                  <Input
                    type="password"
                    inputMode="numeric"
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value)}
                    placeholder="Confirm"
                    className="font-mono"
                    data-testid="input-confirm-change-pin"
                  />
                </div>
                <Button onClick={savePinCode} variant="outline" data-testid="button-change-pin">
                  Change PIN
                </Button>
                <Button onClick={removePinCode} variant="destructive" data-testid="button-remove-pin">
                  Remove PIN
                </Button>
              </div>
            </>
          )}
        </div>

        <div>
          <h3 className="font-semibold mb-3">Data Management</h3>
          <div className="flex flex-wrap gap-2">
            <Button onClick={exportData} variant="outline" data-testid="button-export">
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
            <Button onClick={importData} variant="outline" data-testid="button-import">
              <Upload className="w-4 h-4 mr-2" />
              Import Data
            </Button>
            <Button onClick={clearAllData} variant="destructive" data-testid="button-clear">
              <Trash2 className="w-4 h-4 mr-2" />
              Clear All Data
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Export your data as JSON for backup, or import previously saved data. Clear all data will reset the app to factory defaults.
          </p>
        </div>
      </div>
    </Card>
  );
}
