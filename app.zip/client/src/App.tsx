import { Switch, Route, useLocation } from "wouter";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Beef, Home, ClipboardList } from "lucide-react";
import { Button } from "@/components/ui/button";

// Sheep app (full tabbed UI, self-contained)
import SheepApp from "./SheepApp";

// Workflow weekly planner (embedded static page)
import Workflow from "@/pages/Workflow";

// Cattle app pages (Wouter-routed under /cattle)
import LoadSelector from "@/cattle/pages/LoadSelector";
import LoadDetails from "@/cattle/pages/LoadDetails";
import Management from "@/cattle/pages/Management";
import History from "@/cattle/pages/History";

import NotFound from "@/pages/not-found";
import logoUrl from "@assets/logo new_1761111532929.jpg";

// Simple sheep glyph (lucide has no sheep icon)
function SheepIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M9 9c-1.5 0-2.5-1-2.5-2.2C6.5 5.4 7.6 4.5 9 4.6c.3-1 1.3-1.7 2.4-1.7 1 0 1.9.5 2.3 1.4 1.4-.3 2.8.6 3 2 .2 1.2-.6 2.3-1.7 2.6" />
      <path d="M7 11.5a4.5 4.5 0 0 0 4.5 4.5h1A4.5 4.5 0 0 0 17 11.5" />
      <path d="M8 16v2.5M16 16v2.5M11 16.5V19M13 16.5V19" />
      <circle cx="9.5" cy="9.5" r="0.5" fill="currentColor" />
    </svg>
  );
}

function HomeSelector() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen w-full bg-background text-foreground flex flex-col">
      <header className="border-b border-border">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center gap-3">
          <img
            src={logoUrl}
            alt="Kurra-Wirra Logo"
            className="h-12 w-auto object-contain rounded-md"
            data-testid="logo"
          />
          <div>
            <h1 className="text-lg font-semibold leading-tight tracking-tight">
              Kurra-Wirra Feedlot Manager
            </h1>
            <p className="text-xs text-muted-foreground">Choose an app</p>
          </div>
        </div>
      </header>

      <main className="flex-1 w-full max-w-md mx-auto px-4 py-8 flex flex-col justify-center gap-5">
        <button
          onClick={() => setLocation("/cattle")}
          data-testid="button-cattle"
          className="group w-full rounded-2xl border border-border bg-card hover:bg-accent active:scale-[0.99] transition-all shadow-sm hover:shadow-md p-8 flex flex-col items-center gap-3"
        >
          <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors">
            <Beef className="h-10 w-10 text-primary" />
          </div>
          <span className="text-2xl font-semibold tracking-tight">Cattle</span>
          <span className="text-sm text-muted-foreground">
            Mixer wagon loads &amp; recipes
          </span>
        </button>

        <button
          onClick={() => setLocation("/sheep")}
          data-testid="button-sheep"
          className="group w-full rounded-2xl border border-border bg-card hover:bg-accent active:scale-[0.99] transition-all shadow-sm hover:shadow-md p-8 flex flex-col items-center gap-3"
        >
          <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors">
            <SheepIcon className="h-10 w-10 text-primary" />
          </div>
          <span className="text-2xl font-semibold tracking-tight">Sheep</span>
          <span className="text-sm text-muted-foreground">
            Pen feed runs &amp; grain rosters
          </span>
        </button>

        <button
          onClick={() => setLocation("/workflow")}
          data-testid="button-workflow"
          className="group w-full rounded-2xl border border-border bg-card hover:bg-accent active:scale-[0.99] transition-all shadow-sm hover:shadow-md p-8 flex flex-col items-center gap-3"
        >
          <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors">
            <ClipboardList className="h-10 w-10 text-primary" />
          </div>
          <span className="text-2xl font-semibold tracking-tight">Workflow</span>
          <span className="text-sm text-muted-foreground">
            Weekly staff &amp; task planner
          </span>
        </button>
      </main>

      <footer className="py-4 text-center text-xs text-muted-foreground">
        Kurra-Wirra Pastoral
      </footer>
    </div>
  );
}

// Slim bar shown above each sub-app to return to the selector.
function AppChrome({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  const [, setLocation] = useLocation();
  return (
    <div className="min-h-screen w-full bg-background">
      <div className="sticky top-0 z-[60] bg-background/90 backdrop-blur border-b border-border">
        <div className="max-w-5xl mx-auto px-3 py-2 flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            data-testid="button-home"
          >
            <Home className="w-4 h-4 mr-1" />
            Apps
          </Button>
          <span className="text-sm text-muted-foreground">/ {label}</span>
        </div>
      </div>
      {children}
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomeSelector} />

      {/* Cattle app */}
      <Route path="/cattle">
        <AppChrome label="Cattle">
          <LoadSelector />
        </AppChrome>
      </Route>
      <Route path="/cattle/load/:loadName">
        <AppChrome label="Cattle">
          <LoadDetails />
        </AppChrome>
      </Route>
      <Route path="/cattle/manage">
        <AppChrome label="Cattle">
          <Management />
        </AppChrome>
      </Route>
      <Route path="/cattle/history">
        <AppChrome label="Cattle">
          <History />
        </AppChrome>
      </Route>

      {/* Sheep app */}
      <Route path="/sheep">
        <AppChrome label="Sheep">
          <SheepApp />
        </AppChrome>
      </Route>

      {/* Workflow weekly planner */}
      <Route path="/workflow">
        <AppChrome label="Workflow">
          <Workflow />
        </AppChrome>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <TooltipProvider>
      <Router />
    </TooltipProvider>
  );
}
