import { useState, useEffect } from "react";
import type { Pen } from "@shared/types";
import { useQuery, useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";
import { FeedRun } from "@/components/FeedRun";
import { PensTab } from "@/components/PensTab";
import { HistoryTab } from "@/components/HistoryTab";
import { SettingsTab } from "@/components/SettingsTab";
import { RationTab } from "@/components/RationTab";
import { GrainFeeding } from "@/components/GrainFeeding";
import { PinPrompt } from "@/components/PinPrompt";
import { Button } from "@/components/ui/button";
import { Lock, LockOpen, RefreshCcw, Check, Cloud } from "lucide-react";
import logoImage from "@assets/logo new_1761111532929.jpg";

type Tab = "run" | "ration" | "pens" | "grain" | "history" | "settings";

function formatSyncTime(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  
  if (diffSec < 10) return "Just now";
  if (diffSec < 60) return `${diffSec}s ago`;
  if (diffMin === 1) return "1 min ago";
  if (diffMin < 60) return `${diffMin} mins ago`;
  
  const hours = date.getHours();
  const mins = date.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 || 12;
  return `${displayHours}:${mins.toString().padStart(2, '0')} ${ampm}`;
}

const DEFAULT_PENS: Pen[] = [
  { id: crypto.randomUUID(), name: "Pen 1", ration: "Grower", headCount: 400, kgPerHead: 1.2, rationPercent: 100, active: true },
  { id: crypto.randomUUID(), name: "Pen 2", ration: "Grower", headCount: 380, kgPerHead: 1.2, rationPercent: 100, active: true },
  { id: crypto.randomUUID(), name: "Pen 3", ration: "Finisher", headCount: 420, kgPerHead: 1.4, rationPercent: 100, active: true },
  { id: crypto.randomUUID(), name: "Pen 4", ration: "Starter", headCount: 350, kgPerHead: 0.8, rationPercent: 100, active: true },
  { id: crypto.randomUUID(), name: "Hospital", ration: "Hay/Chaff", headCount: 45, kgPerHead: 0.5, rationPercent: 100, active: true },
];

export default function SheepApp() {
  const [tab, setTab] = useState<Tab>("run");
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [showPinPrompt, setShowPinPrompt] = useState(false);
  const [pendingTab, setPendingTab] = useState<Tab | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);

  const { data: pens = DEFAULT_PENS, isLoading: pensLoading, refetch: refetchPens, isFetching: pensFetching } = useQuery({
    queryKey: ["/api/pens"],
    queryFn: api.pens.getAll,
  });

  const { data: settings, isLoading: settingsLoading, refetch: refetchSettings, isFetching: settingsFetching } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: api.settings.get,
  });

  const savePensMutation = useMutation({
    mutationFn: api.pens.save,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pens"] });
    },
  });

  const hasAdminPin = () => {
    return settings?.adminPin !== null && settings?.adminPin !== undefined && settings.adminPin.length > 0;
  };

  // Order is derived from pens array order (pens are already sorted by backend)
  const order = pens.map(p => p.id);

  const handleSetOrder = (newOrder: string[]) => {
    // Reorder pens array to match new order and save
    const reorderedPens = newOrder
      .map(id => pens.find(p => p.id === id))
      .filter((p): p is Pen => !!p);
    savePensMutation.mutate(reorderedPens);
  };

  const handleTabClick = (newTab: Tab) => {
    const protectedTabs: Tab[] = ["settings"];
    const needsAuth = protectedTabs.includes(newTab) && hasAdminPin() && !isUnlocked;
    
    if (needsAuth) {
      setPendingTab(newTab);
      setShowPinPrompt(true);
    } else {
      setTab(newTab);
    }
  };

  const handlePinSuccess = () => {
    setIsUnlocked(true);
    setShowPinPrompt(false);
    if (pendingTab) {
      setTab(pendingTab);
      setPendingTab(null);
    }
  };

  const handlePinCancel = () => {
    setShowPinPrompt(false);
    setPendingTab(null);
  };

  const handleLock = () => {
    setIsUnlocked(false);
    if (tab === "settings") {
      setTab("run");
    }
  };

  const handleRefresh = async () => {
    setIsSyncing(true);
    try {
      await Promise.all([
        refetchPens(),
        refetchSettings(),
        queryClient.refetchQueries({ queryKey: ["/api/history"] }),
        queryClient.refetchQueries({ queryKey: ["/api/current-run"] }),
      ]);
      setLastSyncTime(new Date());
    } finally {
      setTimeout(() => setIsSyncing(false), 500);
    }
  };

  // Auto-sync on mount
  useEffect(() => {
    setLastSyncTime(new Date());
  }, []);

  // Show syncing indicator when any query is fetching
  useEffect(() => {
    if (pensFetching || settingsFetching) {
      setIsSyncing(true);
    } else {
      setTimeout(() => setIsSyncing(false), 300);
    }
  }, [pensFetching, settingsFetching]);

  // Update the sync time display every 10 seconds to keep it current
  useEffect(() => {
    if (!lastSyncTime) return;
    const interval = setInterval(() => {
      setLastSyncTime(new Date(lastSyncTime));
    }, 10000);
    return () => clearInterval(interval);
  }, [lastSyncTime]);

  return (
    <div className="min-h-screen w-full bg-background text-foreground">
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <img 
              src={logoImage} 
              alt="Kurra-Wirra Logo" 
              className="h-12 w-auto object-contain rounded-md"
              data-testid="logo"
            />
            <div>
              <h1 className="text-lg font-semibold leading-tight tracking-tight">Kurra-Wirra Sheep Feed Manager</h1>
              <p className="text-xs text-muted-foreground">Simple feed run app</p>
            </div>
          </div>
          <nav className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <Button
                onClick={handleRefresh}
                variant={isSyncing ? "default" : "outline"}
                size="sm"
                disabled={isSyncing}
                data-testid="button-refresh"
                className={isSyncing ? "bg-chart-1 hover:bg-chart-1 border-chart-1" : ""}
              >
                {isSyncing ? (
                  <>
                    <RefreshCcw className="w-3 h-3 mr-1 animate-spin" />
                    Syncing...
                  </>
                ) : (
                  <>
                    <Cloud className="w-3 h-3 mr-1" />
                    Sync Now
                  </>
                )}
              </Button>
              {!isSyncing && lastSyncTime && (
                <div className="text-xs text-muted-foreground whitespace-nowrap flex items-center gap-1" data-testid="text-last-sync">
                  <Check className="w-3 h-3 text-chart-1" />
                  {formatSyncTime(lastSyncTime)}
                </div>
              )}
            </div>
            {([
              { id: "run", label: "Feed Run" },
              { id: "ration", label: "Ration" },
              { id: "pens", label: "Pens" },
              { id: "grain", label: "Grain" },
              { id: "history", label: "History" },
              { id: "settings", label: "Settings" },
            ] as const).map(x => {
              const isProtected = x.id === "settings" && hasAdminPin();
              return (
                <Button
                  key={x.id}
                  onClick={() => handleTabClick(x.id)}
                  variant={tab === x.id ? "default" : "outline"}
                  size="sm"
                  data-testid={`tab-${x.id}`}
                >
                  {isProtected && <Lock className="w-3 h-3 mr-1" />}
                  {x.label}
                </Button>
              );
            })}
            {hasAdminPin() && isUnlocked && (
              <Button
                onClick={handleLock}
                variant="ghost"
                size="sm"
                data-testid="button-lock"
              >
                <LockOpen className="w-4 h-4" />
              </Button>
            )}
          </nav>
        </div>
      </header>

      <main className="max-w-5xl mx-auto p-4 pb-24">
        {pensLoading || settingsLoading ? (
          <div className="text-center py-12">Loading...</div>
        ) : (
          <>
            {tab === "run" && <FeedRun pens={pens} order={order} />}
            {tab === "ration" && <RationTab pens={pens} />}
            {tab === "pens" && (
              <PensTab pens={pens} order={order} setOrder={handleSetOrder} />
            )}
            {tab === "grain" && <GrainFeeding />}
            {tab === "history" && <HistoryTab />}
            {tab === "settings" && <SettingsTab isUnlocked={isUnlocked} />}
          </>
        )}
      </main>

      {showPinPrompt && <PinPrompt onSuccess={handlePinSuccess} onCancel={handlePinCancel} />}
    </div>
  );
}
