import { useState, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { loadAdminPin } from '@/lib/storage';

const UNLOCKED_KEY = 'kw_pin_unlocked';

export function usePinProtection() {
  const [showDialog, setShowDialog] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [resolvePromise, setResolvePromise] = useState<((value: boolean) => void) | null>(null);
  const { toast } = useToast();

  const isUnlocked = useCallback(() => {
    return sessionStorage.getItem(UNLOCKED_KEY) === 'true';
  }, []);

  const unlock = useCallback(() => {
    sessionStorage.setItem(UNLOCKED_KEY, 'true');
  }, []);

  const requestUnlock = useCallback((): Promise<boolean> => {
    // Check if already unlocked
    if (isUnlocked()) {
      return Promise.resolve(true);
    }

    // Check if PIN is even set
    const pin = loadAdminPin();
    if (!pin) {
      // No PIN set, allow action
      return Promise.resolve(true);
    }

    // Show PIN dialog and return a promise
    return new Promise<boolean>((resolve) => {
      setResolvePromise(() => resolve);
      setShowDialog(true);
      setPinInput('');
    });
  }, [isUnlocked]);

  const handleSubmit = useCallback(() => {
    const pin = loadAdminPin();
    
    if (pinInput === pin) {
      unlock();
      setShowDialog(false);
      toast({
        title: "Unlocked",
        description: "You can now edit and delete items",
      });
      if (resolvePromise) {
        resolvePromise(true);
        setResolvePromise(null);
      }
    } else {
      toast({
        title: "Incorrect PIN",
        description: "Please try again",
        variant: "destructive",
      });
      setPinInput('');
    }
  }, [pinInput, unlock, toast, resolvePromise]);

  const handleCancel = useCallback(() => {
    setShowDialog(false);
    setPinInput('');
    if (resolvePromise) {
      resolvePromise(false);
      setResolvePromise(null);
    }
  }, [resolvePromise]);

  const PinDialog = useCallback(() => (
    <Dialog open={showDialog} onOpenChange={(open) => !open && handleCancel()}>
      <DialogContent data-testid="dialog-pin-protection">
        <DialogHeader>
          <DialogTitle>Enter PIN</DialogTitle>
          <DialogDescription>
            Please enter your PIN to edit or delete items
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={(e) => { e.preventDefault(); handleSubmit(); }} className="space-y-4">
          <Input
            type="password"
            inputMode="numeric"
            pattern="[0-9]*"
            placeholder="Enter PIN"
            value={pinInput}
            onChange={(e) => setPinInput(e.target.value)}
            autoFocus
            data-testid="input-pin"
          />
          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={handleCancel} className="flex-1" data-testid="button-cancel">
              Cancel
            </Button>
            <Button type="submit" className="flex-1" data-testid="button-submit">
              Unlock
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  ), [showDialog, pinInput, handleSubmit, handleCancel]);

  return {
    isUnlocked: isUnlocked(),
    requestUnlock,
    PinDialog,
  };
}
