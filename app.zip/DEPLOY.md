# Deploying the Kurra-Wirra Feedlot Manager

This is one app containing both the **Cattle** and **Sheep** feedlot tools, with a
home screen that lets you pick between them.

It's a Node server (Express) that also serves the web app, plus a PostgreSQL
database. The recommended host is **Render** because one service runs the whole
thing and the database is free in the same place.

---

## Option 1 — Render (recommended, free)

### A. Put the code on GitHub
1. Create a free account at github.com (if you don't have one).
2. Make a new repository, e.g. `kw-feedlot-manager`.
3. Upload this whole project folder to it (drag-and-drop works on github.com via
   "Add file" → "Upload files", or use GitHub Desktop).

### B. Deploy on Render
1. Sign up at render.com with your GitHub account.
2. Click **New +** → **Blueprint**.
3. Pick your `kw-feedlot-manager` repo. Render finds the included `render.yaml`
   and sets up a web service **and** a free Postgres database automatically.
4. Click **Apply**. First build takes a few minutes.

### C. Create the database tables (one time)
The database starts empty. After the first deploy:
1. In Render, open your web service → **Shell** tab.
2. Run: `npm run db:push`
   This creates all tables for both apps.
3. (Optional) Refresh the app — the cattle side seeds example loads/mobs on first run.

You'll get a URL like `https://kw-feedlot-manager.onrender.com`. Open it on any
phone or computer.

> **Free-tier note:** the app sleeps after ~15 minutes of no use and takes about
> 30 seconds to wake on the next visit. For feedlot use (a few people during
> feeding) that's usually fine. To remove the sleep, upgrade the web service to
> the $7/month Starter plan later — no code changes needed.

---

## Option 2 — Try it with NO database first (quickest look)

The app runs without any database using temporary in-memory storage (data resets
when the server restarts). Handy for a first look before committing to a DB.

- **Locally:** `npm install` then `npm run dev`, open http://localhost:5000
- **On Render:** deploy the web service only (skip the database), and don't set
  `DATABASE_URL`. It boots straight into in-memory mode.

When you're ready for data that persists, add the database and set `DATABASE_URL`
(the blueprint in Option 1 does this for you), then run `npm run db:push`.

---

## Option 3 — Railway (also good, very simple)

1. Push to GitHub as above.
2. At railway.app: **New Project** → **Deploy from GitHub repo**.
3. Add a **PostgreSQL** plugin (Railway sets `DATABASE_URL` for you).
4. In the service settings, confirm: Build = `npm run build`, Start = `npm run start`.
5. Run `npm run db:push` once (Railway has a shell, or run it locally against the
   same `DATABASE_URL`).

Railway's free allowance is a small monthly credit rather than truly unlimited,
but it's the smoothest experience after Render.

---

## Running it on your own computer

```
npm install
npm run dev        # in-memory mode, http://localhost:5000
```

With a database:
```
# set DATABASE_URL to a Postgres connection string (e.g. a free Neon database)
npm run db:push    # create tables
npm run dev
```

---

## What costs money, and what doesn't

| Piece | Free option | When you'd pay |
|---|---|---|
| Hosting the app | Render free / Railway credit | ~$7/mo to stop it sleeping |
| Database | Render free Postgres / Neon free tier | only at large data volumes |
| Domain (e.g. feedlot.kurrawirra.com.au) | use the free `.onrender.com` URL | ~$15/yr if you want a custom domain |

For a single farm business, you can realistically run this for **$0**, or ~$7/mo
if you want it always instant.
