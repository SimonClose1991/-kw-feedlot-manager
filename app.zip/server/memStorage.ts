import * as schema from "@shared/schema";
import type { Pen as SharedPen, FeedRunSummary, MixIngredient } from "@shared/types";
import type { IStorage, GrainRosterData } from "./storage";
import { randomUUID } from "crypto";

// In-memory implementation of the sheep IStorage.
// Used for local preview / demo when DATABASE_URL is not set.
// Data resets when the server restarts.

const DEFAULT_PENS: SharedPen[] = [
  { id: randomUUID(), name: "Pen 1", ration: "Grower", headCount: 400, kgPerHead: 1.2, rationPercent: 100, active: true },
  { id: randomUUID(), name: "Pen 2", ration: "Grower", headCount: 380, kgPerHead: 1.2, rationPercent: 100, active: true },
  { id: randomUUID(), name: "Pen 3", ration: "Finisher", headCount: 420, kgPerHead: 1.4, rationPercent: 100, active: true },
  { id: randomUUID(), name: "Pen 4", ration: "Starter", headCount: 350, kgPerHead: 0.8, rationPercent: 100, active: true },
  { id: randomUUID(), name: "Hospital", ration: "Hay/Chaff", headCount: 45, kgPerHead: 0.5, rationPercent: 100, active: true },
];

interface SettingsShape {
  adminPin: string | null;
  defaultFeeder: string | null;
  splitAM: number;
  splitPM: number;
  silage: number;
  protein: number;
  energy: number;
  water: number;
  straw: number;
  ingredients: MixIngredient[];
  bufferPercent: number;
}

export class MemStorage implements IStorage {
  private pens: SharedPen[] = DEFAULT_PENS.map(p => ({ ...p }));
  private history: FeedRunSummary[] = [];
  private currentRun: FeedRunSummary | null = null;
  private settings: SettingsShape = {
    adminPin: null,
    defaultFeeder: null,
    splitAM: 0.6,
    splitPM: 0.4,
    silage: 0,
    protein: 0,
    energy: 0,
    water: 0,
    straw: 0,
    ingredients: [],
    bufferPercent: 0,
  };
  private grainRosters: GrainRosterData[] = [];
  private grainFeedRuns: schema.GrainFeedRun[] = [];

  async getPens(): Promise<SharedPen[]> {
    return this.pens.map(p => ({ ...p, rationPercent: p.rationPercent ?? 100 }));
  }

  async savePens(pens: SharedPen[], forceDelete: boolean = false): Promise<void> {
    const newIds = new Set(pens.map(p => p.id));
    const pensToDelete = this.pens.filter(p => !newIds.has(p.id));
    if (pensToDelete.length > 2 && !forceDelete) {
      throw new Error(`SAFETY_CHECK: Would delete ${pensToDelete.length} pens (${pensToDelete.map(p => p.name).join(', ')}). Use forceDelete=true to confirm.`);
    }
    // Order is implied by array order
    this.pens = pens.map(p => ({ ...p, rationPercent: p.rationPercent ?? 100 }));
  }

  async getHistory(): Promise<FeedRunSummary[]> {
    return [...this.history].sort((a, b) =>
      new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()
    );
  }

  async saveHistory(run: FeedRunSummary): Promise<void> {
    this.history.push({ ...run });
  }

  async deleteHistory(id: string): Promise<void> {
    this.history = this.history.filter(h => h.id !== id);
  }

  async getCurrentRun(): Promise<FeedRunSummary | null> {
    return this.currentRun ? { ...this.currentRun } : null;
  }

  async saveCurrentRun(run: FeedRunSummary | null): Promise<void> {
    this.currentRun = run ? { ...run } : null;
  }

  async getSettings() {
    return { ...this.settings, ingredients: [...this.settings.ingredients] };
  }

  async saveSettings(settings: Partial<SettingsShape>): Promise<void> {
    this.settings = {
      ...this.settings,
      ...Object.fromEntries(
        Object.entries(settings).filter(([, v]) => v !== undefined)
      ),
    } as SettingsShape;
  }

  async getGrainRosters(): Promise<GrainRosterData[]> {
    return this.grainRosters.map(r => ({ ...r, rows: [...r.rows] }));
  }

  async getGrainRoster(farm: string): Promise<GrainRosterData | null> {
    const r = this.grainRosters.find(r => r.farm === farm);
    return r ? { ...r, rows: [...r.rows] } : null;
  }

  async saveGrainRoster(roster: Omit<GrainRosterData, 'id'>): Promise<GrainRosterData> {
    const existing = this.grainRosters.find(r => r.farm === roster.farm);
    if (existing) {
      existing.feedRateKgPerSec = roster.feedRateKgPerSec;
      existing.rows = roster.rows;
      return { ...existing, rows: [...existing.rows] };
    }
    const created: GrainRosterData = { id: randomUUID(), ...roster };
    this.grainRosters.push(created);
    return { ...created, rows: [...created.rows] };
  }

  async getGrainFeedRuns(farm?: string): Promise<schema.GrainFeedRun[]> {
    let runs = [...this.grainFeedRuns];
    if (farm) runs = runs.filter(r => r.farm === farm);
    return runs.sort((a, b) =>
      new Date(b.finishedAt as any).getTime() - new Date(a.finishedAt as any).getTime()
    );
  }

  async saveGrainFeedRun(run: schema.InsertGrainFeedRun): Promise<schema.GrainFeedRun> {
    const created = {
      id: randomUUID(),
      ...run,
      startedAt: (run as any).startedAt,
      finishedAt: (run as any).finishedAt,
    } as schema.GrainFeedRun;
    this.grainFeedRuns.push(created);
    return created;
  }

  async deleteGrainFeedRun(id: string): Promise<void> {
    this.grainFeedRuns = this.grainFeedRuns.filter(r => r.id !== id);
  }

  private workflowData: any = null;
  async getWorkflow(): Promise<any | null> {
    return this.workflowData;
  }
  async saveWorkflow(data: any): Promise<void> {
    this.workflowData = data;
  }
}
