import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { registerCattleRoutes } from "./cattleRoutes";

export async function registerRoutes(app: Express): Promise<Server> {
  // ===== Cattle Feedlot API routes =====
  registerCattleRoutes(app);

  // ===== Sheep Feedlot API routes =====
  // Pens API
  app.get("/api/pens", async (_req, res) => {
    try {
      const pens = await storage.getPens();
      res.json(pens);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/pens", async (req, res) => {
    try {
      const { pens, forceDelete } = req.body;
      // Support both old format (array) and new format (object with pens and forceDelete)
      const pensArray = Array.isArray(req.body) ? req.body : pens;
      const force = Array.isArray(req.body) ? false : !!forceDelete;
      
      await storage.savePens(pensArray, force);
      res.json({ success: true });
    } catch (error: any) {
      // Return 409 Conflict for safety check errors
      if (error.message.startsWith('SAFETY_CHECK:')) {
        res.status(409).json({ error: error.message, requiresConfirmation: true });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  });

  // History API
  app.get("/api/history", async (_req, res) => {
    try {
      const history = await storage.getHistory();
      res.json(history);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/history", async (req, res) => {
    try {
      await storage.saveHistory(req.body);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/history/:id", async (req, res) => {
    try {
      await storage.deleteHistory(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Current Run API
  app.get("/api/current-run", async (_req, res) => {
    try {
      const currentRun = await storage.getCurrentRun();
      res.json(currentRun);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/current-run", async (req, res) => {
    try {
      await storage.saveCurrentRun(req.body);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Settings API
  app.get("/api/settings", async (_req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/settings", async (req, res) => {
    try {
      await storage.saveSettings(req.body);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Grain Rosters API
  app.get("/api/grain-rosters", async (_req, res) => {
    try {
      const rosters = await storage.getGrainRosters();
      res.json(rosters);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/grain-rosters/:farm", async (req, res) => {
    try {
      const roster = await storage.getGrainRoster(req.params.farm);
      res.json(roster);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/grain-rosters", async (req, res) => {
    try {
      const saved = await storage.saveGrainRoster(req.body);
      res.json(saved);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Grain Feed Runs API
  app.get("/api/grain-feed-runs", async (req, res) => {
    try {
      const farm = req.query.farm as string | undefined;
      const runs = await storage.getGrainFeedRuns(farm);
      res.json(runs);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/grain-feed-runs", async (req, res) => {
    try {
      const saved = await storage.saveGrainFeedRun(req.body);
      res.json(saved);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/grain-feed-runs/:id", async (req, res) => {
    try {
      await storage.deleteGrainFeedRun(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
