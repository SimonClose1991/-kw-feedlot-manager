import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as cattleSchema from "@shared/cattleSchema";

neonConfig.webSocketConstructor = ws;

// Lazily initialized so importing this module does not throw when DATABASE_URL
// is absent (in-memory preview mode).
let _db: ReturnType<typeof drizzle> | null = null;

function getDb() {
  if (_db) return _db;
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL must be set to use the database. (Running in in-memory mode.)");
  }
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  _db = drizzle(pool, { schema: cattleSchema });
  return _db;
}

export const db: ReturnType<typeof drizzle> = new Proxy({} as any, {
  get(_target, prop) {
    const real = getDb() as any;
    const value = real[prop];
    return typeof value === "function" ? value.bind(real) : value;
  },
});
