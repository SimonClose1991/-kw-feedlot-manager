import type { Express } from "express";
import { storage } from "./cattleStorage";
import { 
  insertElementSchema, 
  insertAnimalClassSchema, 
  insertRecipeSchema,
  insertMobSchema,
  insertLoadSchema,
  insertLoadAssignmentSchema,
  insertCattleFeedHistorySchema
} from "@shared/cattleSchema";
import { fromZodError } from "zod-validation-error";

export function registerCattleRoutes(app: Express): void {
  // Elements
  app.get("/api/elements", async (req, res) => {
    const elements = await storage.getElements();
    res.json(elements);
  });

  app.post("/api/elements", async (req, res) => {
    try {
      const data = insertElementSchema.parse(req.body);
      const existing = await storage.getElementByName(data.name);
      if (existing) {
        return res.status(400).json({ message: "Element with this name already exists" });
      }
      const element = await storage.createElement(data);
      res.status(201).json(element);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      console.error("Create element failed:", error);
      res.status(500).json({ message: error?.message || "Failed to create element" });
    }
  });

  app.patch("/api/elements/:id", async (req, res) => {
    try {
      const updated = await storage.updateElement(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Element not found" });
      }
      res.json(updated);
    } catch (error: any) {
      console.error("Update element failed:", error);
      res.status(500).json({ message: error?.message || "Failed to update element" });
    }
  });

  app.delete("/api/elements/:id", async (req, res) => {
    const success = await storage.deleteElement(req.params.id);
    if (!success) {
      return res.status(404).json({ message: "Element not found" });
    }
    res.status(204).send();
  });

  // Animal Classes
  app.get("/api/classes", async (req, res) => {
    const classes = await storage.getAnimalClasses();
    res.json(classes);
  });

  app.post("/api/classes", async (req, res) => {
    try {
      const data = insertAnimalClassSchema.parse(req.body);
      const animalClass = await storage.createAnimalClass(data);
      res.status(201).json(animalClass);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create class" });
    }
  });

  app.delete("/api/classes/:id", async (req, res) => {
    const animalClass = await storage.getAnimalClass(req.params.id);
    if (!animalClass) {
      return res.status(404).json({ message: "Class not found" });
    }
    await storage.deleteRecipesByClass(animalClass.name);
    await storage.deleteAnimalClass(req.params.id);
    res.status(204).send();
  });

  // Recipes
  app.get("/api/recipes", async (req, res) => {
    const recipes = await storage.getRecipes();
    res.json(recipes);
  });

  app.post("/api/recipes", async (req, res) => {
    try {
      const data = insertRecipeSchema.parse(req.body);
      const recipe = await storage.createRecipe(data);
      res.status(201).json(recipe);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create recipe" });
    }
  });

  app.patch("/api/recipes/:id", async (req, res) => {
    try {
      const updated = await storage.updateRecipe(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to update recipe" });
    }
  });

  app.delete("/api/recipes/:id", async (req, res) => {
    const success = await storage.deleteRecipe(req.params.id);
    if (!success) {
      return res.status(404).json({ message: "Recipe not found" });
    }
    res.status(204).send();
  });

  // Mobs
  app.get("/api/mobs", async (req, res) => {
    const mobs = await storage.getMobs();
    res.json(mobs);
  });

  app.post("/api/mobs", async (req, res) => {
    try {
      const data = insertMobSchema.parse(req.body);
      const existing = await storage.getMobByName(data.name);
      if (existing) {
        return res.status(400).json({ message: "Mob with this name already exists" });
      }
      const mob = await storage.createMob(data);
      res.status(201).json(mob);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create mob" });
    }
  });

  app.patch("/api/mobs/:id", async (req, res) => {
    try {
      const existingMob = await storage.getMobs().then(all => all.find(m => m.id === req.params.id));
      if (!existingMob) {
        return res.status(404).json({ message: "Mob not found" });
      }
      const oldName = existingMob.name;
      const updated = await storage.updateMob(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Mob not found" });
      }
      if (req.body.name && req.body.name !== oldName) {
        await storage.updateLoadAssignmentsMobName(oldName, req.body.name);
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to update mob" });
    }
  });

  app.delete("/api/mobs/:id", async (req, res) => {
    const success = await storage.deleteMob(req.params.id);
    if (!success) {
      return res.status(404).json({ message: "Mob not found" });
    }
    res.status(204).send();
  });

  // Loads
  app.get("/api/loads", async (req, res) => {
    const loads = await storage.getLoads();
    res.json(loads);
  });

  app.post("/api/loads", async (req, res) => {
    try {
      const data = insertLoadSchema.parse(req.body);
      const existing = await storage.getLoadByName(data.name);
      if (existing) {
        return res.status(400).json({ message: "Load with this name already exists" });
      }
      const load = await storage.createLoad(data);
      res.status(201).json(load);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create load" });
    }
  });

  app.patch("/api/loads/:id", async (req, res) => {
    try {
      const load = await storage.getLoad(req.params.id);
      if (!load) return res.status(404).json({ message: "Load not found" });
      const { name } = req.body;
      if (!name || typeof name !== "string" || !name.trim()) {
        return res.status(400).json({ message: "Name is required" });
      }
      const newName = name.trim();
      if (newName !== load.name) {
        const existing = await storage.getLoadByName(newName);
        if (existing) return res.status(400).json({ message: "Load with this name already exists" });
        await storage.updateLoadAssignmentsLoadName(load.name, newName);
      }
      const updated = await storage.updateLoad(req.params.id, { name: newName });
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to update load" });
    }
  });

  app.delete("/api/loads/:id", async (req, res) => {
    const load = await storage.getLoad(req.params.id);
    if (!load) {
      return res.status(404).json({ message: "Load not found" });
    }
    await storage.deleteLoadAssignmentsByLoad(load.name);
    await storage.deleteLoad(req.params.id);
    res.status(204).send();
  });

  // Load Assignments
  app.get("/api/load-assignments", async (req, res) => {
    const assignments = await storage.getLoadAssignments();
    res.json(assignments);
  });

  app.post("/api/load-assignments", async (req, res) => {
    try {
      const data = insertLoadAssignmentSchema.parse(req.body);
      const assignment = await storage.createLoadAssignment(data);
      res.status(201).json(assignment);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create assignment" });
    }
  });

  app.patch("/api/load-assignments/:id", async (req, res) => {
    try {
      const updated = await storage.updateLoadAssignment(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to update assignment" });
    }
  });

  app.delete("/api/load-assignments/:id", async (req, res) => {
    const success = await storage.deleteLoadAssignment(req.params.id);
    if (!success) {
      return res.status(404).json({ message: "Assignment not found" });
    }
    res.status(204).send();
  });

  // Feed History
  app.get("/api/feed-history", async (req, res) => {
    const history = await storage.getFeedHistory();
    res.json(history);
  });

  app.post("/api/feed-history", async (req, res) => {
    try {
      const data = insertCattleFeedHistorySchema.parse(req.body);
      const history = await storage.createFeedHistory(data);
      res.status(201).json(history);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create feed history" });
    }
  });
}
