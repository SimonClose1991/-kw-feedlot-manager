import { db } from "./db";
import * as schema from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import type { Pen as SharedPen, FeedRunSummary, MixIngredient } from "@shared/types";

export interface GrainRosterData {
  id: string;
  farm: string;
  feedRateKgPerSec: number;
  rows: any[];
}

export interface IStorage {
  // Pens
  getPens(): Promise<SharedPen[]>;
  savePens(pens: SharedPen[], forceDelete?: boolean): Promise<void>;
  
  // History
  getHistory(): Promise<FeedRunSummary[]>;
  saveHistory(run: FeedRunSummary): Promise<void>;
  deleteHistory(id: string): Promise<void>;
  
  // Current Run
  getCurrentRun(): Promise<FeedRunSummary | null>;
  saveCurrentRun(run: FeedRunSummary | null): Promise<void>;
  
  // Settings
  getSettings(): Promise<{
    adminPin: string | null;
    defaultFeeder: string | null;
    splitAM: number;
    splitPM: number;
    silage: number;
    protein: number;
    energy: number;
    water: number;
    straw: number;
    ingredients: MixIngredient[];
    bufferPercent: number;
  }>;
  saveSettings(settings: {
    adminPin?: string | null;
    defaultFeeder?: string | null;
    splitAM?: number;
    splitPM?: number;
    silage?: number;
    protein?: number;
    energy?: number;
    water?: number;
    straw?: number;
    ingredients?: MixIngredient[];
    bufferPercent?: number;
  }): Promise<void>;
  
  // Grain Rosters
  getGrainRosters(): Promise<GrainRosterData[]>;
  getGrainRoster(farm: string): Promise<GrainRosterData | null>;
  saveGrainRoster(roster: Omit<GrainRosterData, 'id'>): Promise<GrainRosterData>;
  
  // Grain Feed Runs
  getGrainFeedRuns(farm?: string): Promise<schema.GrainFeedRun[]>;
  saveGrainFeedRun(run: schema.InsertGrainFeedRun): Promise<schema.GrainFeedRun>;
  deleteGrainFeedRun(id: string): Promise<void>;
}

export class DbStorage implements IStorage {
  async getPens(): Promise<SharedPen[]> {
    const pens = await db.select().from(schema.pens).orderBy(schema.pens.orderIndex);
    return pens.map(p => ({
      id: p.id,
      name: p.name,
      ration: p.ration,
      headCount: p.headCount,
      kgPerHead: p.kgPerHead,
      rationPercent: p.rationPercent ?? 100,
      active: p.active,
      notes: p.notes ?? undefined,
    }));
  }

  async savePens(pens: SharedPen[], forceDelete: boolean = false): Promise<void> {
    // Get existing pens to compare
    const existingPens = await db.select().from(schema.pens);
    const existingIds = new Set(existingPens.map(p => p.id));
    const newIds = new Set(pens.map(p => p.id));
    
    // Find pens that would be deleted
    const pensToDelete = existingPens.filter(p => !newIds.has(p.id));
    
    // Safety check: refuse to delete more than 2 pens unless forceDelete is true
    if (pensToDelete.length > 2 && !forceDelete) {
      throw new Error(`SAFETY_CHECK: Would delete ${pensToDelete.length} pens (${pensToDelete.map(p => p.name).join(', ')}). Use forceDelete=true to confirm.`);
    }
    
    // Delete only the pens that are explicitly removed
    for (const pen of pensToDelete) {
      await db.delete(schema.pens).where(eq(schema.pens.id, pen.id));
    }
    
    // Upsert remaining pens
    for (let i = 0; i < pens.length; i++) {
      const pen = pens[i];
      
      if (existingIds.has(pen.id)) {
        // Update existing pen
        await db.update(schema.pens)
          .set({
            name: pen.name,
            ration: pen.ration,
            headCount: pen.headCount,
            kgPerHead: pen.kgPerHead,
            rationPercent: pen.rationPercent ?? 100,
            active: pen.active,
            orderIndex: i,
            notes: pen.notes ?? null,
          })
          .where(eq(schema.pens.id, pen.id));
      } else {
        // Insert new pen
        await db.insert(schema.pens).values({
          id: pen.id,
          name: pen.name,
          ration: pen.ration,
          headCount: pen.headCount,
          kgPerHead: pen.kgPerHead,
          rationPercent: pen.rationPercent ?? 100,
          active: pen.active,
          orderIndex: i,
          notes: pen.notes ?? null,
        });
      }
    }
  }

  async getHistory(): Promise<FeedRunSummary[]> {
    const history = await db.select().from(schema.feedHistory).orderBy(desc(schema.feedHistory.startedAt));
    return history.map(h => ({
      id: h.id,
      startedAt: h.startedAt.toISOString(),
      finishedAt: h.finishedAt?.toISOString(),
      feeder: h.feeder ?? undefined,
      period: h.period as 'AM' | 'PM',
      splitFraction: h.splitFraction,
      events: h.events as any,
    }));
  }

  async saveHistory(run: FeedRunSummary): Promise<void> {
    await db.insert(schema.feedHistory).values({
      id: run.id,
      startedAt: new Date(run.startedAt),
      finishedAt: run.finishedAt ? new Date(run.finishedAt) : null,
      feeder: run.feeder ?? null,
      period: run.period,
      splitFraction: run.splitFraction,
      events: run.events as any,
    });
  }

  async deleteHistory(id: string): Promise<void> {
    await db.delete(schema.feedHistory).where(eq(schema.feedHistory.id, id));
  }

  async getCurrentRun(): Promise<FeedRunSummary | null> {
    const result = await db.select().from(schema.currentRun).limit(1);
    if (!result.length) return null;
    
    const run = result[0];
    return {
      id: run.id,
      startedAt: run.startedAt.toISOString(),
      feeder: run.feeder ?? undefined,
      period: run.period as 'AM' | 'PM',
      splitFraction: run.splitFraction,
      events: run.events as any,
    };
  }

  async saveCurrentRun(run: FeedRunSummary | null): Promise<void> {
    await db.delete(schema.currentRun);
    
    if (run) {
      await db.insert(schema.currentRun).values({
        id: run.id,
        startedAt: new Date(run.startedAt),
        feeder: run.feeder ?? null,
        period: run.period,
        splitFraction: run.splitFraction,
        events: run.events as any,
      });
    }
  }

  async getSettings() {
    const result = await db.select().from(schema.settings).where(eq(schema.settings.id, 'singleton')).limit(1);
    
    if (!result.length) {
      return {
        adminPin: null,
        defaultFeeder: null,
        splitAM: 0.6,
        splitPM: 0.4,
        silage: 0,
        protein: 0,
        energy: 0,
        water: 0,
        straw: 0,
        ingredients: [],
        bufferPercent: 0,
      };
    }
    
    const settings = result[0];

    // Build ingredients array — use stored JSONB if present, otherwise migrate from old columns
    let ingredients: MixIngredient[] = [];
    if (settings.ingredients && Array.isArray(settings.ingredients) && (settings.ingredients as any[]).length > 0) {
      ingredients = settings.ingredients as MixIngredient[];
    } else {
      // Auto-migrate from legacy individual columns
      const legacyMap: Array<[string, number | null]> = [
        ["Silage", settings.silage],
        ["Protein", settings.protein],
        ["Energy", settings.energy],
        ["Water", settings.water],
        ["Straw", settings.straw],
      ];
      ingredients = legacyMap
        .filter(([, kg]) => (kg ?? 0) > 0)
        .map(([name, kg]) => ({ name, kgPerHead: kg as number }));
    }

    return {
      adminPin: settings.adminPin,
      defaultFeeder: settings.defaultFeeder,
      splitAM: settings.splitAM ?? 0.6,
      splitPM: settings.splitPM ?? 0.4,
      silage: settings.silage ?? 0,
      protein: settings.protein ?? 0,
      energy: settings.energy ?? 0,
      water: settings.water ?? 0,
      straw: settings.straw ?? 0,
      ingredients,
      bufferPercent: settings.bufferPercent ?? 0,
    };
  }

  async saveSettings(settings: {
    adminPin?: string | null;
    defaultFeeder?: string | null;
    splitAM?: number;
    splitPM?: number;
    silage?: number;
    protein?: number;
    energy?: number;
    water?: number;
    bufferPercent?: number;
  }): Promise<void> {
    const existing = await db.select().from(schema.settings).where(eq(schema.settings.id, 'singleton')).limit(1);
    
    if (existing.length) {
      // Merge with existing settings to avoid nullifying unspecified fields
      const merged = {
        adminPin: settings.adminPin !== undefined ? settings.adminPin : existing[0].adminPin,
        defaultFeeder: settings.defaultFeeder !== undefined ? settings.defaultFeeder : existing[0].defaultFeeder,
        splitAM: settings.splitAM !== undefined ? settings.splitAM : existing[0].splitAM,
        splitPM: settings.splitPM !== undefined ? settings.splitPM : existing[0].splitPM,
        silage: settings.silage !== undefined ? settings.silage : existing[0].silage,
        protein: settings.protein !== undefined ? settings.protein : existing[0].protein,
        energy: settings.energy !== undefined ? settings.energy : existing[0].energy,
        water: settings.water !== undefined ? settings.water : existing[0].water,
        straw: settings.straw !== undefined ? settings.straw : existing[0].straw,
        ingredients: settings.ingredients !== undefined ? settings.ingredients as any : existing[0].ingredients,
        bufferPercent: settings.bufferPercent !== undefined ? settings.bufferPercent : existing[0].bufferPercent,
      };
      await db.update(schema.settings)
        .set(merged)
        .where(eq(schema.settings.id, 'singleton'));
    } else {
      await db.insert(schema.settings).values({
        id: 'singleton',
        adminPin: settings.adminPin ?? null,
        defaultFeeder: settings.defaultFeeder ?? null,
        splitAM: settings.splitAM ?? 0.6,
        splitPM: settings.splitPM ?? 0.4,
        silage: settings.silage ?? 0,
        protein: settings.protein ?? 0,
        energy: settings.energy ?? 0,
        water: settings.water ?? 0,
        straw: settings.straw ?? 0,
        ingredients: (settings.ingredients ?? []) as any,
        bufferPercent: settings.bufferPercent ?? 0,
      });
    }
  }
  
  async getGrainRosters(): Promise<GrainRosterData[]> {
    const rosters = await db.select().from(schema.grainRosters);
    return rosters.map(r => ({
      id: r.id,
      farm: r.farm,
      feedRateKgPerSec: r.feedRateKgPerSec,
      rows: r.rows as any[],
    }));
  }
  
  async getGrainRoster(farm: string): Promise<GrainRosterData | null> {
    const result = await db.select().from(schema.grainRosters).where(eq(schema.grainRosters.farm, farm)).limit(1);
    if (!result.length) return null;
    
    const r = result[0];
    return {
      id: r.id,
      farm: r.farm,
      feedRateKgPerSec: r.feedRateKgPerSec,
      rows: r.rows as any[],
    };
  }
  
  async saveGrainRoster(roster: Omit<GrainRosterData, 'id'>): Promise<GrainRosterData> {
    // Check if roster for this farm already exists
    const existing = await db.select().from(schema.grainRosters).where(eq(schema.grainRosters.farm, roster.farm)).limit(1);
    
    if (existing.length) {
      // Update existing roster
      await db.update(schema.grainRosters)
        .set({
          feedRateKgPerSec: roster.feedRateKgPerSec,
          rows: roster.rows as any,
        })
        .where(eq(schema.grainRosters.farm, roster.farm));
      
      return {
        id: existing[0].id,
        farm: roster.farm,
        feedRateKgPerSec: roster.feedRateKgPerSec,
        rows: roster.rows,
      };
    } else {
      // Create new roster
      const result = await db.insert(schema.grainRosters).values({
        farm: roster.farm,
        feedRateKgPerSec: roster.feedRateKgPerSec,
        rows: roster.rows as any,
      }).returning();
      
      return {
        id: result[0].id,
        farm: result[0].farm,
        feedRateKgPerSec: result[0].feedRateKgPerSec,
        rows: result[0].rows as any[],
      };
    }
  }
  
  async getGrainFeedRuns(farm?: string): Promise<schema.GrainFeedRun[]> {
    if (farm) {
      return await db.select()
        .from(schema.grainFeedRuns)
        .where(eq(schema.grainFeedRuns.farm, farm))
        .orderBy(desc(schema.grainFeedRuns.finishedAt));
    }
    return await db.select()
      .from(schema.grainFeedRuns)
      .orderBy(desc(schema.grainFeedRuns.finishedAt));
  }
  
  async saveGrainFeedRun(run: schema.InsertGrainFeedRun): Promise<schema.GrainFeedRun> {
    const result = await db.insert(schema.grainFeedRuns).values(run).returning();
    return result[0];
  }
  
  async deleteGrainFeedRun(id: string): Promise<void> {
    await db.delete(schema.grainFeedRuns).where(eq(schema.grainFeedRuns.id, id));
  }
}

import { MemStorage } from "./memStorage";

export const storage: IStorage = process.env.DATABASE_URL
  ? new DbStorage()
  : new MemStorage();

if (!process.env.DATABASE_URL) {
  console.log("[storage] No DATABASE_URL set — using in-memory storage (sheep). Data resets on restart.");
}
