import { 
  type Element, type InsertElement,
  type AnimalClass, type InsertAnimalClass,
  type Recipe, type InsertRecipe,
  type Mob, type InsertMob,
  type Load, type InsertLoad,
  type LoadAssignment, type InsertLoadAssignment,
  type FeedHistory, type InsertFeedHistory,
  elements, animalClasses, recipes, mobs, loads, loadAssignments, cattleFeedHistory
} from "@shared/cattleSchema";
import { db } from "./cattleDb";
import { eq, and, desc } from "drizzle-orm";
import type { IStorage } from "./cattleStorage";

export class DatabaseStorage implements IStorage {
  private initialized = false;

  async init() {
    if (this.initialized) return;
    await this.seedDataIfEmpty();
    this.initialized = true;
  }

  private async seedDataIfEmpty() {
    // Check if database is already seeded
    const existingElements = await db.select().from(elements).limit(1);
    if (existingElements.length > 0) {
      return; // Already seeded
    }

    // Seed elements
    const seedElements: InsertElement[] = [
      { name: "Silage", unit: "kg/head", defaultRate: 1 },
      { name: "Energy", unit: "kg/head", defaultRate: 0.9 },
      { name: "Protein", unit: "kg/head", defaultRate: 0.35 },
      { name: "Almond hulls", unit: "kg/head", defaultRate: 0 },
      { name: "Straw", unit: "kg/head", defaultRate: 0 },
      { name: "Water", unit: "L/head", defaultRate: 5 },
    ];

    await db.insert(elements).values(seedElements);

    // Seed animal classes
    const seedClassNames = [
      "Spring U Bulls",
      "Autumn V Bulls",
      "Stud Bulls",
      "Autumn Heifers",
      "Commercial Cows"
    ];

    await db.insert(animalClasses).values(
      seedClassNames.map(name => ({ name }))
    );

    // Seed recipes
    const recipeData: InsertRecipe[] = [];
    for (const className of seedClassNames) {
      for (const element of seedElements) {
        recipeData.push({
          className,
          elementName: element.name,
          rate: element.defaultRate ?? 0
        });
      }
    }
    await db.insert(recipes).values(recipeData);

    // Seed mobs
    const seedMobs: InsertMob[] = [
      { name: "Spring U Bulls @ Simon's Haystack", className: "Spring U Bulls", paddock: "Simon's Haystack", headCount: 50, feedMultiplier: 1.0 },
      { name: "Autumn V Bulls @ Little Phalaris", className: "Autumn V Bulls", paddock: "Little Phalaris", headCount: 46, feedMultiplier: 1.0 },
      { name: "Stud Bulls @ Windmill", className: "Stud Bulls", paddock: "Windmill", headCount: 25, feedMultiplier: 1.0 },
      { name: "Autumn Heifers @ Dina's Triangle", className: "Autumn Heifers", paddock: "Dina's Triangle", headCount: 29, feedMultiplier: 1.0 },
      { name: "Commercial Cows @ FoM", className: "Commercial Cows", paddock: "FoM", headCount: 94, feedMultiplier: 1.0 },
    ];
    await db.insert(mobs).values(seedMobs);

    // Seed loads
    const seedLoadNames = ["Load 1", "Load 2", "Load 3", "Load 4", "Load 5"];
    await db.insert(loads).values(
      seedLoadNames.map(name => ({ name }))
    );

    // Seed load assignments
    const seedLoadAssignments: InsertLoadAssignment[] = [
      { loadName: "Load 2", mobName: "Spring U Bulls @ Simon's Haystack", feedMultiplier: 1.5, feedOrder: 0 },
      { loadName: "Load 2", mobName: "Autumn V Bulls @ Little Phalaris", feedMultiplier: 1.15, feedOrder: 1 },
      { loadName: "Load 2", mobName: "Stud Bulls @ Windmill", feedMultiplier: 1.5, feedOrder: 2 },
      { loadName: "Load 2", mobName: "Autumn Heifers @ Dina's Triangle", feedMultiplier: 1.2, feedOrder: 3 },
      { loadName: "Load 2", mobName: "Commercial Cows @ FoM", feedMultiplier: 2.0, feedOrder: 4 },
      { loadName: "Load 5", mobName: "Spring U Bulls @ Simon's Haystack", feedMultiplier: 1.0, feedOrder: 0 },
    ];
    await db.insert(loadAssignments).values(seedLoadAssignments);
  }

  // Elements
  async getElements(): Promise<Element[]> {
    return await db.select().from(elements);
  }

  async getElement(id: string): Promise<Element | undefined> {
    const [element] = await db.select().from(elements).where(eq(elements.id, id));
    return element || undefined;
  }

  async getElementByName(name: string): Promise<Element | undefined> {
    const [element] = await db.select().from(elements).where(eq(elements.name, name));
    return element || undefined;
  }

  async createElement(element: InsertElement): Promise<Element> {
    const [newElement] = await db.insert(elements).values(element).returning();
    return newElement;
  }

  async updateElement(id: string, element: Partial<InsertElement>): Promise<Element | undefined> {
    const [updated] = await db
      .update(elements)
      .set(element)
      .where(eq(elements.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteElement(id: string): Promise<boolean> {
    const result = await db.delete(elements).where(eq(elements.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Animal Classes
  async getAnimalClasses(): Promise<AnimalClass[]> {
    return await db.select().from(animalClasses);
  }

  async getAnimalClass(id: string): Promise<AnimalClass | undefined> {
    const [animalClass] = await db.select().from(animalClasses).where(eq(animalClasses.id, id));
    return animalClass || undefined;
  }

  async createAnimalClass(animalClass: InsertAnimalClass): Promise<AnimalClass> {
    const [newClass] = await db.insert(animalClasses).values(animalClass).returning();
    return newClass;
  }

  async deleteAnimalClass(id: string): Promise<boolean> {
    const result = await db.delete(animalClasses).where(eq(animalClasses.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Recipes
  async getRecipes(): Promise<Recipe[]> {
    return await db.select().from(recipes);
  }

  async getRecipesByClass(className: string): Promise<Recipe[]> {
    return await db.select().from(recipes).where(eq(recipes.className, className));
  }

  async createRecipe(recipe: InsertRecipe): Promise<Recipe> {
    const [newRecipe] = await db.insert(recipes).values(recipe).returning();
    return newRecipe;
  }

  async updateRecipe(id: string, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined> {
    const [updated] = await db
      .update(recipes)
      .set(recipe)
      .where(eq(recipes.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteRecipe(id: string): Promise<boolean> {
    const result = await db.delete(recipes).where(eq(recipes.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async deleteRecipesByClass(className: string): Promise<void> {
    await db.delete(recipes).where(eq(recipes.className, className));
  }

  // Mobs
  async getMobs(): Promise<Mob[]> {
    return await db.select().from(mobs);
  }

  async getMob(id: string): Promise<Mob | undefined> {
    const [mob] = await db.select().from(mobs).where(eq(mobs.id, id));
    return mob || undefined;
  }

  async getMobByName(name: string): Promise<Mob | undefined> {
    const [mob] = await db.select().from(mobs).where(eq(mobs.name, name));
    return mob || undefined;
  }

  async createMob(mob: InsertMob): Promise<Mob> {
    const mobData = {
      ...mob,
      feedMultiplier: mob.feedMultiplier ?? 1.0
    };
    const [newMob] = await db.insert(mobs).values(mobData).returning();
    return newMob;
  }

  async updateMob(id: string, mob: Partial<InsertMob>): Promise<Mob | undefined> {
    const [updated] = await db
      .update(mobs)
      .set(mob)
      .where(eq(mobs.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteMob(id: string): Promise<boolean> {
    const result = await db.delete(mobs).where(eq(mobs.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Loads
  async getLoads(): Promise<Load[]> {
    return await db.select().from(loads);
  }

  async getLoad(id: string): Promise<Load | undefined> {
    const [load] = await db.select().from(loads).where(eq(loads.id, id));
    return load || undefined;
  }

  async getLoadByName(name: string): Promise<Load | undefined> {
    const [load] = await db.select().from(loads).where(eq(loads.name, name));
    return load || undefined;
  }

  async createLoad(load: InsertLoad): Promise<Load> {
    const [newLoad] = await db.insert(loads).values(load).returning();
    return newLoad;
  }

  async updateLoad(id: string, data: { name: string }): Promise<Load | undefined> {
    const [updated] = await db.update(loads).set({ name: data.name }).where(eq(loads.id, id)).returning();
    return updated || undefined;
  }

  async deleteLoad(id: string): Promise<boolean> {
    const result = await db.delete(loads).where(eq(loads.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Load Assignments
  async getLoadAssignments(): Promise<LoadAssignment[]> {
    return await db.select().from(loadAssignments);
  }

  async getLoadAssignmentsByLoad(loadName: string): Promise<LoadAssignment[]> {
    return await db.select().from(loadAssignments).where(eq(loadAssignments.loadName, loadName));
  }

  async createLoadAssignment(assignment: InsertLoadAssignment): Promise<LoadAssignment> {
    const [newAssignment] = await db.insert(loadAssignments).values(assignment).returning();
    return newAssignment;
  }

  async updateLoadAssignment(id: string, assignment: Partial<InsertLoadAssignment>): Promise<LoadAssignment | undefined> {
    const [updated] = await db
      .update(loadAssignments)
      .set(assignment)
      .where(eq(loadAssignments.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteLoadAssignment(id: string): Promise<boolean> {
    const result = await db.delete(loadAssignments).where(eq(loadAssignments.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async deleteLoadAssignmentsByLoad(loadName: string): Promise<void> {
    await db.delete(loadAssignments).where(eq(loadAssignments.loadName, loadName));
  }

  async updateLoadAssignmentsMobName(oldName: string, newName: string): Promise<void> {
    await db
      .update(loadAssignments)
      .set({ mobName: newName })
      .where(eq(loadAssignments.mobName, oldName));
  }

  async updateLoadAssignmentsLoadName(oldName: string, newName: string): Promise<void> {
    await db
      .update(loadAssignments)
      .set({ loadName: newName })
      .where(eq(loadAssignments.loadName, oldName));
  }

  // Feed History
  async getFeedHistory(): Promise<FeedHistory[]> {
    const history = await db.select().from(cattleFeedHistory).orderBy(desc(cattleFeedHistory.timestamp));
    // Parse JSON ingredients
    return history.map(record => ({
      ...record,
      ingredients: typeof record.ingredients === 'string' 
        ? JSON.parse(record.ingredients) 
        : record.ingredients
    }));
  }

  async createFeedHistory(history: InsertFeedHistory): Promise<FeedHistory> {
    const historyData: any = {
      ...history,
      ingredients: JSON.stringify(history.ingredients)
    };
    const [newHistory] = await db.insert(cattleFeedHistory).values(historyData).returning();
    return {
      ...newHistory,
      ingredients: typeof newHistory.ingredients === 'string'
        ? JSON.parse(newHistory.ingredients)
        : newHistory.ingredients
    };
  }
}
