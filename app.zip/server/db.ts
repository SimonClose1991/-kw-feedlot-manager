import pkg from 'pg';
const { Pool } = pkg;
import { drizzle } from 'drizzle-orm/node-postgres';
import * as schema from '@shared/schema';

// Uses the standard PostgreSQL driver (pg) — a plain TCP connection that works
// on Render, Railway, Fly, Neon, and most Postgres hosts. Lazily initialized so
// importing this module does not throw when DATABASE_URL is absent (in-memory mode).
let _db: ReturnType<typeof drizzle> | null = null;

function getDb() {
  if (_db) return _db;
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL must be set to use the database. (Running in in-memory mode.)");
  }
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_URL.includes("localhost") ? false : { rejectUnauthorized: false },
  });
  _db = drizzle(pool, { schema });
  return _db;
}

export const db: ReturnType<typeof drizzle> = new Proxy({} as any, {
  get(_target, prop) {
    const real = getDb() as any;
    const value = real[prop];
    return typeof value === "function" ? value.bind(real) : value;
  },
});
