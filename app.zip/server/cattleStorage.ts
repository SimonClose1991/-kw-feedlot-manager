import { 
  type Element, type InsertElement,
  type AnimalClass, type InsertAnimalClass,
  type Recipe, type InsertRecipe,
  type Mob, type InsertMob,
  type Load, type InsertLoad,
  type LoadAssignment, type InsertLoadAssignment,
  type FeedHistory, type InsertFeedHistory
} from "@shared/cattleSchema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Elements
  getElements(): Promise<Element[]>;
  getElement(id: string): Promise<Element | undefined>;
  getElementByName(name: string): Promise<Element | undefined>;
  createElement(element: InsertElement): Promise<Element>;
  updateElement(id: string, element: Partial<InsertElement>): Promise<Element | undefined>;
  deleteElement(id: string): Promise<boolean>;

  // Animal Classes
  getAnimalClasses(): Promise<AnimalClass[]>;
  getAnimalClass(id: string): Promise<AnimalClass | undefined>;
  createAnimalClass(animalClass: InsertAnimalClass): Promise<AnimalClass>;
  deleteAnimalClass(id: string): Promise<boolean>;

  // Recipes
  getRecipes(): Promise<Recipe[]>;
  getRecipesByClass(className: string): Promise<Recipe[]>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  updateRecipe(id: string, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined>;
  deleteRecipe(id: string): Promise<boolean>;
  deleteRecipesByClass(className: string): Promise<void>;

  // Mobs
  getMobs(): Promise<Mob[]>;
  getMob(id: string): Promise<Mob | undefined>;
  getMobByName(name: string): Promise<Mob | undefined>;
  createMob(mob: InsertMob): Promise<Mob>;
  updateMob(id: string, mob: Partial<InsertMob>): Promise<Mob | undefined>;
  deleteMob(id: string): Promise<boolean>;

  // Loads
  getLoads(): Promise<Load[]>;
  getLoad(id: string): Promise<Load | undefined>;
  getLoadByName(name: string): Promise<Load | undefined>;
  createLoad(load: InsertLoad): Promise<Load>;
  updateLoad(id: string, data: { name: string }): Promise<Load | undefined>;
  deleteLoad(id: string): Promise<boolean>;

  // Load Assignments
  getLoadAssignments(): Promise<LoadAssignment[]>;
  getLoadAssignmentsByLoad(loadName: string): Promise<LoadAssignment[]>;
  createLoadAssignment(assignment: InsertLoadAssignment): Promise<LoadAssignment>;
  updateLoadAssignment(id: string, assignment: Partial<InsertLoadAssignment>): Promise<LoadAssignment | undefined>;
  deleteLoadAssignment(id: string): Promise<boolean>;
  deleteLoadAssignmentsByLoad(loadName: string): Promise<void>;
  updateLoadAssignmentsMobName(oldName: string, newName: string): Promise<void>;
  updateLoadAssignmentsLoadName(oldName: string, newName: string): Promise<void>;

  // Feed History
  getFeedHistory(): Promise<FeedHistory[]>;
  createFeedHistory(history: InsertFeedHistory): Promise<FeedHistory>;
}

export class MemStorage implements IStorage {
  private elements: Map<string, Element>;
  private animalClasses: Map<string, AnimalClass>;
  private recipes: Map<string, Recipe>;
  private mobs: Map<string, Mob>;
  private loads: Map<string, Load>;
  private loadAssignments: Map<string, LoadAssignment>;
  private feedHistory: Map<string, FeedHistory>;

  constructor() {
    this.elements = new Map();
    this.animalClasses = new Map();
    this.recipes = new Map();
    this.mobs = new Map();
    this.loads = new Map();
    this.loadAssignments = new Map();
    this.feedHistory = new Map();
    
    this.seedData();
  }

  private seedData() {
    const seedElements: InsertElement[] = [
      { name: "Silage", unit: "kg/head", defaultRate: 1 },
      { name: "Energy", unit: "kg/head", defaultRate: 0.9 },
      { name: "Protein", unit: "kg/head", defaultRate: 0.35 },
      { name: "Almond hulls", unit: "kg/head", defaultRate: 0 },
      { name: "Straw", unit: "kg/head", defaultRate: 0 },
      { name: "Water", unit: "L/head", defaultRate: 5 },
    ];

    const seedClasses = [
      "Spring U Bulls",
      "Autumn V Bulls",
      "Stud Bulls",
      "Autumn Heifers",
      "Commercial Cows"
    ];

    const seedMobs: InsertMob[] = [
      { name: "Spring U Bulls @ Simon's Haystack", className: "Spring U Bulls", paddock: "Simon's Haystack", headCount: 50, feedMultiplier: 1.0 },
      { name: "Autumn V Bulls @ Little Phalaris", className: "Autumn V Bulls", paddock: "Little Phalaris", headCount: 46, feedMultiplier: 1.0 },
      { name: "Stud Bulls @ Windmill", className: "Stud Bulls", paddock: "Windmill", headCount: 25, feedMultiplier: 1.0 },
      { name: "Autumn Heifers @ Dina's Triangle", className: "Autumn Heifers", paddock: "Dina's Triangle", headCount: 29, feedMultiplier: 1.0 },
      { name: "Commercial Cows @ FoM", className: "Commercial Cows", paddock: "FoM", headCount: 94, feedMultiplier: 1.0 },
    ];

    const seedLoads = ["Load 1", "Load 2", "Load 3", "Load 4", "Load 5"];

    const seedLoadAssignments: InsertLoadAssignment[] = [
      { loadName: "Load 2", mobName: "Spring U Bulls @ Simon's Haystack", feedMultiplier: 1.5, feedOrder: 0 },
      { loadName: "Load 2", mobName: "Autumn V Bulls @ Little Phalaris", feedMultiplier: 1.15, feedOrder: 1 },
      { loadName: "Load 2", mobName: "Stud Bulls @ Windmill", feedMultiplier: 1.5, feedOrder: 2 },
      { loadName: "Load 2", mobName: "Autumn Heifers @ Dina's Triangle", feedMultiplier: 1.2, feedOrder: 3 },
      { loadName: "Load 2", mobName: "Commercial Cows @ FoM", feedMultiplier: 2.0, feedOrder: 4 },
      { loadName: "Load 5", mobName: "Spring U Bulls @ Simon's Haystack", feedMultiplier: 1.0, feedOrder: 0 },
    ];

    seedElements.forEach(el => {
      const id = randomUUID();
      this.elements.set(id, { id, name: el.name, unit: el.unit, defaultRate: el.defaultRate ?? 0 });
    });

    seedClasses.forEach(name => {
      const id = randomUUID();
      this.animalClasses.set(id, { id, name });
      
      seedElements.forEach(el => {
        const recipeId = randomUUID();
        this.recipes.set(recipeId, {
          id: recipeId,
          className: name,
          elementName: el.name,
          rate: el.defaultRate ?? 0
        });
      });
    });

    seedMobs.forEach(mob => {
      const id = randomUUID();
      this.mobs.set(id, { 
        ...mob, 
        id,
        feedMultiplier: mob.feedMultiplier ?? 1.0
      });
    });

    seedLoads.forEach(name => {
      const id = randomUUID();
      this.loads.set(id, { id, name });
    });

    seedLoadAssignments.forEach(assignment => {
      const id = randomUUID();
      this.loadAssignments.set(id, { 
        id, 
        loadName: assignment.loadName, 
        mobName: assignment.mobName, 
        feedMultiplier: assignment.feedMultiplier ?? 1.0,
        feedOrder: assignment.feedOrder ?? 0
      });
    });
  }

  // Elements
  async getElements(): Promise<Element[]> {
    return Array.from(this.elements.values());
  }

  async getElement(id: string): Promise<Element | undefined> {
    return this.elements.get(id);
  }

  async getElementByName(name: string): Promise<Element | undefined> {
    return Array.from(this.elements.values()).find(el => el.name === name);
  }

  async createElement(element: InsertElement): Promise<Element> {
    const id = randomUUID();
    const newElement: Element = { 
      id, 
      name: element.name, 
      unit: element.unit, 
      defaultRate: element.defaultRate ?? 0,
      isGradual: element.isGradual ?? false,
      costPerUnit: element.costPerUnit ?? 0,
      costUnit: element.costUnit ?? "$/tonne",
    };
    this.elements.set(id, newElement);
    return newElement;
  }

  async updateElement(id: string, element: Partial<InsertElement>): Promise<Element | undefined> {
    const existing = this.elements.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...element };
    this.elements.set(id, updated);
    return updated;
  }

  async deleteElement(id: string): Promise<boolean> {
    return this.elements.delete(id);
  }

  // Animal Classes
  async getAnimalClasses(): Promise<AnimalClass[]> {
    return Array.from(this.animalClasses.values());
  }

  async getAnimalClass(id: string): Promise<AnimalClass | undefined> {
    return this.animalClasses.get(id);
  }

  async createAnimalClass(animalClass: InsertAnimalClass): Promise<AnimalClass> {
    const id = randomUUID();
    const newClass: AnimalClass = { ...animalClass, id };
    this.animalClasses.set(id, newClass);
    return newClass;
  }

  async deleteAnimalClass(id: string): Promise<boolean> {
    return this.animalClasses.delete(id);
  }

  // Recipes
  async getRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipes.values());
  }

  async getRecipesByClass(className: string): Promise<Recipe[]> {
    return Array.from(this.recipes.values()).filter(r => r.className === className);
  }

  async createRecipe(recipe: InsertRecipe): Promise<Recipe> {
    const id = randomUUID();
    const newRecipe: Recipe = { ...recipe, id };
    this.recipes.set(id, newRecipe);
    return newRecipe;
  }

  async updateRecipe(id: string, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined> {
    const existing = this.recipes.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...recipe };
    this.recipes.set(id, updated);
    return updated;
  }

  async deleteRecipe(id: string): Promise<boolean> {
    return this.recipes.delete(id);
  }

  async deleteRecipesByClass(className: string): Promise<void> {
    const toDelete = Array.from(this.recipes.entries())
      .filter(([_, recipe]) => recipe.className === className)
      .map(([id]) => id);
    toDelete.forEach(id => this.recipes.delete(id));
  }

  // Mobs
  async getMobs(): Promise<Mob[]> {
    return Array.from(this.mobs.values());
  }

  async getMob(id: string): Promise<Mob | undefined> {
    return this.mobs.get(id);
  }

  async getMobByName(name: string): Promise<Mob | undefined> {
    return Array.from(this.mobs.values()).find(m => m.name === name);
  }

  async createMob(mob: InsertMob): Promise<Mob> {
    const id = randomUUID();
    const newMob: Mob = { 
      ...mob, 
      id,
      feedMultiplier: mob.feedMultiplier ?? 1.0
    };
    this.mobs.set(id, newMob);
    return newMob;
  }

  async updateMob(id: string, mob: Partial<InsertMob>): Promise<Mob | undefined> {
    const existing = this.mobs.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...mob };
    this.mobs.set(id, updated);
    return updated;
  }

  async deleteMob(id: string): Promise<boolean> {
    return this.mobs.delete(id);
  }

  // Loads
  async getLoads(): Promise<Load[]> {
    return Array.from(this.loads.values());
  }

  async getLoad(id: string): Promise<Load | undefined> {
    return this.loads.get(id);
  }

  async getLoadByName(name: string): Promise<Load | undefined> {
    return Array.from(this.loads.values()).find(l => l.name === name);
  }

  async createLoad(load: InsertLoad): Promise<Load> {
    const id = randomUUID();
    const newLoad: Load = { ...load, id };
    this.loads.set(id, newLoad);
    return newLoad;
  }

  async updateLoad(id: string, data: { name: string }): Promise<Load | undefined> {
    const load = this.loads.get(id);
    if (!load) return undefined;
    const updated = { ...load, name: data.name };
    this.loads.set(id, updated);
    return updated;
  }

  async deleteLoad(id: string): Promise<boolean> {
    return this.loads.delete(id);
  }

  // Load Assignments
  async getLoadAssignments(): Promise<LoadAssignment[]> {
    return Array.from(this.loadAssignments.values());
  }

  async getLoadAssignmentsByLoad(loadName: string): Promise<LoadAssignment[]> {
    return Array.from(this.loadAssignments.values()).filter(a => a.loadName === loadName);
  }

  async createLoadAssignment(assignment: InsertLoadAssignment): Promise<LoadAssignment> {
    const id = randomUUID();
    const newAssignment: LoadAssignment = { 
      id, 
      loadName: assignment.loadName, 
      mobName: assignment.mobName, 
      feedMultiplier: assignment.feedMultiplier ?? 1.0,
      feedOrder: assignment.feedOrder ?? 0
    };
    this.loadAssignments.set(id, newAssignment);
    return newAssignment;
  }

  async updateLoadAssignment(id: string, assignment: Partial<InsertLoadAssignment>): Promise<LoadAssignment | undefined> {
    const existing = this.loadAssignments.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...assignment };
    this.loadAssignments.set(id, updated);
    return updated;
  }

  async deleteLoadAssignment(id: string): Promise<boolean> {
    return this.loadAssignments.delete(id);
  }

  async deleteLoadAssignmentsByLoad(loadName: string): Promise<void> {
    const toDelete = Array.from(this.loadAssignments.entries())
      .filter(([_, assignment]) => assignment.loadName === loadName)
      .map(([id]) => id);
    toDelete.forEach(id => this.loadAssignments.delete(id));
  }

  async updateLoadAssignmentsMobName(oldName: string, newName: string): Promise<void> {
    for (const [id, assignment] of this.loadAssignments.entries()) {
      if (assignment.mobName === oldName) {
        this.loadAssignments.set(id, { ...assignment, mobName: newName });
      }
    }
  }

  async updateLoadAssignmentsLoadName(oldName: string, newName: string): Promise<void> {
    for (const [id, assignment] of this.loadAssignments.entries()) {
      if (assignment.loadName === oldName) {
        this.loadAssignments.set(id, { ...assignment, loadName: newName });
      }
    }
  }

  // Feed History
  async getFeedHistory(): Promise<FeedHistory[]> {
    return Array.from(this.feedHistory.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createFeedHistory(history: InsertFeedHistory): Promise<FeedHistory> {
    const id = randomUUID();
    const newHistory: FeedHistory = {
      id,
      feederName: history.feederName,
      loadName: history.loadName,
      mobName: history.mobName,
      paddock: history.paddock,
      feedMultiplier: history.feedMultiplier,
      totalKg: history.totalKg,
      ingredients: history.ingredients,
      timestamp: new Date(),
    };
    this.feedHistory.set(id, newHistory);
    return newHistory;
  }
}

import { DatabaseStorage } from "./cattleDatabaseStorage";

function createStorage(): IStorage {
  if (process.env.DATABASE_URL) {
    const dbStorage = new DatabaseStorage();
    dbStorage.init().catch(console.error);
    return dbStorage;
  }
  console.log("[storage] No DATABASE_URL set — using in-memory storage (cattle). Data resets on restart.");
  return new MemStorage();
}

export const storage: IStorage = createStorage();
