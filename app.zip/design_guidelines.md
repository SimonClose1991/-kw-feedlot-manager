# Kurra-Wirra Feedlot Manager - Design Guidelines

## Design Approach

**Selected Approach:** Design System - Productivity Focused  
**Rationale:** This is a utility-first application for agricultural professionals requiring efficiency, data clarity, and reliable daily use. Drawing inspiration from Linear, Notion, and modern dashboard systems with emphasis on scannable data hierarchies and quick actions.

**Core Principles:**
- Clarity over decoration - data must be instantly readable
- Speed of operation - keyboard shortcuts visible, actions obvious
- Trust and reliability - professional aesthetic for business-critical operations
- Field-ready - works on tablets/phones in outdoor conditions

---

## Core Design Elements

### A. Color Palette

**Light Mode (Primary):**
- Background Base: 248 10% 98% (zinc-50)
- Surface: 0 0% 100% (white)
- Border: 240 6% 90% (zinc-200)
- Text Primary: 240 10% 4% (zinc-900)
- Text Secondary: 240 4% 46% (zinc-500)

**Accent Colors:**
- Primary Action: 240 6% 10% (zinc-900) - for CTAs, active states
- Success: 142 76% 36% - feeding completed
- Warning: 38 92% 50% - skip/undo actions
- Info: 217 91% 60% - AM period
- Info Alt: 271 91% 65% - PM period

**Dark Mode:**
- Background Base: 240 10% 4%
- Surface: 240 6% 10%
- Border: 240 4% 16%
- Text Primary: 0 0% 98%
- Text Secondary: 240 5% 65%

### B. Typography

**Font Stack:**
- Primary: 'Inter', system-ui, sans-serif (via Google Fonts)
- Monospace: 'JetBrains Mono', monospace (for kg values, counts)

**Scale:**
- Header (App Title): 18px (1.125rem), semibold, -0.01em tracking
- Subheader: 12px (0.75rem), medium, zinc-500
- Tab Navigation: 14px (0.875rem), medium
- Body/Labels: 14px (0.875rem), regular
- Data Values (kg, counts): 16px (1rem), monospace, medium
- Small Text: 13px (0.8125rem), regular

### C. Layout System

**Spacing Primitives:** Use Tailwind units of 1, 2, 3, 4, 6, 8, 12, 16, 24
- Micro spacing: p-1, p-2, gap-2 (4-8px)
- Component padding: p-3, p-4 (12-16px)
- Section spacing: p-6, p-8, gap-8 (24-32px)
- Vertical rhythm: space-y-4, space-y-6

**Container:**
- Max width: max-w-5xl (1024px) centered
- Horizontal padding: px-4 (mobile), px-6 (desktop)
- Vertical padding: py-3 (header), py-4 (main sections)

**Grid System:**
- Feed Run: Single column progression (one pen at a time)
- Pen List: Single column with reorder handles
- History: Responsive table/cards (stack on mobile)
- Settings: 2-column form layout on desktop, stack on mobile

### D. Component Library

**Navigation Header:**
- Sticky top, semi-transparent background with backdrop-blur
- Logo: 36px square, rounded-2xl, zinc-100 background
- Tab Pills: rounded-xl buttons, active state with dark fill
- Border bottom: 1px zinc-200

**Cards:**
- White background with subtle border (border-zinc-200)
- Rounded corners: rounded-xl (12px)
- Padding: p-4 to p-6 depending on content density
- Shadow: Very subtle or none - border-only for clarity

**Buttons:**
- Primary: Full dark background (bg-zinc-900), white text, rounded-xl
- Secondary: White background, border-zinc-200, hover:bg-zinc-100
- Ghost: No background, hover:bg-zinc-100
- Sizes: Small (px-3 py-1.5), Medium (px-4 py-2.5), Large (px-6 py-3)

**Data Display:**
- Pen Cards: Clear hierarchy - name bold, ration and counts secondary
- Progress Indicators: Horizontal bars with percentage, height-2, rounded-full
- Stats: Large monospace numbers with small labels underneath
- Tables: Zebra striping subtle (zinc-50), hover states, sticky headers

**Forms:**
- Input fields: border-zinc-200, rounded-lg, px-3 py-2, focus ring zinc-900
- Labels: text-sm font-medium mb-1.5
- Help text: text-xs text-zinc-500 mt-1
- Number inputs: monospace font for consistency

**Modals/Overlays:**
- Backdrop: Semi-transparent dark (bg-black/20)
- Dialog: max-w-md to max-w-2xl depending on content
- Rounded-2xl, white background, p-6
- Close button: top-right, ghost style

**Status Indicators:**
- Fed: Green checkmark icon, green-50 background pill
- Skipped: Yellow dash icon, amber-50 background
- Active Run: Blue dot indicator
- Completed Run: Gray checkmark

### E. Interaction Patterns

**Keyboard Shortcuts:**
- Visible hint badges near action buttons (text-xs, zinc-400, border)
- Format: "Space" "→" "←" in monospace font
- Hint text: "Press Space to confirm feed"

**Progress Tracking:**
- Linear progress bar at top of Feed Run view
- Fraction display: "5 / 12 pens" in medium weight
- Current pen highlighted with border accent

**Reordering:**
- Drag handles: Visible grip icon (6-dot pattern)
- Drop zones: Subtle highlight on hover
- Dragging state: Slight elevation and opacity change

**Data Entry Flow:**
- Auto-focus on kg override input when pen is displayed
- Clear visual separation between current pen and action buttons
- Undo action prominently placed for quick correction

---

## Page-Specific Layouts

**Feed Run Tab:**
- Progress bar spanning full width at top
- Current pen displayed as large card (center focus)
- Expected kg shown prominently in monospace
- Override input optional but clearly labeled
- Action buttons: Fed (primary, large), Skip (secondary), Undo (ghost)
- Keyboard hints visible below actions
- Completed pens list collapsed or minimized

**Pens Management Tab:**
- Action bar: Add Pen button (primary) + reorder toggle
- Pen list: Vertical cards with drag handles
- Each card: Name, ration badge, head count, kg/head, toggle active/inactive
- Edit inline or modal depending on complexity
- Delete confirmation required

**History Tab:**
- Date range filter at top (from/to date pickers)
- Summary cards: Total kg per ration, per period (AM/PM)
- Expandable run entries with event details
- Export button for data download

**Settings Tab:**
- Sections: Feeder Default, AM/PM Split Preferences, Data Management
- Split inputs: Number inputs with percentage display
- Clear visual feedback for save actions
- Import/Export with file handling UI

---

## Responsive Behavior

**Mobile (< 640px):**
- Stack all elements vertically
- Tabs become dropdown or bottom navigation
- Cards full-width with adequate touch targets (min 44px)
- Tables become card-based lists
- Hide non-essential columns/data

**Tablet (640px - 1024px):**
- Maintain 2-column layouts where beneficial
- Keep navigation horizontal
- Scale spacing proportionally

**Desktop (> 1024px):**
- Utilize horizontal space for data tables
- Side-by-side layouts for settings
- Larger touch targets still maintained for ease

---

## Accessibility & Polish

- Minimum contrast ratio 4.5:1 for all text
- Focus states: 2px ring offset, zinc-900 color
- Error states: Red-500 text + border, with icon
- Loading states: Subtle spinner or skeleton screens
- Toast notifications: Bottom-right, 4-second auto-dismiss
- Confirmation dialogs for destructive actions

---

## Images

**No hero images required** - this is a utility application focused on data and workflows. All visual elements are UI components, icons, and data visualizations.