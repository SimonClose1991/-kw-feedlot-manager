export interface Pen {
  id: string;
  name: string;
  ration: string;
  headCount: number;
  kgPerHead: number;
  rationPercent?: number;
  active: boolean;
  notes?: string;
}

export type FeedingPeriod = "AM" | "PM";

export interface FeedEvent {
  runId: string;
  penId: string;
  penName: string;
  ration: string;
  headCount: number;
  kgPerHead: number;
  totalKg: number;
  at: string;
  notes?: string;
  period: FeedingPeriod;
  splitFraction: number;
}

export interface FeedRunSummary {
  id: string;
  startedAt: string;
  finishedAt?: string;
  feeder?: string;
  period: FeedingPeriod;
  splitFraction: number;
  events: FeedEvent[];
}

export const DEFAULT_SPLIT = { AM: 0.6, PM: 0.4 } as const;

export interface MixIngredient {
  name: string;
  kgPerHead: number;
}

export interface Settings {
  adminPin: string | null;
  defaultFeeder: string | null;
  splitAM: number;
  splitPM: number;
  silage: number;
  protein: number;
  energy: number;
  water: number;
  straw: number;
  ingredients: MixIngredient[];
  bufferPercent: number;
}
