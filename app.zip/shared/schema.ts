import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const pens = pgTable("pens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  ration: text("ration").notNull(),
  headCount: integer("head_count").notNull().default(0),
  kgPerHead: real("kg_per_head").notNull().default(0),
  rationPercent: integer("ration_percent").default(100),
  active: boolean("active").notNull().default(true),
  orderIndex: integer("order_index").notNull().default(0),
  notes: text("notes"),
});

export const feedHistory = pgTable("feed_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  startedAt: timestamp("started_at").notNull(),
  finishedAt: timestamp("finished_at"),
  feeder: text("feeder"),
  period: text("period").notNull(),
  splitFraction: real("split_fraction").notNull(),
  events: jsonb("events").notNull(),
});

export const currentRun = pgTable("current_run", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  startedAt: timestamp("started_at").notNull(),
  feeder: text("feeder"),
  period: text("period").notNull(),
  splitFraction: real("split_fraction").notNull(),
  events: jsonb("events").notNull(),
});

export const settings = pgTable("settings", {
  id: varchar("id").primaryKey().default('singleton'),
  adminPin: text("admin_pin"),
  defaultFeeder: text("default_feeder"),
  splitAM: real("split_am").default(0.6),
  splitPM: real("split_pm").default(0.4),
  silage: real("silage").default(0),
  protein: real("protein").default(0),
  energy: real("energy").default(0),
  water: real("water").default(0),
  straw: real("straw").default(0),
  ingredients: jsonb("ingredients"),
  bufferPercent: real("buffer_percent").default(0),
});

export const grainRosters = pgTable("grain_rosters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  farm: text("farm").notNull(),
  feedRateKgPerSec: real("feed_rate_kg_per_sec").notNull().default(4),
  rows: jsonb("rows").notNull(),
});

export const grainFeedRuns = pgTable("grain_feed_runs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  farm: text("farm").notNull(),
  feeder: text("feeder").notNull(),
  startedAt: timestamp("started_at").notNull(),
  finishedAt: timestamp("finished_at").notNull(),
  feedRateKgPerSec: real("feed_rate_kg_per_sec").notNull(),
  totalKg: real("total_kg").notNull(),
  totalSeconds: integer("total_seconds").notNull(),
  paddocks: jsonb("paddocks").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPenSchema = createInsertSchema(pens).omit({ id: true });
export const insertFeedHistorySchema = createInsertSchema(feedHistory).omit({ id: true });
export const insertCurrentRunSchema = createInsertSchema(currentRun).omit({ id: true });
export const insertSettingsSchema = createInsertSchema(settings).omit({ id: true });
export const insertGrainRosterSchema = createInsertSchema(grainRosters).omit({ id: true });
export const insertGrainFeedRunSchema = createInsertSchema(grainFeedRuns).omit({ id: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type Pen = typeof pens.$inferSelect;
export type InsertPen = z.infer<typeof insertPenSchema>;

export type FeedHistory = typeof feedHistory.$inferSelect;
export type InsertFeedHistory = z.infer<typeof insertFeedHistorySchema>;

export type CurrentRun = typeof currentRun.$inferSelect;
export type InsertCurrentRun = z.infer<typeof insertCurrentRunSchema>;

export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;

export type GrainRoster = typeof grainRosters.$inferSelect;
export type InsertGrainRoster = z.infer<typeof insertGrainRosterSchema>;

export type GrainFeedRun = typeof grainFeedRuns.$inferSelect;
export type InsertGrainFeedRun = z.infer<typeof insertGrainFeedRunSchema>;

// Workflow weekly planner — single-row key/value store holding the whole
// planner state (tasks, staff, published weeks) as one JSON blob so it is
// shared across all devices.
export const workflowState = pgTable("workflow_state", {
  id: varchar("id").primaryKey(),
  data: jsonb("data").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type WorkflowState = typeof workflowState.$inferSelect;
