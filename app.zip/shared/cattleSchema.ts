import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, integer, timestamp, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Elements (feed ingredients like Silage, Energy, Protein, Water)
export const elements = pgTable("elements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  unit: text("unit", { enum: ["kg/head", "L/head"] }).notNull(),
  defaultRate: real("default_rate").notNull().default(0),
  isGradual: boolean("is_gradual").notNull().default(false),
});

export const insertElementSchema = createInsertSchema(elements).omit({ id: true });
export type InsertElement = z.infer<typeof insertElementSchema>;
export type Element = typeof elements.$inferSelect;

// Animal classes (e.g., Spring U Bulls, Autumn Heifers)
export const animalClasses = pgTable("animal_classes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
});

export const insertAnimalClassSchema = createInsertSchema(animalClasses).omit({ id: true });
export type InsertAnimalClass = z.infer<typeof insertAnimalClassSchema>;
export type AnimalClass = typeof animalClasses.$inferSelect;

// Recipes (per-class feeding rates for each element)
export const recipes = pgTable("recipes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  className: text("class_name").notNull(),
  elementName: text("element_name").notNull(),
  rate: real("rate").notNull(),
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({ id: true });
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type Recipe = typeof recipes.$inferSelect;

// Gradual element data type
export interface GradualElementData {
  percentage: number;
  updatedAt: string;
}

// Mobs (groups of animals with class, paddock, head count)
export const mobs = pgTable("mobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  className: text("class_name").notNull(),
  paddock: text("paddock").notNull(),
  headCount: integer("head_count").notNull(),
  feedMultiplier: real("feed_multiplier").notNull().default(1.0),
  gradualPercentages: json("gradual_percentages").$type<Record<string, GradualElementData>>().default({}),
});

export const insertMobSchema = createInsertSchema(mobs)
  .omit({ id: true })
  .extend({
    gradualPercentages: z.record(z.string(), z.object({
      percentage: z.number(),
      updatedAt: z.string(),
    })).optional(),
  });
export type InsertMob = z.infer<typeof insertMobSchema>;
export type Mob = typeof mobs.$inferSelect;

// Loads (feed loads with assigned mobs and multipliers)
export const loads = pgTable("loads", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
});

export const insertLoadSchema = createInsertSchema(loads).omit({ id: true });
export type InsertLoad = z.infer<typeof insertLoadSchema>;
export type Load = typeof loads.$inferSelect;

// Load assignments (which mobs are in which loads with feed multipliers)
export const loadAssignments = pgTable("load_assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  loadName: text("load_name").notNull(),
  mobName: text("mob_name").notNull(),
  feedMultiplier: real("feed_multiplier").notNull().default(1.0),
  feedOrder: integer("feed_order").notNull().default(0),
  twiceDaily: boolean("twice_daily").notNull().default(false),
  feedTime: text("feed_time", { enum: ["morning", "afternoon"] }).notNull().default("morning"),
});

export const insertLoadAssignmentSchema = createInsertSchema(loadAssignments).omit({ id: true });
export type InsertLoadAssignment = z.infer<typeof insertLoadAssignmentSchema>;
export type LoadAssignment = typeof loadAssignments.$inferSelect;

// Feed history (tracking who fed what and when)
export const cattleFeedHistory = pgTable("cattle_feed_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  feederName: text("feeder_name").notNull(),
  loadName: text("load_name").notNull(),
  mobName: text("mob_name").notNull(),
  paddock: text("paddock").notNull(),
  feedMultiplier: real("feed_multiplier").notNull(),
  totalKg: real("total_kg").notNull(),
  ingredients: text("ingredients").notNull().$type<Record<string, number>>(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertCattleFeedHistorySchema = createInsertSchema(cattleFeedHistory)
  .omit({ id: true, timestamp: true })
  .extend({
    ingredients: z.record(z.string(), z.number()),
  });
export type InsertFeedHistory = z.infer<typeof insertCattleFeedHistorySchema>;
export type FeedHistory = typeof cattleFeedHistory.$inferSelect;
